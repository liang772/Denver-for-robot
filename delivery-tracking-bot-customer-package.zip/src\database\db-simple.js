// Simple in-memory database for testing (no SQLite compilation needed)
const { v4: uuidv4 } = require('uuid');

// In-memory data store
const data = {
  drivers: [
    {
      id: 1,
      telegram_id: '123456789',
      name: 'Driver Zhang',
      phone: '+86 138 0000 0000'
    }
  ],
  journeys: [],
  trips: [],
  location_updates: []
};

// Initialize with mock data
function initMockData() {
  const today = new Date().toISOString().split('T')[0];
  const journeyId1 = uuidv4();
  const journeyId2 = uuidv4();

  // Add journeys
  data.journeys.push(
    {
      id: journeyId1,
      driver_id: 1,
      date: today,
      status: 'pending',
      started_at: null,
      completed_at: null
    },
    {
      id: journeyId2,
      driver_id: 1,
      date: today,
      status: 'pending',
      started_at: null,
      completed_at: null
    }
  );

  // Add trips for journey 1
  const trips1 = [
    { name: 'Beijing Chaoyang Distribution Center', address: '88 Jianguo Road, Chaoyang District', lat: 39.9042, lng: 116.4074, eta: '09:30' },
    { name: "Mr. Wang's Home", address: 'Wangjing SOHO T3, Chaoyang District', lat: 39.9965, lng: 116.4704, eta: '10:15' },
    { name: "Ms. Li's Company", address: '1 Zhongguancun Street, Haidian District', lat: 39.9869, lng: 116.3143, eta: '11:00' }
  ];

  trips1.forEach((trip, index) => {
    data.trips.push({
      id: uuidv4(),
      journey_id: journeyId1,
      sequence: index + 1,
      destination_name: trip.name,
      destination_address: trip.address,
      destination_lat: trip.lat,
      destination_lng: trip.lng,
      status: 'pending',
      reached_at: null,
      completed_at: null,
      eta: trip.eta
    });
  });

  // Add trips for journey 2
  const trips2 = [
    { name: 'Shanghai Pudong Warehouse', address: 'Zhangjiang Hi-Tech Park, Pudong', lat: 31.2304, lng: 121.4737, eta: '14:00' },
    { name: "Mr. Chen's Office", address: '100 Century Avenue, Pudong', lat: 31.2397, lng: 121.5058, eta: '15:30' }
  ];

  trips2.forEach((trip, index) => {
    data.trips.push({
      id: uuidv4(),
      journey_id: journeyId2,
      sequence: index + 1,
      destination_name: trip.name,
      destination_address: trip.address,
      destination_lat: trip.lat,
      destination_lng: trip.lng,
      status: 'pending',
      reached_at: null,
      completed_at: null,
      eta: trip.eta
    });
  });

  console.log('Mock data initialized successfully');
}

// Simple query functions
const db = {
  prepare: (sql) => {
    return {
      get: (...params) => {
        // Simple implementation for common queries
        if (sql.includes('SELECT * FROM drivers WHERE telegram_id')) {
          return data.drivers.find(d => d.telegram_id === params[0]);
        }
        if (sql.includes('SELECT * FROM journeys') && sql.includes('status = \'pending\'')) {
          return data.journeys.find(j => j.driver_id === params[0] && j.date === params[1] && j.status === 'pending');
        }
        if (sql.includes('SELECT * FROM trips') && sql.includes('status = \'pending\'')) {
          return data.trips.find(t => t.journey_id === params[0] && t.status === 'pending');
        }
        if (sql.includes('SELECT * FROM trips') && sql.includes('status = \'reached\'')) {
          return data.trips.find(t => t.journey_id === params[0] && t.status === 'reached');
        }
        return null;
      },
      all: (...params) => {
        // Simple implementation for common queries
        if (sql.includes('SELECT j.*, COUNT(t.id) as total_trips')) {
          const driverId = params[0];
          const date = params[1];
          return data.journeys
            .filter(j => j.driver_id === driverId && j.date === date)
            .map(j => {
              const journeyTrips = data.trips.filter(t => t.journey_id === j.id);
              return {
                ...j,
                total_trips: journeyTrips.length,
                completed_trips: journeyTrips.filter(t => t.status === 'completed').length
              };
            });
        }
        if (sql.includes('SELECT * FROM trips') && sql.includes('ORDER BY sequence')) {
          return data.trips
            .filter(t => t.journey_id === params[0])
            .sort((a, b) => a.sequence - b.sequence);
        }
        return [];
      },
      run: (...params) => {
        // Simple implementation for updates
        if (sql.includes('UPDATE journeys') && sql.includes('SET status = \'active\'')) {
          const journey = data.journeys.find(j => j.id === params[1]);
          if (journey) {
            journey.status = 'active';
            journey.started_at = params[0];
          }
        }
        if (sql.includes('UPDATE trips') && sql.includes('SET status = \'reached\'')) {
          const trip = data.trips.find(t => t.id === params[1]);
          if (trip) {
            trip.status = 'reached';
            trip.reached_at = params[0];
          }
        }
        if (sql.includes('UPDATE trips') && sql.includes('SET status = \'completed\'')) {
          const trip = data.trips.find(t => t.id === params[1]);
          if (trip) {
            trip.status = 'completed';
            trip.completed_at = params[0];
          }
        }
        if (sql.includes('UPDATE trips') && sql.includes('SET eta')) {
          const trip = data.trips.find(t => t.id === params[1]);
          if (trip) {
            trip.eta = params[0];
          }
        }
        if (sql.includes('UPDATE journeys') && sql.includes('SET status = \'completed\'')) {
          const journey = data.journeys.find(j => j.id === params[1]);
          if (journey) {
            journey.status = 'completed';
            journey.completed_at = params[0];
          }
        }
        if (sql.includes('INSERT INTO location_updates')) {
          data.location_updates.push({
            id: data.location_updates.length + 1,
            journey_id: params[0],
            latitude: params[1],
            longitude: params[2],
            timestamp: params[3]
          });
        }
        return { changes: 1 };
      }
    };
  }
};

// Initialize mock data on load
initMockData();

module.exports = db;
