const TelegramBot = require('node-telegram-bot-api');
const config = require('../config');
const handlers = require('./handlers');

let bot;

function initBot(app) {
  if (config.env === 'production') {
    // Webhook mode for production
    bot = new TelegramBot(config.telegram.token);
    bot.setWebHook(`${config.telegram.webhookUrl}/bot${config.telegram.token}`);
    
    app.post(`/bot${config.telegram.token}`, (req, res) => {
      bot.processUpdate(req.body);
      res.sendStatus(200);
    });
  } else {
    // Polling mode for development
    bot = new TelegramBot(config.telegram.token, { polling: true });
  }

  // Command handlers
  bot.onText(/\/start/, (msg) => handlers.handleStart(bot, msg));
  
  // Message handlers
  bot.on('message', (msg) => {
    if (msg.text === '📋 今日我的行程') {
      handlers.handleMyJourneys(bot, msg);
    } else if (msg.text === '🚀 启动行程') {
      handlers.handleStartJourney(bot, msg);
    } else if (msg.text === '⏭️ 跳过位置（演示模式）') {
      handlers.handleSkipLocation(bot, msg);
    } else if (msg.text === '📍 到达目的地') {
      handlers.handleReachedDestination(bot, msg);
    } else if (msg.text === '✅ 完成目的地配送') {
      handlers.handleCompleteDestination(bot, msg);
    } else if (msg.location) {
      handlers.handleLocation(bot, msg);
    }
  });

  console.log('Telegram bot initialized');
  return bot;
}

module.exports = { initBot };
