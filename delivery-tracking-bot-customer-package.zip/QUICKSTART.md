# 🚀 Quick Start

## 1. Install Dependencies
```bash
npm install
```

## 2. Start Demo Server
```bash
# Windows
START_DEMO.bat

# Mac/Linux
node test-simple.js
```

## 3. Open in Browser
- Dashboard: http://localhost:3001/
- Live Map: http://localhost:3001/map.html

## 📚 Full Documentation
See README.md for complete documentation.

## 🎬 Demo Guide
See CUSTOMER_DEMO_GUIDE.md for presentation guide.

---
**Ready to demo in 2 minutes!**
