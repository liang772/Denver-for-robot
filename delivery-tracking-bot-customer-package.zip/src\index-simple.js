// IMPORTANT: Override database module BEFORE any other requires
const Module = require('module');
const originalRequire = Module.prototype.require;

Module.prototype.require = function(id) {
  if (id === './database/db' || id.endsWith('database/db') || id.endsWith('database\\db')) {
    return originalRequire.call(this, './database/db-simple');
  }
  return originalRequire.apply(this, arguments);
};

const express = require('express');
const config = require('./config');
const { initBot } = require('./bot');
const apiRoutes = require('./api/routes');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Delivery Tracking Bot API',
    version: '1.0.0',
    mode: 'Simple Test Mode (In-Memory Database)'
  });
});

// API routes
app.use('/api', apiRoutes);

// Initialize Telegram bot
initBot(app);

// Start server
app.listen(config.api.port, () => {
  console.log(`\n========================================`);
  console.log(`Server running on port ${config.api.port}`);
  console.log(`Environment: ${config.env}`);
  console.log(`Mode: Simple Test (In-Memory Database)`);
  console.log(`========================================\n`);
  console.log(`✓ Bot initialized`);
  console.log(`✓ Mock data loaded`);
  console.log(`✓ Ready to test!\n`);
  console.log(`Test the API:`);
  console.log(`  http://localhost:${config.api.port}/`);
  console.log(`  http://localhost:${config.api.port}/api/drivers/1/journeys`);
  console.log(`\n========================================\n`);
});
