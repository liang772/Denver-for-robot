// Simple standalone test server - no SQLite compilation needed
const express = require('express');
const TelegramBot = require('node-telegram-bot-api');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// In-memory data store
const data = {
  drivers: [
    {
      id: 1,
      telegram_id: '123456789',
      name: 'Driver Zhang',
      phone: '+86 138 0000 0000'
    }
  ],
  journeys: [],
  trips: [],
  location_updates: []
};

// Initialize mock data
function initMockData() {
  const today = new Date().toISOString().split('T')[0];
  const journeyId1 = uuidv4();
  const journeyId2 = uuidv4();

  data.journeys.push(
    {
      id: journeyId1,
      driver_id: 1,
      date: today,
      status: 'pending',
      started_at: null,
      completed_at: null
    },
    {
      id: journeyId2,
      driver_id: 1,
      date: today,
      status: 'pending',
      started_at: null,
      completed_at: null
    }
  );

  // Journey 1 trips
  const trips1 = [
    { name: 'Beijing Chaoyang Distribution Center', address: '88 Jianguo Road, Chaoyang District', lat: 39.9042, lng: 116.4074, eta: '09:30' },
    { name: "Mr. Wang's Home", address: 'Wangjing SOHO T3, Chaoyang District', lat: 39.9965, lng: 116.4704, eta: '10:15' },
    { name: "Ms. Li's Company", address: '1 Zhongguancun Street, Haidian District', lat: 39.9869, lng: 116.3143, eta: '11:00' }
  ];

  trips1.forEach((trip, index) => {
    data.trips.push({
      id: uuidv4(),
      journey_id: journeyId1,
      sequence: index + 1,
      destination_name: trip.name,
      destination_address: trip.address,
      destination_lat: trip.lat,
      destination_lng: trip.lng,
      status: 'pending',
      reached_at: null,
      completed_at: null,
      eta: trip.eta
    });
  });

  // Journey 2 trips
  const trips2 = [
    { name: 'Shanghai Pudong Warehouse', address: 'Zhangjiang Hi-Tech Park, Pudong', lat: 31.2304, lng: 121.4737, eta: '14:00' },
    { name: "Mr. Chen's Office", address: '100 Century Avenue, Pudong', lat: 31.2397, lng: 121.5058, eta: '15:30' }
  ];

  trips2.forEach((trip, index) => {
    data.trips.push({
      id: uuidv4(),
      journey_id: journeyId2,
      sequence: index + 1,
      destination_name: trip.name,
      destination_address: trip.address,
      destination_lat: trip.lat,
      destination_lng: trip.lng,
      status: 'pending',
      reached_at: null,
      completed_at: null,
      eta: trip.eta
    });
  });

  console.log('✓ Mock data initialized');
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check API (must be before static files)
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Delivery Tracking Bot API - Test Mode',
    version: '1.0.0',
    mode: 'In-Memory Database (No SQLite)',
    journeys: data.journeys.length,
    trips: data.trips.length
  });
});

// Serve static files from public directory (this will serve index.html for /)
app.use(express.static('public'));

// API Routes
app.get('/api/drivers/:driverId/journeys', (req, res) => {
  const { driverId } = req.params;
  const date = req.query.date || new Date().toISOString().split('T')[0];
  
  const journeys = data.journeys
    .filter(j => j.driver_id == driverId && j.date === date)
    .map(j => {
      const journeyTrips = data.trips.filter(t => t.journey_id === j.id);
      return {
        ...j,
        total_trips: journeyTrips.length,
        completed_trips: journeyTrips.filter(t => t.status === 'completed').length
      };
    });
  
  res.json({ success: true, data: journeys });
});

app.get('/api/journeys/:journeyId', (req, res) => {
  const { journeyId } = req.params;
  const journey = data.journeys.find(j => j.id === journeyId);
  
  if (!journey) {
    return res.status(404).json({ error: 'Journey not found' });
  }
  
  const trips = data.trips.filter(t => t.journey_id === journeyId);
  res.json({ journey, trips });
});

app.get('/api/journeys/:journeyId/trips', (req, res) => {
  const { journeyId } = req.params;
  const trips = data.trips
    .filter(t => t.journey_id === journeyId)
    .sort((a, b) => a.sequence - b.sequence);
  
  res.json({ success: true, data: trips });
});

app.put('/api/trips/:tripId/status', (req, res) => {
  const { tripId } = req.params;
  const { status } = req.body;
  
  const trip = data.trips.find(t => t.id === tripId);
  if (!trip) {
    return res.status(404).json({ error: 'Trip not found' });
  }
  
  trip.status = status;
  if (status === 'reached') {
    trip.reached_at = new Date().toISOString();
  } else if (status === 'completed') {
    trip.completed_at = new Date().toISOString();
  }
  
  res.json({ success: true, trip });
});

app.put('/api/trips/:tripId/eta', (req, res) => {
  const { tripId } = req.params;
  const { eta } = req.body;
  
  const trip = data.trips.find(t => t.id === tripId);
  if (!trip) {
    return res.status(404).json({ error: 'Trip not found' });
  }
  
  trip.eta = eta;
  res.json({ success: true, trip });
});

app.get('/api/journeys/:journeyId/location', (req, res) => {
  const { journeyId } = req.params;
  const locations = data.location_updates
    .filter(l => l.journey_id === journeyId)
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  res.json({ locations });
});

// POST /api/journeys/:journeyId/location-update
app.post('/api/journeys/:journeyId/location-update', (req, res) => {
  const { journeyId } = req.params;
  const { latitude, longitude } = req.body;
  
  if (!latitude || !longitude) {
    return res.status(400).json({ success: false, error: '缺少位置信息' });
  }

  const timestamp = new Date().toISOString();
  
  data.location_updates.push({
    id: data.location_updates.length + 1,
    journey_id: journeyId,
    latitude: latitude,
    longitude: longitude,
    timestamp: timestamp
  });

  res.json({
    success: true,
    message: '位置已更新',
    data: { latitude, longitude, timestamp }
  });
});

// Initialize Telegram Bot
let bot;
const activeJourneys = new Map();

if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_BOT_TOKEN !== 'your_bot_token_here') {
  try {
    bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: true });
    
    bot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const welcomeMessage = `
👋 Welcome to Delivery Tracking Bot!

I can help you:
• View today's journeys
• Start journey and track location
• Update delivery status

Please select an action:
      `;

      const keyboard = {
        keyboard: [
          [{ text: '📋 My Journeys Today' }],
          [{ text: '🚀 Start Journey' }],
          [{ text: '📍 Arrived at Destination' }],
          [{ text: '✅ Complete Delivery' }]
        ],
        resize_keyboard: true
      };

      bot.sendMessage(chatId, welcomeMessage, { reply_markup: keyboard });
    });

    bot.on('message', (msg) => {
      const chatId = msg.chat.id;
      
      if (msg.text === '📋 My Journeys Today') {
        const today = new Date().toISOString().split('T')[0];
        const journeys = data.journeys.filter(j => j.date === today).map(j => {
          const journeyTrips = data.trips.filter(t => t.journey_id === j.id);
          return {
            ...j,
            total_trips: journeyTrips.length,
            completed_trips: journeyTrips.filter(t => t.status === 'completed').length
          };
        });

        if (journeys.length === 0) {
          bot.sendMessage(chatId, '📭 No journeys scheduled for today.');
          return;
        }

        let message = '📋 *Today\'s Journeys*\n\n';
        journeys.forEach((journey, index) => {
          const statusEmoji = journey.status === 'active' ? '🟢' : journey.status === 'completed' ? '✅' : '⚪';
          message += `${statusEmoji} *Journey ${index + 1}*\n`;
          message += `Status: ${journey.status}\n`;
          message += `Deliveries: ${journey.completed_trips}/${journey.total_trips}\n\n`;
        });

        bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
      }
      
      else if (msg.text === '🚀 Start Journey') {
        const today = new Date().toISOString().split('T')[0];
        const journey = data.journeys.find(j => j.date === today && j.status === 'pending');

        if (!journey) {
          bot.sendMessage(chatId, '❌ No pending journeys to start.');
          return;
        }

        bot.sendMessage(chatId, '🚀 Please share your live location to start the journey:', {
          reply_markup: {
            keyboard: [
              [{ text: '📍 Share Live Location', request_location: true }]
            ],
            one_time_keyboard: true,
            resize_keyboard: true
          }
        });

        activeJourneys.set(chatId, journey.id);
      }
      
      else if (msg.location) {
        const journeyId = activeJourneys.get(chatId);
        if (!journeyId) {
          bot.sendMessage(chatId, '❌ Please select "Start Journey" first.');
          return;
        }

        const journey = data.journeys.find(j => j.id === journeyId);
        journey.status = 'active';
        journey.started_at = new Date().toISOString();

        data.location_updates.push({
          id: data.location_updates.length + 1,
          journey_id: journeyId,
          latitude: msg.location.latitude,
          longitude: msg.location.longitude,
          timestamp: new Date().toISOString()
        });

        const nextTrip = data.trips.find(t => t.journey_id === journeyId && t.status === 'pending');

        let message = '✅ Journey started!\n\n';
        if (nextTrip) {
          message += `📍 *Next Delivery*\n`;
          message += `Destination: ${nextTrip.destination_name}\n`;
          message += `Address: ${nextTrip.destination_address}\n`;
          message += `ETA: ${nextTrip.eta}\n`;
        }

        bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
      }
      
      else if (msg.text === '📍 Arrived at Destination') {
        const journeyId = activeJourneys.get(chatId);
        if (!journeyId) {
          bot.sendMessage(chatId, '❌ No active journey.');
          return;
        }

        const currentTrip = data.trips.find(t => t.journey_id === journeyId && t.status === 'pending');
        if (!currentTrip) {
          bot.sendMessage(chatId, '❌ No pending destination.');
          return;
        }

        currentTrip.status = 'reached';
        currentTrip.reached_at = new Date().toISOString();

        bot.sendMessage(chatId, `✅ Marked as arrived!\n\n📍 *${currentTrip.destination_name}*\n${currentTrip.destination_address}`, 
          { parse_mode: 'Markdown' });
      }
      
      else if (msg.text === '✅ Complete Delivery') {
        const journeyId = activeJourneys.get(chatId);
        if (!journeyId) {
          bot.sendMessage(chatId, '❌ No active journey.');
          return;
        }

        const currentTrip = data.trips.find(t => t.journey_id === journeyId && t.status === 'reached');
        if (!currentTrip) {
          bot.sendMessage(chatId, '❌ Please mark "Arrived at Destination" first.');
          return;
        }

        currentTrip.status = 'completed';
        currentTrip.completed_at = new Date().toISOString();

        const nextTrip = data.trips.find(t => t.journey_id === journeyId && t.sequence > currentTrip.sequence && t.status === 'pending');

        let message = `✅ Delivery completed!\n\n📦 ${currentTrip.destination_name}\n\n`;

        if (nextTrip) {
          message += `📍 *Next Delivery*\n`;
          message += `Destination: ${nextTrip.destination_name}\n`;
          message += `Address: ${nextTrip.destination_address}\n`;
          message += `ETA: ${nextTrip.eta}\n`;
        } else {
          message += `🎉 All deliveries completed!`;
          const journey = data.journeys.find(j => j.id === journeyId);
          journey.status = 'completed';
          journey.completed_at = new Date().toISOString();
          activeJourneys.delete(chatId);
        }

        bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
      }
    });

    console.log('✓ Telegram bot initialized');
  } catch (error) {
    console.log('⚠ Telegram bot not initialized:', error.message);
    console.log('  Set TELEGRAM_BOT_TOKEN in .env to enable bot');
  }
} else {
  console.log('⚠ Telegram bot not initialized');
  console.log('  Set TELEGRAM_BOT_TOKEN in .env to enable bot');
}

// Initialize and start
initMockData();

app.listen(PORT, () => {
  console.log(`\n========================================`);
  console.log(`✓ Server running on port ${PORT}`);
  console.log(`✓ Mode: Test (In-Memory Database)`);
  console.log(`========================================\n`);
  console.log(`🌐 Open in browser:`);
  console.log(`  http://localhost:${PORT}/`);
  console.log(`\n📡 Test the API:`);
  console.log(`  http://localhost:${PORT}/api/drivers/1/journeys?date=${new Date().toISOString().split('T')[0]}`);
  console.log(`\n========================================\n`);
});
