# API Reference Documentation

## Overview

This document describes the REST API interface specification for the delivery journey tracking system. The current version uses mock data and can be integrated with a real backend system later.

**Base URL:** `http://localhost:3000/api`  
**Content-Type:** `application/json`  
**Version:** 1.0.0

---

## Authentication

The current version does not implement authentication. For future integration, we recommend using:
- JWT Token
- API Key
- OAuth 2.0

---

## Endpoint Details

### 1. Get Driver's Today Journeys

Get all journeys for a specific driver on the current day.

**Endpoint:** `GET /api/drivers/{driverId}/journeys`

**Path Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| driverId | integer | Yes | Driver ID |

**Request Example:**
```http
GET /api/drivers/1/journeys
```

**Response Example (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "driver_id": 1,
      "date": "2025-12-08",
      "status": "pending",
      "started_at": null,
      "completed_at": null,
      "total_trips": 3,
      "completed_trips": 0
    }
  ]
}
```

**Field Descriptions:**
- `status`: Journey status
  - `pending` - Not started
  - `active` - In progress
  - `completed` - Completed
- `total_trips`: Total number of delivery destinations
- `completed_trips`: Number of completed destinations

---

### 2. Start Journey

Start a specified journey and record initial location.

**Endpoint:** `POST /api/journeys/{journeyId}/start`

**Path Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| journeyId | string | Yes | Journey ID (UUID) |

**Request Body:**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

**Request Body Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| latitude | number | No | Latitude |
| longitude | number | No | Longitude |

**Response Example (200 OK):**
```json
{
  "success": true,
  "message": "Journey started",
  "data": {
    "journeyId": "550e8400-e29b-41d4-a716-446655440000",
    "startedAt": "2025-12-08T09:00:00.000Z"
  }
}
```

---

### 3. Update Location

Continuously update driver's GPS location information.

**Endpoint:** `POST /api/journeys/{journeyId}/location-update`

**Path Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| journeyId | string | Yes | Journey ID (UUID) |

**Request Body:**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

**Request Body Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| latitude | number | Yes | Latitude (-90 to 90) |
| longitude | number | Yes | Longitude (-180 to 180) |

**Response Example (200 OK):**
```json
{
  "success": true,
  "message": "Location updated",
  "data": {
    "latitude": 39.9042,
    "longitude": 116.4074,
    "timestamp": "2025-12-08T09:15:00.000Z"
  }
}
```

**Error Response (400 Bad Request):**
```json
{
  "success": false,
  "error": "Missing location information"
}
```

---

### 4. Get Journey Trips List

Get all delivery trips (destinations) for a specified journey.

**Endpoint:** `GET /api/journeys/{journeyId}/trips`

**Path Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| journeyId | string | Yes | Journey ID (UUID) |

**Request Example:**
```http
GET /api/journeys/550e8400-e29b-41d4-a716-446655440000/trips
```

**Response Example (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "660e8400-e29b-41d4-a716-446655440001",
      "journey_id": "550e8400-e29b-41d4-a716-446655440000",
      "sequence": 1,
      "destination_name": "Beijing Chaoyang Distribution Center",
      "destination_address": "88 Jianguo Road, Chaoyang District",
      "destination_lat": 39.9042,
      "destination_lng": 116.4074,
      "status": "pending",
      "reached_at": null,
      "completed_at": null,
      "eta": "09:30"
    },
    {
      "id": "660e8400-e29b-41d4-a716-446655440002",
      "journey_id": "550e8400-e29b-41d4-a716-446655440000",
      "sequence": 2,
      "destination_name": "Mr. Wang's Home",
      "destination_address": "Wangjing SOHO T3, Chaoyang District",
      "destination_lat": 39.9965,
      "destination_lng": 116.4704,
      "status": "pending",
      "reached_at": null,
      "completed_at": null,
      "eta": "10:15"
    }
  ]
}
```

**Field Descriptions:**
- `sequence`: Delivery sequence (starts from 1)
- `status`: Delivery trip status
  - `pending` - Not started
  - `reached` - Reached destination
  - `completed` - Completed
- `eta`: Estimated time of arrival (HH:MM format)

---

### 5. Mark Destination as Reached

Mark a delivery trip as "reached" status and return a deep link.

**Endpoint:** `POST /api/trips/{tripId}/reached`

**Path Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| tripId | string | Yes | Delivery Trip ID (UUID) |

**Request Example:**
```http
POST /api/trips/660e8400-e29b-41d4-a716-446655440001/reached
```

**Response Example (200 OK):**
```json
{
  "success": true,
  "message": "Marked as reached",
  "data": {
    "tripId": "660e8400-e29b-41d4-a716-446655440001",
    "reachedAt": "2025-12-08T09:30:00.000Z",
    "deepLink": "https://your-webapp-domain.com/journey/550e8400-e29b-41d4-a716-446655440000/trip/660e8400-e29b-41d4-a716-446655440001"
  }
}
```

**Field Descriptions:**
- `deepLink`: URL to open journey details in web application

---

### 6. Complete Delivery Trip

Mark a delivery trip as "completed" and return updated ETA for next destination.

**Endpoint:** `POST /api/trips/{tripId}/complete`

**Path Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| tripId | string | Yes | Delivery Trip ID (UUID) |

**Request Example:**
```http
POST /api/trips/660e8400-e29b-41d4-a716-446655440001/complete
```

**Response Example (200 OK) - With Next Destination:**
```json
{
  "success": true,
  "message": "Delivery completed",
  "data": {
    "tripId": "660e8400-e29b-41d4-a716-446655440001",
    "completedAt": "2025-12-08T09:45:00.000Z",
    "nextTrip": {
      "id": "660e8400-e29b-41d4-a716-446655440002",
      "destination": "Mr. Wang's Home",
      "updatedEta": "10:15"
    }
  }
}
```

**Response Example (200 OK) - No Next Destination (Last Stop):**
```json
{
  "success": true,
  "message": "Delivery completed",
  "data": {
    "tripId": "660e8400-e29b-41d4-a716-446655440003",
    "completedAt": "2025-12-08T11:30:00.000Z",
    "nextTrip": null
  }
}
```

**Field Descriptions:**
- `nextTrip`: Next delivery destination information (if exists)
- `updatedEta`: Updated estimated time of arrival (currently mock calculation, actual calculation requires backend integration)

---

## Status Codes

| Status Code | Description | Use Case |
|-------------|-------------|----------|
| 200 | OK | Request successful |
| 400 | Bad Request | Request parameters error or missing |
| 404 | Not Found | Resource not found |
| 500 | Internal Server Error | Server internal error |

---

## Error Response Format

All error responses follow a unified format:

```json
{
  "success": false,
  "error": "Error description message"
}
```

**Example:**
```json
{
  "success": false,
  "error": "Missing location information"
}
```

---

## Data Models

### Driver
```typescript
{
  id: number;
  telegram_id: string;
  name: string;
  phone: string;
}
```

### Journey
```typescript
{
  id: string;  // UUID
  driver_id: number;
  date: string;  // ISO 8601 date (YYYY-MM-DD)
  status: 'pending' | 'active' | 'completed';
  started_at: string | null;  // ISO 8601 datetime
  completed_at: string | null;  // ISO 8601 datetime
}
```

### Trip (Delivery Task)
```typescript
{
  id: string;  // UUID
  journey_id: string;  // UUID
  sequence: number;
  destination_name: string;
  destination_address: string;
  destination_lat: number;
  destination_lng: number;
  status: 'pending' | 'reached' | 'completed';
  reached_at: string | null;  // ISO 8601 datetime
  completed_at: string | null;  // ISO 8601 datetime
  eta: string;  // HH:MM format
}
```

### LocationUpdate
```typescript
{
  id: number;
  journey_id: string;  // UUID
  latitude: number;
  longitude: number;
  timestamp: string;  // ISO 8601 datetime
}
```

---

## Integration Guide

### Backend Integration Steps

1. **Replace Data Source**
   - Replace SQLite queries in `src/api/routes.js` with backend API calls
   - Use axios or fetch to call real backend interfaces

2. **Configure API Base URL**
   ```env
   API_BASE_URL=https://your-backend-api.com
   ```

3. **Implement Authentication**
   - Add JWT token verification
   - Pass authentication information in request headers

4. **Implement Real ETA Calculation**
   - Integrate map services (Google Maps API / Amap API)
   - Calculate estimated arrival time based on real-time traffic

### Example: Integrating Backend API

```javascript
// Before (using SQLite)
const journeys = db.prepare(`
  SELECT * FROM journeys WHERE driver_id = ?
`).all(driverId);

// After (calling backend API)
const response = await fetch(`${config.api.baseUrl}/drivers/${driverId}/journeys`, {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});
const journeys = await response.json();
```

---

## Testing

### Using cURL

```bash
# Get driver journeys
curl http://localhost:3000/api/drivers/1/journeys

# Start journey
curl -X POST http://localhost:3000/api/journeys/{journeyId}/start \
  -H "Content-Type: application/json" \
  -d '{"latitude": 39.9042, "longitude": 116.4074}'

# Update location
curl -X POST http://localhost:3000/api/journeys/{journeyId}/location-update \
  -H "Content-Type: application/json" \
  -d '{"latitude": 39.9042, "longitude": 116.4074}'

# Get delivery trips list
curl http://localhost:3000/api/journeys/{journeyId}/trips

# Mark as reached
curl -X POST http://localhost:3000/api/trips/{tripId}/reached

# Complete delivery
curl -X POST http://localhost:3000/api/trips/{tripId}/complete
```

### Using Postman

Import the following Collection:

```json
{
  "info": {
    "name": "Delivery Tracking API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Get Driver Journeys",
      "request": {
        "method": "GET",
        "url": "{{baseUrl}}/api/drivers/1/journeys"
      }
    }
  ],
  "variable": [
    {
      "key": "baseUrl",
      "value": "http://localhost:3000"
    }
  ]
}
```

---

## Version History

### v1.0.0 (2025-12-08)
- Initial version
- Implemented 6 core API endpoints
- Using mock data
- Support basic journey management features

---

## Contact

For questions or suggestions, please contact the development team.
