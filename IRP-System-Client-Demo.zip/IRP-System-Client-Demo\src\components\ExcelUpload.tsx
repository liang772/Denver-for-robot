'use client'

/**
 * Excel Upload Component
 * Allows bulk upload of trips via Excel file
 * Phase 2.1: Trip Upload Feature
 */

import { useState, useCallback } from 'react'
import * as XLSX from 'xlsx'

interface ExcelRow {
  trip_name: string
  destination_name: string
  destination_address: string
  destination_lat?: number
  destination_lng?: number
  customer_name?: string
  customer_phone?: string
  load_pallets: number
  delivery_type?: 'delivery' | 'refund_pickup' | 'pickup'
  time_window_start?: string
  time_window_end?: string
  service_time?: number
  notes?: string
}

interface ParsedTrip {
  name: string
  destinations: Array<{
    name: string
    address: string
    latitude?: number
    longitude?: number
    customer_name?: string
    customer_phone?: string
    load_pallets: number
    delivery_type: 'delivery' | 'refund_pickup' | 'pickup'
    time_window_start?: string
    time_window_end?: string
    service_time?: number
    notes?: string
    sequence: number
  }>
}

interface ExcelUploadProps {
  onTripsUploaded: (trips: ParsedTrip[]) => void
  onCancel: () => void
}

export default function ExcelUpload({ onTripsUploaded, onCancel }: ExcelUploadProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [preview, setPreview] = useState<ParsedTrip[]>([])
  const [file, setFile] = useState<File | null>(null)

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setError(null)
    parseExcelFile(selectedFile)
  }, [])

  const parseExcelFile = async (file: File) => {
    setIsProcessing(true)
    setError(null)

    try {
      const data = await file.arrayBuffer()
      const workbook = XLSX.read(data, { type: 'array' })
      const sheetName = workbook.SheetNames[0]
      const sheet = workbook.Sheets[sheetName]
      const rows = XLSX.utils.sheet_to_json<ExcelRow>(sheet)

      if (rows.length === 0) {
        throw new Error('Excel file is empty')
      }

      // Group destinations by trip_name
      const tripsMap = new Map<string, ParsedTrip>()

      rows.forEach((row, index) => {
        const tripName = row.trip_name?.toString().trim()
        if (!tripName) {
          throw new Error(`Row ${index + 2}: Missing trip_name`)
        }

        if (!row.destination_name || !row.destination_address) {
          throw new Error(`Row ${index + 2}: Missing destination_name or destination_address`)
        }

        if (!tripsMap.has(tripName)) {
          tripsMap.set(tripName, {
            name: tripName,
            destinations: []
          })
        }

        const trip = tripsMap.get(tripName)!
        trip.destinations.push({
          name: row.destination_name,
          address: row.destination_address,
          latitude: row.destination_lat,
          longitude: row.destination_lng,
          customer_name: row.customer_name,
          customer_phone: row.customer_phone,
          load_pallets: row.load_pallets || 0,
          delivery_type: row.delivery_type || 'delivery',
          time_window_start: row.time_window_start,
          time_window_end: row.time_window_end,
          service_time: row.service_time,
          notes: row.notes,
          sequence: trip.destinations.length + 1
        })
      })

      const parsedTrips = Array.from(tripsMap.values())
      setPreview(parsedTrips)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to parse Excel file')
    } finally {
      setIsProcessing(false)
    }
  }

  const handleConfirm = () => {
    if (preview.length > 0) {
      onTripsUploaded(preview)
    }
  }

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault()
    const droppedFile = event.dataTransfer.files[0]
    if (droppedFile && (droppedFile.name.endsWith('.xlsx') || droppedFile.name.endsWith('.xls'))) {
      setFile(droppedFile)
      parseExcelFile(droppedFile)
    }
  }, [])

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault()
  }, [])

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b">
          <h2 className="text-2xl font-bold">Upload Trips from Excel</h2>
          <p className="text-gray-600 mt-2">Upload an Excel file with trip and destination information</p>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* File Upload Area */}
          {!preview.length && (
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors"
            >
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileSelect}
                className="hidden"
                id="excel-upload"
              />
              <label htmlFor="excel-upload" className="cursor-pointer">
                <div className="text-6xl mb-4">📊</div>
                <p className="text-lg font-medium mb-2">
                  Drop Excel file here or click to browse
                </p>
                <p className="text-sm text-gray-500">Supports .xlsx and .xls files</p>
              </label>
            </div>
          )}

          {/* Excel Format Guide */}
          {!preview.length && (
            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold mb-2">📋 Required Excel Format</h3>
              <div className="text-sm space-y-1">
                <p><strong>Required columns:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><code>trip_name</code> - Name of the trip</li>
                  <li><code>destination_name</code> - Destination name</li>
                  <li><code>destination_address</code> - Full address</li>
                  <li><code>load_pallets</code> - Number of pallets (positive for delivery, negative for refund)</li>
                </ul>
                <p className="mt-2"><strong>Optional columns:</strong></p>
                <ul className="list-disc list-inside ml-4 space-y-1">
                  <li><code>destination_lat</code>, <code>destination_lng</code> - GPS coordinates</li>
                  <li><code>customer_name</code>, <code>customer_phone</code> - Customer details</li>
                  <li><code>delivery_type</code> - delivery, refund_pickup, or pickup</li>
                  <li><code>time_window_start</code>, <code>time_window_end</code> - Time constraints</li>
                  <li><code>service_time</code> - Service time in minutes</li>
                  <li><code>notes</code> - Additional notes</li>
                </ul>
              </div>
            </div>
          )}

          {/* Processing State */}
          {isProcessing && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p>Processing Excel file...</p>
            </div>
          )}

          {/* Error Display */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
              <h3 className="font-semibold text-red-800 mb-2">Error</h3>
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {/* Preview */}
          {preview.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Preview: {preview.length} Trip(s)</h3>
                <button
                  onClick={() => {
                    setPreview([])
                    setFile(null)
                  }}
                  className="text-blue-600 hover:text-blue-800"
                >
                  Upload Different File
                </button>
              </div>

              <div className="space-y-4">
                {preview.map((trip, tripIndex) => (
                  <div key={tripIndex} className="border rounded-lg p-4 bg-gray-50">
                    <h4 className="font-semibold mb-2">
                      {trip.name} ({trip.destinations.length} destination{trip.destinations.length !== 1 ? 's' : ''})
                    </h4>
                    <div className="space-y-2">
                      {trip.destinations.map((dest, destIndex) => (
                        <div key={destIndex} className="flex items-start text-sm bg-white p-2 rounded">
                          <span className="font-mono text-gray-500 mr-2">{dest.sequence}.</span>
                          <div className="flex-1">
                            <div className="font-medium">{dest.name}</div>
                            <div className="text-gray-600">{dest.address}</div>
                            <div className="flex gap-4 mt-1 text-xs text-gray-500">
                              <span>📦 {dest.load_pallets} pallets</span>
                              {dest.delivery_type !== 'delivery' && (
                                <span className="text-orange-600">🔄 {dest.delivery_type}</span>
                              )}
                              {dest.customer_name && <span>👤 {dest.customer_name}</span>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="p-6 border-t bg-gray-50 flex justify-end gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-100"
          >
            Cancel
          </button>
          {preview.length > 0 && (
            <button
              onClick={handleConfirm}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Import {preview.length} Trip(s)
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
