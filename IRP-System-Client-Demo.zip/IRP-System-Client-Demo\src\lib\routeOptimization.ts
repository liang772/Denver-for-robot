// Route optimization utilities for fuel and time efficiency

export interface Destination {
  id: string
  address: string
  preferredDeliveryTime: string
  order: number
  loadInfo: string
  coordinates: [number, number]
}

export interface OptimizedTrip {
  id: string
  tripNumber: number
  destinations: Destination[]
  totalLoad: number
  estimatedDuration: string
  startTime: string
  endTime: string
  totalDistance: number
  fuelEfficiency: number
}

// Calculate distance between two coordinates using Haversine formula
export const calculateDistance = (coord1: [number, number], coord2: [number, number]): number => {
  const [lat1, lon1] = coord1
  const [lat2, lon2] = coord2
  
  const R = 6371 // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLon = (lon2 - lon1) * Math.PI / 180
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}

// Calculate total distance for a sequence of destinations
export const calculateTripDistance = (destinations: Destination[], departureCoords: [number, number]): number => {
  if (destinations.length === 0) return 0
  
  let totalDistance = 0
  let currentCoords = departureCoords
  
  for (const destination of destinations) {
    totalDistance += calculateDistance(currentCoords, destination.coordinates)
    currentCoords = destination.coordinates
  }
  
  // Add return journey to departure point
  totalDistance += calculateDistance(currentCoords, departureCoords)
  
  return totalDistance
}

// Optimize route using Nearest Neighbor algorithm with time constraints
export const optimizeRoute = (
  destinations: Destination[], 
  departureCoords: [number, number],
  maxPalletsPerTrip: number = 3
): OptimizedTrip[] => {
  if (destinations.length === 0) return []
  
  // Separate destinations with and without time constraints
  const destinationsWithTime = destinations.filter(d => d.preferredDeliveryTime)
  const destinationsWithoutTime = destinations.filter(d => !d.preferredDeliveryTime)
  
  // Sort time-constrained destinations by preferred time
  const sortedDestinationsWithTime = destinationsWithTime.sort((a, b) => {
    const timeA = a.preferredDeliveryTime.split(' - ')[0]
    const timeB = b.preferredDeliveryTime.split(' - ')[0]
    return timeA.localeCompare(timeB)
  })
  
  // Combine destinations: time-constrained first, then flexible ones
  const allDestinations = [...sortedDestinationsWithTime, ...destinationsWithoutTime]
  
  const trips: OptimizedTrip[] = []
  let currentTrip: Destination[] = []
  let currentLoad = 0
  let tripNumber = 1
  
  for (const destination of allDestinations) {
    const pallets = parseFloat(destination.loadInfo.split(' ')[0])
    
    // Check if adding this destination would exceed capacity
    if (currentLoad + pallets > maxPalletsPerTrip) {
      // Finalize current trip
      if (currentTrip.length > 0) {
        const optimizedTrip = createOptimizedTrip(currentTrip, departureCoords, tripNumber)
        trips.push(optimizedTrip)
        tripNumber++
      }
      
      // Start new trip
      currentTrip = [destination]
      currentLoad = pallets
    } else {
      // Add to current trip
      currentTrip.push(destination)
      currentLoad += pallets
    }
  }
  
  // Add final trip if there are remaining destinations
  if (currentTrip.length > 0) {
    const optimizedTrip = createOptimizedTrip(currentTrip, departureCoords, tripNumber)
    trips.push(optimizedTrip)
  }
  
  return trips
}

// Create an optimized trip with proper destination sequencing
const createOptimizedTrip = (
  destinations: Destination[], 
  departureCoords: [number, number], 
  tripNumber: number
): OptimizedTrip => {
  // Optimize the sequence within this trip using Nearest Neighbor
  const optimizedSequence = optimizeTripSequence(destinations, departureCoords)
  
  // Calculate trip statistics
  const totalLoad = optimizedSequence.reduce((sum, dest) => sum + parseFloat(dest.loadInfo.split(' ')[0]), 0)
  const totalDistance = calculateTripDistance(optimizedSequence, departureCoords)
  
  // Find time constraints for this trip
  const destinationsWithTime = optimizedSequence.filter(d => d.preferredDeliveryTime)
  let startTime = '08:00' // Default start time
  let endTime = '18:00'   // Default end time
  
  if (destinationsWithTime.length > 0) {
    // Use the earliest start time and latest end time from destinations with constraints
    const startTimes = destinationsWithTime.map(d => d.preferredDeliveryTime.split(' - ')[0])
    const endTimes = destinationsWithTime.map(d => d.preferredDeliveryTime.split(' - ')[1])
    startTime = startTimes.reduce((earliest, current) => 
      current < earliest ? current : earliest
    )
    endTime = endTimes.reduce((latest, current) => 
      current > latest ? current : latest
    )
  }
  
  // Calculate fuel efficiency (km per pallet)
  const fuelEfficiency = totalDistance > 0 ? totalDistance / totalLoad : 0
  
  return {
    id: `trip-${tripNumber}`,
    tripNumber,
    destinations: optimizedSequence,
    totalLoad,
    estimatedDuration: `${optimizedSequence.length * 45} min`,
    startTime,
    endTime,
    totalDistance: Math.round(totalDistance * 100) / 100, // Round to 2 decimal places
    fuelEfficiency: Math.round(fuelEfficiency * 100) / 100
  }
}

// Optimize sequence within a trip using Nearest Neighbor algorithm
const optimizeTripSequence = (destinations: Destination[], departureCoords: [number, number]): Destination[] => {
  if (destinations.length <= 1) return destinations
  
  const unvisited = [...destinations]
  const optimized: Destination[] = []
  let currentCoords = departureCoords
  
  while (unvisited.length > 0) {
    // Find the nearest unvisited destination
    let nearestIndex = 0
    let nearestDistance = calculateDistance(currentCoords, unvisited[0].coordinates)
    
    for (let i = 1; i < unvisited.length; i++) {
      const distance = calculateDistance(currentCoords, unvisited[i].coordinates)
      if (distance < nearestDistance) {
        nearestDistance = distance
        nearestIndex = i
      }
    }
    
    // Add nearest destination to optimized sequence
    const nearest = unvisited.splice(nearestIndex, 1)[0]
    optimized.push(nearest)
    currentCoords = nearest.coordinates
  }
  
  return optimized
}

// Calculate fuel cost estimate (assuming 10km/L and $2.50/L)
export const calculateFuelCost = (totalDistance: number): number => {
  const fuelEfficiency = 10 // km per liter
  const fuelPrice = 2.50 // SGD per liter
  const fuelUsed = totalDistance / fuelEfficiency
  return Math.round(fuelUsed * fuelPrice * 100) / 100
}

// Calculate time estimate including travel time (assuming 30km/h average speed)
export const calculateTotalTime = (destinations: Destination[], totalDistance: number): string => {
  const deliveryTime = destinations.length * 45 // 45 minutes per delivery
  const travelTime = (totalDistance / 30) * 60 // Convert to minutes (30 km/h average)
  const totalMinutes = deliveryTime + travelTime
  
  const hours = Math.floor(totalMinutes / 60)
  const minutes = Math.round(totalMinutes % 60)
  
  if (hours > 0) {
    return `${hours}h ${minutes}m`
  } else {
    return `${minutes}m`
  }
}
