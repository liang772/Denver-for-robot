/**
 * Notification Service
 * Phase 4.1 & 4.2: Notification infrastructure and workflows
 * 
 * Implements three notification workflows:
 * 1. D-1 Pre-delivery time window notification
 * 2. "On the Way" notification when journey starts
 * 3. Next Trip notification when trip completes
 */

import { SupabaseClient } from '@supabase/supabase-js'

// Notification channels
export type NotificationChannel = 'whatsapp' | 'sms' | 'email' | 'push'

export interface NotificationRecipient {
  customerId?: string
  customerName?: string
  phone?: string
  email?: string
  whatsapp?: string
}

export interface NotificationContent {
  title: string
  message: string
  templateId?: string
  variables?: Record<string, any>
}

export interface NotificationResult {
  success: boolean
  messageId?: string
  error?: string
  channel: NotificationChannel
}

export class NotificationService {
  constructor(private supabase: SupabaseClient) {}

  /**
   * WORKFLOW 1: D-1 Pre-delivery Time Window Notification
   * Trigger: Daily batch job (evening) 1 day before delivery
   * Purpose: Inform customers of next-day delivery window
   */
  async sendD1PreDeliveryNotifications(deliveryDate: string): Promise<void> {
    try {
      console.log(`[Workflow 1] Sending D-1 notifications for ${deliveryDate}`)

      // Get all journeys scheduled for the target date
      const { data: journeys, error: journeysError } = await this.supabase
        .from('irp_journeys')
        .select(`
          id,
          name,
          date,
          planned_departure_time
        `)
        .eq('date', deliveryDate)

      if (journeysError) throw journeysError

      for (const journey of journeys || []) {
        // Get all destinations for this journey
        const { data: destinations, error: destsError } = await this.supabase
          .from('irp_trip_destinations')
          .select(`
            *,
            trip:irp_trips!inner(journey_id)
          `)
          .eq('trip.journey_id', journey.id)

        if (destsError) continue

        for (const dest of destinations || []) {
          const timeWindow = this.calculateTimeWindow(dest.estimated_arrival_time)
          
          await this.sendNotification({
            recipient: {
              customerName: dest.customer_name,
              phone: dest.customer_phone,
              whatsapp: dest.customer_whatsapp,
              email: dest.customer_email
            },
            content: {
              title: 'Delivery Scheduled Tomorrow',
              message: `Your delivery is scheduled for ${deliveryDate} between ${timeWindow}. We'll notify you when the driver is on the way.`,
              templateId: 'd1_pre_delivery',
              variables: {
                delivery_date: deliveryDate,
                time_window: timeWindow,
                address: dest.address
              }
            },
            channels: ['whatsapp', 'sms'],
            metadata: {
              journey_id: journey.id,
              destination_id: dest.id,
              workflow: 'D-1 Pre-delivery'
            }
          })
        }
      }

      console.log(`[Workflow 1] Completed D-1 notifications for ${deliveryDate}`)
    } catch (error) {
      console.error('[Workflow 1] Error sending D-1 notifications:', error)
      throw error
    }
  }

  /**
   * WORKFLOW 2: "On the Way" Notification
   * Trigger: When driver presses "Start Journey"
   * Purpose: Inform customers that truck is on the way
   */
  async sendOnTheWayNotifications(journeyId: string): Promise<void> {
    try {
      console.log(`[Workflow 2] Sending "On the Way" notifications for journey ${journeyId}`)

      // Get journey details
      const { data: journey, error: journeyError } = await this.supabase
        .from('irp_journeys')
        .select('*, driver:irp_drivers(name)')
        .eq('id', journeyId)
        .single()

      if (journeyError) throw journeyError

      // Get all destinations in this journey
      const { data: trips, error: tripsError } = await this.supabase
        .from('irp_trips')
        .select(`
          *,
          trip_destinations:irp_trip_destinations(*)
        `)
        .eq('journey_id', journeyId)
        .order('journey_sequence', { ascending: true })

      if (tripsError) throw tripsError

      // Send notification to all destinations
      for (const trip of trips || []) {
        for (const dest of trip.trip_destinations || []) {
          const eta = dest.estimated_arrival_time || 'soon'

          await this.sendNotification({
            recipient: {
              customerName: dest.customer_name,
              phone: dest.customer_phone,
              whatsapp: dest.customer_whatsapp,
              email: dest.customer_email
            },
            content: {
              title: '🚛 Driver is on the way!',
              message: `Your delivery is on the way! Driver ${journey.driver?.name || 'N/A'} will arrive around ${eta}. Track your delivery in real-time.`,
              templateId: 'on_the_way',
              variables: {
                driver_name: journey.driver?.name || 'N/A',
                eta: eta,
                address: dest.address,
                tracking_link: `https://yourapp.com/track/${dest.id}`
              }
            },
            channels: ['whatsapp', 'sms'],
            metadata: {
              journey_id: journeyId,
              trip_id: trip.id,
              destination_id: dest.id,
              workflow: 'On the Way'
            }
          })
        }
      }

      console.log(`[Workflow 2] Completed "On the Way" notifications`)
    } catch (error) {
      console.error('[Workflow 2] Error sending "On the Way" notifications:', error)
      throw error
    }
  }

  /**
   * WORKFLOW 3: Next Trip Notification
   * Trigger: When a trip is marked completed
   * Purpose: Notify customers in the next trip that they're up next
   */
  async sendNextTripNotifications(completedTripId: string): Promise<void> {
    try {
      console.log(`[Workflow 3] Sending Next Trip notifications after trip ${completedTripId}`)

      // Get the completed trip's journey and sequence
      const { data: completedTrip, error: tripError } = await this.supabase
        .from('irp_trips')
        .select('journey_id, journey_sequence')
        .eq('id', completedTripId)
        .single()

      if (tripError || !completedTrip) {
        console.error('Completed trip not found')
        return
      }

      // Get the next trip in sequence
      const { data: nextTrips, error: nextTripError } = await this.supabase
        .from('irp_trips')
        .select(`
          *,
          trip_destinations:irp_trip_destinations(*)
        `)
        .eq('journey_id', completedTrip.journey_id)
        .gt('journey_sequence', completedTrip.journey_sequence)
        .order('journey_sequence', { ascending: true })
        .limit(1)

      if (nextTripError || !nextTrips || nextTrips.length === 0) {
        console.log('No next trip found - journey might be complete')
        return
      }

      const nextTrip = nextTrips[0]

      // Send notifications to all destinations in next trip
      for (const dest of nextTrip.trip_destinations || []) {
        const eta = dest.estimated_arrival_time || 'soon'

        await this.sendNotification({
          recipient: {
            customerName: dest.customer_name,
            phone: dest.customer_phone,
            whatsapp: dest.customer_whatsapp,
            email: dest.customer_email
          },
          content: {
            title: "You're Next! 🎯",
            message: `Great news! Your delivery is coming up next. Expected arrival: ${eta}. Please be available to receive your delivery.`,
            templateId: 'next_trip',
            variables: {
              eta: eta,
              address: dest.address
            }
          },
          channels: ['whatsapp', 'sms'],
          metadata: {
            journey_id: completedTrip.journey_id,
            trip_id: nextTrip.id,
            destination_id: dest.id,
            workflow: 'Next Trip'
          }
        })
      }

      console.log(`[Workflow 3] Completed Next Trip notifications`)
    } catch (error) {
      console.error('[Workflow 3] Error sending Next Trip notifications:', error)
      throw error
    }
  }

  /**
   * Core notification sending method
   */
  async sendNotification(params: {
    recipient: NotificationRecipient
    content: NotificationContent
    channels: NotificationChannel[]
    metadata?: Record<string, any>
  }): Promise<NotificationResult[]> {
    const results: NotificationResult[] = []

    for (const channel of params.channels) {
      try {
        let result: NotificationResult

        switch (channel) {
          case 'whatsapp':
            result = await this.sendWhatsApp(params.recipient, params.content)
            break
          case 'sms':
            result = await this.sendSMS(params.recipient, params.content)
            break
          case 'email':
            result = await this.sendEmail(params.recipient, params.content)
            break
          default:
            result = {
              success: false,
              error: `Unsupported channel: ${channel}`,
              channel
            }
        }

        results.push(result)

        // Log notification to database
        await this.logNotification({
          recipient_phone: params.recipient.phone,
          recipient_email: params.recipient.email,
          channel,
          title: params.content.title,
          message: params.content.message,
          status: result.success ? 'sent' : 'failed',
          error_message: result.error,
          metadata: params.metadata
        })
      } catch (error) {
        console.error(`Error sending via ${channel}:`, error)
        results.push({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
          channel
        })
      }
    }

    return results
  }

  /**
   * Send WhatsApp message
   */
  private async sendWhatsApp(
    recipient: NotificationRecipient,
    content: NotificationContent
  ): Promise<NotificationResult> {
    // TODO: Integrate with WhatsApp Business API or third-party service like Twilio
    // For now, return mock success
    console.log('[WhatsApp] Sending to:', recipient.whatsapp, content.message)
    
    // Example Twilio WhatsApp integration (commented):
    /*
    const twilio = require('twilio')
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
    
    try {
      const message = await client.messages.create({
        body: content.message,
        from: 'whatsapp:+14155238886', // Twilio sandbox or your WhatsApp number
        to: `whatsapp:${recipient.whatsapp}`
      })
      
      return {
        success: true,
        messageId: message.sid,
        channel: 'whatsapp'
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
        channel: 'whatsapp'
      }
    }
    */

    return {
      success: true,
      messageId: `wa_${Date.now()}`,
      channel: 'whatsapp'
    }
  }

  /**
   * Send SMS message
   */
  private async sendSMS(
    recipient: NotificationRecipient,
    content: NotificationContent
  ): Promise<NotificationResult> {
    // TODO: Integrate with SMS service like Twilio
    console.log('[SMS] Sending to:', recipient.phone, content.message)
    
    // Example Twilio SMS integration (commented):
    /*
    const twilio = require('twilio')
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
    
    try {
      const message = await client.messages.create({
        body: content.message,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: recipient.phone
      })
      
      return {
        success: true,
        messageId: message.sid,
        channel: 'sms'
      }
    } catch (error) {
      return {
        success: false,
        error: error.message,
        channel: 'sms'
      }
    }
    */

    return {
      success: true,
      messageId: `sms_${Date.now()}`,
      channel: 'sms'
    }
  }

  /**
   * Send Email
   */
  private async sendEmail(
    recipient: NotificationRecipient,
    content: NotificationContent
  ): Promise<NotificationResult> {
    // TODO: Integrate with email service
    console.log('[Email] Sending to:', recipient.email, content.message)

    return {
      success: true,
      messageId: `email_${Date.now()}`,
      channel: 'email'
    }
  }

  /**
   * Calculate time window based on ETA
   */
  private calculateTimeWindow(eta?: string): string {
    if (!eta) return '10:00-18:00'

    try {
      const [hours] = eta.split(':').map(Number)
      
      if (hours < 14) {
        return '10:00-14:00'
      } else if (hours < 18) {
        return '14:00-18:00'
      } else {
        return '18:00-20:00'
      }
    } catch {
      return '10:00-18:00'
    }
  }

  /**
   * Log notification to database
   */
  private async logNotification(data: {
    recipient_phone?: string
    recipient_email?: string
    channel: NotificationChannel
    title: string
    message: string
    status: 'sent' | 'failed' | 'pending'
    error_message?: string
    metadata?: Record<string, any>
  }): Promise<void> {
    try {
      await this.supabase.from('irp_notifications').insert({
        recipient_phone: data.recipient_phone,
        recipient_email: data.recipient_email,
        channel: data.channel,
        title: data.title,
        message: data.message,
        status: data.status,
        error_message: data.error_message,
        metadata: data.metadata || {}
      })
    } catch (error) {
      console.error('Error logging notification:', error)
    }
  }
}

/**
 * Singleton instance
 */
let notificationService: NotificationService | null = null

export function getNotificationService(supabase: SupabaseClient): NotificationService {
  if (!notificationService) {
    notificationService = new NotificationService(supabase)
  }
  return notificationService
}

export default NotificationService
