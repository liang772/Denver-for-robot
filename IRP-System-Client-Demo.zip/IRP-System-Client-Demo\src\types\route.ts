// Route planning data types that match our database schema

export interface Route {
  id: string
  user_id: string
  name: string
  description?: string
  date: string
  departure_address: string
  departure_latitude?: number
  departure_longitude?: number
  status: 'planned' | 'active' | 'completed' | 'cancelled'
  total_destinations: number
  total_load: number
  estimated_distance?: number
  estimated_duration?: number
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface Destination {
  id: string
  route_id: string
  address: string
  latitude?: number
  longitude?: number
  location_name?: string
  preferred_delivery_time_start?: string
  preferred_delivery_time_end?: string
  load_info: string
  load_pallets: number
  requires_tailgate: boolean
  special_instructions?: string
  contact_person?: string
  contact_phone?: string
  priority: number
  estimated_stop_duration: number
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface Trip {
  id: string
  route_id: string
  trip_number: number
  name?: string
  start_time?: string
  end_time?: string
  estimated_duration?: number
  total_load: number
  destination_count: number
  requires_tailgate: boolean
  vehicle_type: 'standard' | 'tailgate' | 'refrigerated'
  driver_notes?: string
  status: 'planned' | 'in_progress' | 'completed' | 'cancelled'
  // New trip tracking fields
  return_to_warehouse_time?: number
  total_offloading_time_extra?: number
  total_offloading_time?: number
  loading_time?: number
  truck_id?: string
  // Truck information
  truck?: {
    id: string
    display_name: string
    is_internal: boolean
    capacity_pallets: number
  } | null
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface TripDestination {
  id: string
  trip_id: string
  trip_order: number
  address: string
  latitude?: number
  longitude?: number
  load_info?: string
  load_pallets: number
  requires_tailgate: boolean
  estimated_arrival_time?: string
  actual_arrival_time?: string
  actual_departure_time?: string
  notes?: string
  // New trip tracking fields
  truck_id?: string
  time_to_location?: number
  offloading_time?: number
  offloading_time_extra?: number
  address_type?: string
  // Truck information
  truck?: {
    id: string
    display_name: string
    is_internal: boolean
  } | null
  created_at: string
  updated_at: string
}

export interface Vehicle {
  id: string
  user_id: string
  name: string
  vehicle_type: 'standard' | 'tailgate' | 'refrigerated' | 'flatbed'
  capacity_pallets: number
  capacity_weight?: number
  capacity_volume?: number
  fuel_efficiency?: number
  operating_cost_per_km?: number
  driver_required: boolean
  available: boolean
  current_location_lat?: number
  current_location_lng?: number
  maintenance_due_date?: string
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface Truck {
  id: string
  user_id: string
  display_name: string
  is_internal: boolean
  capacity_pallets: number
  available_count: number
  vehicle_type: 'standard' | 'tailgate' | 'refrigerated' | 'flatbed'
  fuel_efficiency?: number
  operating_cost_per_km?: number
  driver_required: boolean
  current_location_lat?: number
  current_location_lng?: number
  maintenance_due_date?: string
  contractor_name?: string
  contractor_contact?: string
  contractor_rate?: number
  notes?: string
  is_active: boolean
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface TruckAvailability {
  id: string
  truck_id: string
  date: string
  available_count: number
  reserved_count: number
  notes?: string
  created_at: string
  updated_at: string
}

export interface TruckMaintenance {
  id: string
  truck_id: string
  maintenance_type: 'routine' | 'repair' | 'inspection' | 'emergency'
  description: string
  cost?: number
  performed_by?: string
  performed_at: string
  next_maintenance_date?: string
  mileage_at_service?: number
  notes?: string
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface TripTruck {
  id: string
  trip_id: string
  truck_id: string
  driver_id?: string
  assigned_date: string
  assigned_at: string
  assignment_notes?: string
  estimated_departure_time?: string
  estimated_return_time?: string
  actual_departure_time?: string
  actual_return_time?: string
  status: 'assigned' | 'in_transit' | 'completed' | 'cancelled'
  created_at: string
  updated_at: string
}

export interface UndeliverableDestination {
  id: string
  route_id: string
  destination_order: number
  address: string
  latitude?: number
  longitude?: number
  load_info?: string
  load_pallets: number
  requires_tailgate: boolean
  estimated_arrival_time?: string
  actual_arrival_time?: string
  actual_departure_time?: string
  notes?: string
  constraint_type: 'time_conflict' | 'capacity_exceeded' | 'vehicle_unavailable' | 'geographical_constraint' | 'manual_exclusion'
  constraint_reason: string
  suggested_resolution?: string
  priority: number
  reschedule_date?: string
  reschedule_time_start?: string
  reschedule_time_end?: string
  status: 'pending' | 'rescheduled' | 'cancelled' | 'resolved'
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface RouteWithDestinations extends Route {
  destinations: Destination[]
}

export interface TripWithDestinations extends Trip {
  trip_destinations?: TripDestination[]
}

// Frontend-friendly interfaces (for backward compatibility)
export interface RouteListItem {
  id: string
  name: string
  date: string
  departureAddress: string
  destinationCount: number
  totalLoad: string
  status: 'active' | 'completed' | 'planned' | 'cancelled'
  createdAt: string
}

export interface DestinationItem {
  id: string
  address: string
  preferredDeliveryTime: string
  order: number
  loadInfo: string
  tailgate: boolean
}

export interface TripItem {
  id: string
  tripNumber: number
  destinations: DestinationItem[]
  totalLoad: number
  estimatedDuration: string
  startTime: string
  endTime: string
}

export interface TruckListItem {
  id: string
  displayName: string
  isInternal: boolean
  capacityPallets: number
  availableCount: number
  vehicleType: 'standard' | 'tailgate' | 'refrigerated' | 'flatbed'
  contractorName?: string
  contractorRate?: number
  isActive: boolean
  createdAt: string
}

// API request/response types
export interface CreateRouteRequest {
  name: string
  description?: string
  date: string
  departure_address: string
  departure_latitude?: number
  departure_longitude?: number
}

export interface CreateDestinationRequest {
  address: string
  latitude?: number
  longitude?: number
  location_name?: string
  preferred_delivery_time_start?: string
  preferred_delivery_time_end?: string
  load_info: string
  load_pallets: number
  requires_tailgate?: boolean
  special_instructions?: string
  contact_person?: string
  contact_phone?: string
  priority?: number
}

export interface CreateTripRequest {
  trip_number: number
  name?: string
  start_time?: string
  end_time?: string
  estimated_duration?: number
  total_load: number
  requires_tailgate?: boolean
  vehicle_type?: string
  driver_notes?: string
}

export interface CreateTruckRequest {
  display_name: string
  is_internal: boolean
  capacity_pallets: number
  available_count: number
  vehicle_type?: string
  fuel_efficiency?: number
  operating_cost_per_km?: number
  driver_required?: boolean
  current_location_lat?: number
  current_location_lng?: number
  maintenance_due_date?: string
  contractor_name?: string
  contractor_contact?: string
  contractor_rate?: number
  notes?: string
}

// Destination Types
export interface DestinationType {
  id: string
  user_id: string
  name: string
  description?: string
  extraOffloadingTime: number
  isActive: boolean
  colorCode: string
  icon: string
  allowedTruckIds: string[]
  allowedTruckNames: string[]
  metadata?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface DestinationTypeListItem {
  id: string
  name: string
  description?: string
  extraOffloadingTime: number
  isActive: boolean
  colorCode: string
  icon: string
  allowedTruckIds: string[]
  allowedTruckNames: string[]
  truckCount: number
  createdAt: string
}

// Enhanced truck data for API calls (includes destination type information)
export interface EnhancedTruckData {
  truck_id: string
  count: number
  capacity_pallets: number
  vehicle_type: 'standard' | 'tailgate' | 'refrigerated' | 'flatbed'
  is_internal: boolean
  contractor_name?: string | null
  contractor_rate?: number | null
  allowed_destination_types: {
    id: string
    name: string
    description?: string
    extra_offloading_time: number
    color_code: string
    icon: string
  }[]
}

// API response for calculate-trips
export interface CalculateTripsResponse {
  success: boolean
  message: string
  routeId: string
  truckDetails: EnhancedTruckData[]
  destinationTypesIncluded: number
  totalTruckDestinationTypeMappings: number
}

// Utility types
export type RouteStatus = Route['status']
export type TripStatus = Trip['status']
export type VehicleType = Vehicle['vehicle_type']
export type TruckType = Truck['vehicle_type']
export type TruckStatus = TripTruck['status']
export type MaintenanceType = TruckMaintenance['maintenance_type']
export type ConstraintType = UndeliverableDestination['constraint_type']
export type UndeliverableStatus = UndeliverableDestination['status']
