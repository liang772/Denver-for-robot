import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, message, type, chat_id } = body

    if ((!phone && !chat_id) || !message) {
      return NextResponse.json(
        { error: 'Phone number (or chat_id) and message are required' },
        { status: 400 }
      )
    }

    const botToken = process.env.TELEGRAM_BOT_TOKEN
    
    if (!botToken) {
      return NextResponse.json(
        { 
          error: 'Telegram bot not configured. Please set TELEGRAM_BOT_TOKEN environment variable.',
          info: 'Add TELEGRAM_BOT_TOKEN to your .env.local file'
        },
        { status: 503 }
      )
    }

    // If chat_id is provided directly, use it
    // Otherwise, you would need to look it up from your database using the phone number
    const targetChatId = chat_id

    if (!targetChatId) {
      return NextResponse.json(
        { 
          success: false,
          message: `Phone number ${phone} is not registered with the bot yet.`,
          note: 'Customer needs to open Telegram, search for your bot, and send /start followed by /register ${phone}'
        },
        { status: 200 }
      )
    }

    // Send message via Telegram API
    const telegramApiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`
    
    const response = await fetch(telegramApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: targetChatId,
        text: message,
        parse_mode: 'HTML'
      })
    })

    const data = await response.json()

    if (!response.ok) {
      console.error('Telegram API error:', data)
      return NextResponse.json(
        { 
          error: 'Failed to send Telegram message',
          details: data.description || 'Unknown error'
        },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      message: `Notification sent successfully`,
      type: type || 'generic',
      timestamp: new Date().toISOString(),
      telegram_response: data
    })

  } catch (error) {
    console.error('Telegram send error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to send notification',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
