# Google Maps Integration Setup Guide

## 🗺️ Overview

The IRP system supports both OpenStreetMap (free) and Google Maps (premium) for live tracking and route visualization. This guide explains how to set up Google Maps integration.

## 🚀 Quick Setup

### 1. Get Google Maps API Key

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/

2. **Create or Select a Project**
   - Create a new project or select an existing one
   - Project name example: "IRP-Logistics-System"

3. **Enable Required APIs**
   - Go to "APIs & Services" > "Library"
   - Enable these APIs:
     - ✅ **Maps JavaScript API** (Required)
     - ✅ **Places API** (Optional, for address autocomplete)
     - ✅ **Directions API** (Optional, for route optimization)
     - ✅ **Geocoding API** (Optional, for address conversion)

4. **Create API Key**
   - Go to "APIs & Services" > "Credentials"
   - Click "Create Credentials" > "API Key"
   - Copy the generated API key

5. **Secure Your API Key (Important!)**
   - Click on your API key to edit it
   - Under "Application restrictions":
     - Select "HTTP referrers (web sites)"
     - Add your domains:
       - `localhost:3000/*` (for development)
       - `localhost:3001/*` (for development)
       - `yourdomain.com/*` (for production)
   - Under "API restrictions":
     - Select "Restrict key"
     - Choose only the APIs you enabled above

### 2. Configure Environment Variables

1. **Copy the example file:**
   ```bash
   cp .env.example .env.local
   ```

2. **Add your Google Maps API key:**
   ```env
   NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your-actual-api-key-here
   ```

3. **Restart your development server:**
   ```bash
   npm run dev
   ```

## 🎯 Using Google Maps

### In Live Tracking Page

1. Navigate to **Live Tracking** page
2. In the top-right controls, you'll see a dropdown
3. Select **"🌍 Google Maps"** instead of **"🗺️ OpenStreetMap"**
4. The map will switch to Google Maps with enhanced features

### Features Available with Google Maps

- ✅ **Satellite View** - Aerial imagery
- ✅ **Street View Integration** - Street-level imagery
- ✅ **Traffic Information** - Real-time traffic data
- ✅ **Better Address Search** - Enhanced geocoding
- ✅ **Route Optimization** - Advanced routing algorithms
- ✅ **Custom Styling** - Professional map themes

## 💰 Pricing Information

### Google Maps Pricing (as of 2024)

- **Maps JavaScript API**: $7 per 1,000 map loads
- **First 28,000 map loads per month**: FREE
- **Directions API**: $5 per 1,000 requests
- **Geocoding API**: $5 per 1,000 requests

### Cost Estimation for IRP System

**Small Operation (< 10 drivers):**
- Monthly map loads: ~5,000
- **Cost: FREE** (within free tier)

**Medium Operation (10-50 drivers):**
- Monthly map loads: ~15,000
- **Cost: FREE** (within free tier)

**Large Operation (50+ drivers):**
- Monthly map loads: ~50,000
- **Cost: ~$154/month** ((50,000 - 28,000) × $7/1,000)

## 🔧 Advanced Configuration

### Custom Map Styling

You can customize the Google Maps appearance by modifying the `styles` array in `GoogleMap.tsx`:

```javascript
styles: [
  {
    featureType: 'poi',
    elementType: 'labels',
    stylers: [{ visibility: 'off' }]
  },
  // Add more custom styles here
]
```

### Enable Additional Features

To enable more Google Maps features, update your API key restrictions to include:

- **Places API** - For address autocomplete
- **Directions API** - For route optimization
- **Distance Matrix API** - For travel time calculations

## 🛡️ Security Best Practices

### 1. API Key Restrictions
- ✅ Always restrict your API key to specific domains
- ✅ Only enable the APIs you actually use
- ✅ Monitor usage in Google Cloud Console

### 2. Environment Variables
- ✅ Never commit API keys to version control
- ✅ Use different API keys for development and production
- ✅ Rotate API keys regularly

### 3. Usage Monitoring
- ✅ Set up billing alerts in Google Cloud Console
- ✅ Monitor API usage regularly
- ✅ Implement client-side caching to reduce API calls

## 🔄 Fallback Strategy

The system is designed with a fallback strategy:

1. **Primary**: Google Maps (if API key is configured)
2. **Fallback**: OpenStreetMap (always available, free)

If Google Maps fails to load, the system will automatically show an error message and users can switch back to OpenStreetMap.

## 🐛 Troubleshooting

### Common Issues

**1. "Google Maps API Key Required" message**
- ✅ Check that `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` is set in `.env.local`
- ✅ Restart your development server after adding the key

**2. Map not loading**
- ✅ Check browser console for error messages
- ✅ Verify API key restrictions allow your domain
- ✅ Ensure Maps JavaScript API is enabled

**3. "This page can't load Google Maps correctly" error**
- ✅ Check API key restrictions
- ✅ Verify billing is enabled in Google Cloud Console
- ✅ Check if you've exceeded your quota

**4. Markers not showing**
- ✅ Check that driver data contains valid latitude/longitude
- ✅ Verify coordinates are within valid ranges (-90 to 90 for lat, -180 to 180 for lng)

### Getting Help

1. **Google Maps Documentation**: https://developers.google.com/maps/documentation
2. **Google Cloud Support**: Available with paid support plans
3. **Community Forums**: Stack Overflow, Google Maps Platform Community

## 📊 Monitoring Usage

### Google Cloud Console

1. Go to "APIs & Services" > "Dashboard"
2. Click on "Maps JavaScript API"
3. View usage charts and quotas
4. Set up alerts for usage thresholds

### Recommended Alerts

- ✅ 80% of free tier quota used
- ✅ Daily spending exceeds $10
- ✅ API error rate exceeds 5%

---

## 🎉 You're All Set!

Once configured, your IRP system will have professional-grade mapping capabilities with Google Maps integration. Users can seamlessly switch between OpenStreetMap and Google Maps based on their needs and preferences.

**Need help?** Check the troubleshooting section above or refer to the Google Maps Platform documentation.