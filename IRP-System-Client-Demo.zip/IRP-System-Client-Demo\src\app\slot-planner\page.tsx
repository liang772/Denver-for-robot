'use client'

/**
 * Delivery Slot Planner Page
 * Phase 5.1: Delivery slot suggestion system with color coding
 */

import { useState, useEffect, useCallback } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'
import { mockJourneys, mockTrips, mockDestinations } from '@/lib/mock-data'

interface TimeSlot {
  start: string
  end: string
  label: string
}

interface SlotUtilization {
  date: string
  slot: TimeSlot
  driverId?: string
  driverName?: string
  totalDrivingTime: number // minutes
  destinationCount: number
  status: 'green' | 'yellow' | 'red'
  color: string
  description: string
}

interface DailyUtilization {
  date: string
  overallStatus: 'green' | 'yellow' | 'red'
  slots: SlotUtilization[]
}

const TIME_SLOTS: TimeSlot[] = [
  { start: '10:00', end: '14:00', label: '10:00-14:00' },
  { start: '14:00', end: '18:00', label: '14:00-18:00' },
]

// const WORKING_HOURS = { start: '10:00', end: '18:00' } // Reserved for future use

export default function SlotPlannerPage() {
  const { user } = useAuth()

  const [dateRange, setDateRange] = useState<string[]>([])
  const [utilization, setUtilization] = useState<Map<string, DailyUtilization>>(new Map())
  const [isLoading, setIsLoading] = useState(true)
  const [customerType, setCustomerType] = useState<'A' | 'B'>('B') // A=Fixed, B=Flexible
  const [showAddDestination, setShowAddDestination] = useState(false)
  const [selectedSlot, setSelectedSlot] = useState<{ date: string; slot: TimeSlot } | null>(null)

  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    // Generate next 7 days
    const dates: string[] = []
    for (let i = 0; i < 7; i++) {
      const date = new Date()
      date.setDate(date.getDate() + i)
      dates.push(date.toISOString().split('T')[0])
    }
    setDateRange(dates)
  }, [])

  const calculateUtilization = useCallback(() => {
    try {
      setIsLoading(true)
      const utilizationMap = new Map<string, DailyUtilization>()

      for (const date of dateRange) {
        const dailyUtil: DailyUtilization = {
          date,
          overallStatus: 'green',
          slots: []
        }

        // Get all journeys using mock data
        const journeys = mockJourneys.filter(j => j.date === date)

        // Calculate utilization for each time slot
        for (const slot of TIME_SLOTS) {
          let totalTime = 0
          let destCount = 0

          // For each journey, calculate time spent in this slot
          for (const journey of journeys) {
            const trips = mockTrips.filter(t => t.journey_id === journey.id)
            for (const trip of trips) {
              const destinations = mockDestinations.filter(d => d.trip_id === trip.id)
              for (const dest of destinations) {
                // Assuming all destinations are within slot range (can extend mock data structure for more precision)
                const travelTime = dest.time_to_location || 0
                const offloadTime = (dest.offloading_time || 15)
                totalTime += travelTime + offloadTime
                destCount++
              }
            }
          }

          // Determine status based on total time
          let status: 'green' | 'yellow' | 'red'
          let color: string
          let description: string

          if (totalTime < 180) { // < 3 hours
            status = 'green'
            color = 'bg-green-100 border-green-300 text-green-800'
            description = 'Available'
          } else if (totalTime <= 360) { // 3-6 hours
            status = 'yellow'
            color = 'bg-yellow-100 border-yellow-300 text-yellow-800'
            description = 'Moderate'
          } else { // > 6 hours
            status = 'red'
            color = 'bg-red-100 border-red-300 text-red-800'
            description = 'High Load'
          }

          dailyUtil.slots.push({
            date,
            slot,
            totalDrivingTime: totalTime,
            destinationCount: destCount,
            status,
            color,
            description
          })
        }

        // Calculate overall day status (worst of all slots)
        const hasRed = dailyUtil.slots.some(s => s.status === 'red')
        const hasYellow = dailyUtil.slots.some(s => s.status === 'yellow')
        dailyUtil.overallStatus = hasRed ? 'red' : hasYellow ? 'yellow' : 'green'

        utilizationMap.set(date, dailyUtil)
      }

      setUtilization(utilizationMap)
    } catch (error) {
      console.error('Error calculating utilization:', error)
    } finally {
      setIsLoading(false)
    }
  }, [dateRange])

  useEffect(() => {
    if (dateRange.length > 0) {
      calculateUtilization()
    }
  }, [calculateUtilization, dateRange])

  const suggestBestSlot = (): { date: string; slot: TimeSlot } | null => {
    // Find the first green slot
    for (const date of dateRange) {
      const daily = utilization.get(date)
      if (!daily) continue

      for (const slotUtil of daily.slots) {
        if (slotUtil.status === 'green') {
          return { date, slot: slotUtil.slot }
        }
      }
    }

    // If no green, find first yellow
    for (const date of dateRange) {
      const daily = utilization.get(date)
      if (!daily) continue

      for (const slotUtil of daily.slots) {
        if (slotUtil.status === 'yellow') {
          return { date, slot: slotUtil.slot }
        }
      }
    }

    return null
  }

  const formatDuration = (minutes: number): string => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins}m`
  }

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr)
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', weekday: 'short' })
  }

  const suggestedSlot = suggestBestSlot()

  const handleSlotClick = (date: string, slot: TimeSlot) => {
    setSelectedSlot({ date, slot })
    setShowAddDestination(true)
  }

  const handleAddDestination = async (destinationData: {
    address: string
    customer_name: string
    customer_phone: string
    load_pallets: number
    delivery_type: 'delivery' | 'refund_pickup'
  }) => {
    if (!selectedSlot || !user) return

    setIsSaving(true)
    try {
      // Simulate adding destination to mock data
      console.log('Adding destination (mock):', {
        slot: selectedSlot,
        destinationData
      })

      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Refresh utilization calculation
      calculateUtilization()

      setShowAddDestination(false)
      setSelectedSlot(null)
      alert('✅ Destination added successfully! (Demo mode)')
    } catch (error) {
      console.error('Error adding destination:', error)
      alert(`❌ Failed to add destination: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <ProtectedRoute>
      <Layout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Delivery Slot Planner
            </h1>
            <p className="text-sm text-gray-600">
              Plan deliveries and suggest optimal time slots based on driver utilization
            </p>
          </div>

          {/* Customer Type Selector */}
          <div className="mb-6 bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Customer Type</h3>
            <div className="flex gap-4">
              <button
                onClick={() => setCustomerType('A')}
                className={`px-4 py-2 rounded-lg font-medium text-sm ${
                  customerType === 'A'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Type A - Fixed Time Request
              </button>
              <button
                onClick={() => setCustomerType('B')}
                className={`px-4 py-2 rounded-lg font-medium text-sm ${
                  customerType === 'B'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                Type B - Flexible (Need Suggestion)
              </button>
            </div>

            {customerType === 'B' && suggestedSlot && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl">✨</span>
                  <h4 className="font-semibold text-green-900">Suggested Slot</h4>
                </div>
                <p className="text-sm text-green-800">
                  Best available slot: <strong>{formatDate(suggestedSlot.date)}</strong> between{' '}
                  <strong>{suggestedSlot.slot.label}</strong>
                </p>
              </div>
            )}
          </div>

          {/* Legend */}
          <div className="mb-4 flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-100 border border-green-300 rounded"></div>
              <span>🟢 Green: &lt; 3h (Available)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-yellow-100 border border-yellow-300 rounded"></div>
              <span>🟡 Yellow: 3-6h (Moderate)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-100 border border-red-300 rounded"></div>
              <span>🔴 Red: &gt; 6h (High Load)</span>
            </div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          )}

          {/* Calendar Grid */}
          {!isLoading && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {dateRange.map(date => {
                const daily = utilization.get(date)
                if (!daily) return null

                return (
                  <div
                    key={date}
                    className="bg-white border-2 border-gray-200 rounded-lg p-4 hover:shadow-lg transition-shadow"
                  >
                    {/* Date Header */}
                    <div className="mb-3 pb-2 border-b border-gray-200">
                      <h3 className="font-semibold text-gray-900">{formatDate(date)}</h3>
                      <p className="text-xs text-gray-500">{date}</p>
                    </div>

                    {/* Time Slots */}
                    <div className="space-y-2">
                      {daily.slots.map((slotUtil, idx) => (
                        <div
                          key={idx}
                          className={`p-3 rounded-lg border-2 ${slotUtil.color} cursor-pointer hover:opacity-80 transition-opacity`}
                          onClick={() => handleSlotClick(date, slotUtil.slot)}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-semibold text-sm">{slotUtil.slot.label}</span>
                            <span className="text-xs font-medium">{slotUtil.description}</span>
                          </div>
                          <div className="text-xs space-y-1">
                            <div>⏱️ {formatDuration(slotUtil.totalDrivingTime)}</div>
                            <div>📦 {slotUtil.destinationCount} destinations</div>
                          </div>
                          <div className="mt-2 text-xs text-gray-600">
                            {slotUtil.status === 'red' && customerType === 'A' && (
                              <span className="text-red-700 font-semibold">⚠️ High load - consider another slot</span>
                            )}
                            {slotUtil.status !== 'red' && (
                              <span className="text-gray-500">Click to add destination</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          )}

          {/* Add Destination Modal */}
          {showAddDestination && selectedSlot && (
            <AddDestinationModal
              date={selectedSlot.date}
              slot={selectedSlot.slot}
              customerType={customerType}
              onSubmit={handleAddDestination}
              onCancel={() => {
                setShowAddDestination(false)
                setSelectedSlot(null)
              }}
              isSaving={isSaving}
            />
          )}
        </div>
      </Layout>
    </ProtectedRoute>
  )
}

// Add Destination Modal Component
function AddDestinationModal({ date, slot, customerType, onSubmit, onCancel, isSaving }: {
  date: string
  slot: TimeSlot
  customerType: 'A' | 'B'
  onSubmit: (data: {
    address: string
    customer_name: string
    customer_phone: string
    load_pallets: number
    delivery_type: 'delivery' | 'refund_pickup'
  }) => void
  onCancel: () => void
  isSaving: boolean
}) {
  const [formData, setFormData] = useState({
    address: '',
    customer_name: '',
    customer_phone: '',
    load_pallets: 0,
    delivery_type: 'delivery' as 'delivery' | 'refund_pickup'
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.address.trim()) {
      alert('Please enter delivery address')
      return
    }
    
    if (formData.load_pallets <= 0 && formData.delivery_type === 'delivery') {
      alert('Please enter valid pallet count')
      return
    }

    onSubmit(formData)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
        <h2 className="text-xl font-bold mb-4">Add Destination to Slot</h2>
        
        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-sm">
            <div><strong>Date:</strong> {new Date(date).toLocaleDateString()}</div>
            <div><strong>Time Window:</strong> {slot.label}</div>
            <div><strong>Customer Type:</strong> {customerType === 'A' ? 'Fixed Request' : 'Flexible (Suggested)'}</div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Delivery Address *
            </label>
            <textarea
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={3}
              required
              placeholder="Enter full delivery address"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Customer Name
            </label>
            <input
              type="text"
              value={formData.customer_name}
              onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Optional"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Customer Phone
            </label>
            <input
              type="tel"
              value={formData.customer_phone}
              onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Optional"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Delivery Type *
            </label>
            <select
              value={formData.delivery_type}
              onChange={(e) => setFormData({ ...formData, delivery_type: e.target.value as 'delivery' | 'refund_pickup' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="delivery">Delivery</option>
              <option value="refund_pickup">Refund Pickup</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Load (Pallets) *
            </label>
            <input
              type="number"
              value={formData.load_pallets}
              onChange={(e) => setFormData({ ...formData, load_pallets: parseFloat(e.target.value) })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              step="0.5"
              min="0"
              required
              placeholder={formData.delivery_type === 'delivery' ? 'Positive number' : 'Will be pickup'}
            />
          </div>

          <div className="flex gap-3 mt-6">
            <button
              type="button"
              onClick={onCancel}
              disabled={isSaving}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {isSaving ? 'Adding...' : 'Add Destination'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
