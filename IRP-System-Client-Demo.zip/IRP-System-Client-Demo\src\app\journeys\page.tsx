'use client'

/**
 * Journeys List Page
 * Phase 2: Journey management UI
 */

import { useState } from 'react'
import Link from 'next/link'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { mockJourneys, mockTrips, mockDestinations } from '@/lib/mock-data'

interface Journey {
  id: string
  name: string
  date: string
  driver_name?: string
  truck_name?: string
  planned_departure_time?: string
  total_planned_duration?: number
  status: 'pending' | 'active' | 'in_progress' | 'completed' | 'cancelled'
  total_trips: number
  completed_trips: number
  total_destinations: number
  completed_destinations: number
}

export default function JourneysPage() {
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0])
  
  // 处理 mock 数据，添加统计信息
  const journeys: Journey[] = mockJourneys
    .filter(j => j.date === selectedDate)
    .map(journey => {
      const trips = mockTrips.filter(t => t.journey_id === journey.id)
      const destinations = mockDestinations.filter(d => 
        trips.some(t => t.id === d.trip_id)
      )
      
      return {
        id: journey.id,
        name: journey.name,
        date: journey.date,
        driver_name: journey.driver?.name,
        truck_name: journey.truck?.display_name,
        planned_departure_time: journey.planned_departure_time,
        total_planned_duration: 480, // 8 hours default
        status: journey.status as Journey['status'],
        total_trips: trips.length,
        completed_trips: trips.filter(t => t.status === 'completed').length,
        total_destinations: destinations.length,
        completed_destinations: destinations.filter(d => d.status === 'completed').length
      }
    })

  const isLoading = false
  const error = null

  const getStatusColor = (status: Journey['status']) => {
    switch (status) {
      case 'active':
      case 'in_progress':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusIcon = (status: Journey['status']) => {
    switch (status) {
      case 'active':
      case 'in_progress':
        return '🚛'
      case 'completed':
        return '✅'
      case 'pending':
        return '⏳'
      case 'cancelled':
        return '❌'
      default:
        return '📦'
    }
  }

  const formatDuration = (minutes?: number) => {
    if (!minutes) return 'N/A'
    const hours = Math.floor(minutes / 60)
    const mins = Math.round(minutes % 60)
    return `${hours}h ${mins}m`
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Journeys">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Journeys</h1>
                <p className="mt-1 text-sm text-gray-500">
                  Manage driver journeys and trip assignments
                </p>
              </div>
              <Link
                href="/journeys/new"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
              >
                + Create Journey
              </Link>
            </div>

            {/* Date Filter */}
            <div className="flex items-center gap-4">
              <label className="text-sm font-medium text-gray-700">Date:</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
              <button
                onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])}
                className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm font-medium"
              >
                Today
              </button>
            </div>
          </div>

          {/* Loading State */}
          {isLoading && (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          )}

          {/* Error State */}
          {error && !isLoading && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-600">
              {error}
            </div>
          )}

          {/* Empty State */}
          {!isLoading && !error && journeys.length === 0 && (
            <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
              <div className="text-6xl mb-4">📅</div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No journeys for {selectedDate}
              </h3>
              <p className="text-gray-600 mb-4">
                Create a new journey to get started
              </p>
              <Link
                href="/journeys/new"
                className="inline-block px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Create Journey
              </Link>
            </div>
          )}

          {/* Journeys List */}
          {!isLoading && journeys.length > 0 && (
            <div className="space-y-4">
              {journeys.map((journey) => (
                <div
                  key={journey.id}
                  className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      {/* Header */}
                      <div className="flex items-center gap-3 mb-3">
                        <Link href={`/journeys/${journey.id}`}>
                          <h3 className="text-lg font-semibold text-gray-900 hover:text-blue-600">
                            {journey.name}
                          </h3>
                        </Link>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(
                            journey.status
                          )}`}
                        >
                          {getStatusIcon(journey.status)}{' '}
                          {journey.status.charAt(0).toUpperCase() + journey.status.slice(1)}
                        </span>
                      </div>

                      {/* Details Grid */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                        <div>
                          <div className="text-xs text-gray-500 mb-1">Driver</div>
                          <div className="text-sm font-medium text-gray-900">
                            {journey.driver_name || 'Not assigned'}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500 mb-1">Truck</div>
                          <div className="text-sm font-medium text-gray-900">
                            {journey.truck_name || 'Not assigned'}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500 mb-1">Departure Time</div>
                          <div className="text-sm font-medium text-gray-900">
                            {journey.planned_departure_time || 'Not set'}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs text-gray-500 mb-1">Duration</div>
                          <div className="text-sm font-medium text-gray-900">
                            {formatDuration(journey.total_planned_duration)}
                          </div>
                        </div>
                      </div>

                      {/* Progress */}
                      <div className="flex items-center gap-6 text-sm">
                        <div className="flex items-center gap-2">
                          <span className="text-gray-600">Trips:</span>
                          <span className="font-semibold text-gray-900">
                            {journey.completed_trips} / {journey.total_trips}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-gray-600">Destinations:</span>
                          <span className="font-semibold text-gray-900">
                            {journey.completed_destinations} / {journey.total_destinations}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Arrow */}
                    <div className="ml-4">
                      <svg
                        className="w-6 h-6 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 5l7 7-7 7"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Layout>
    </ProtectedRoute>
  )
}