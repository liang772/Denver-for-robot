import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  output: 'standalone',
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  // Force dynamic rendering to avoid build-time environment variable issues
  experimental: {
    // Ensure server components work properly in Docker
  },
  serverExternalPackages: ['@supabase/supabase-js'],
};

export default nextConfig;
