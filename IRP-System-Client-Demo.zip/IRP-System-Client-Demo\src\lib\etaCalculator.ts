/**
 * ETA Calculator Service
 * Phase 1.2: ETA Calculation Engine
 * 
 * Automatically calculates Estimated Time of Arrival (ETA) for all destinations
 * in a journey based on:
 * - Journey departure time (planned or actual)
 * - Travel time between destinations
 * - Service/offloading time at each destination
 * - Loading time at warehouse
 * 
 * Triggers recalculation on:
 * - Journey departure time change
 * - Destination reordering (drag & drop)
 * - Trip sequence change
 * - Driver starts journey (actual start time)
 */

import { SupabaseClient } from '@supabase/supabase-js'

export interface ETACalculationParams {
  journeyId?: string
  tripId?: string
  routeId?: string
  departureTime?: string // ISO time string or Time
  useActualStartTime?: boolean
}

export interface DestinationETA {
  destinationId: string
  tripId: string
  sequence: number
  estimatedArrivalTime: string // ISO timestamp
  estimatedDepartureTime: string // After offloading
  cumulativeTravelTime: number // minutes from journey start
  cumulativeServiceTime: number // minutes spent at destinations
}

export interface TripTiming {
  tripId: string
  plannedStartTime: string
  plannedEndTime: string
  totalDuration: number // minutes
  destinations: DestinationETA[]
}

export interface JourneyTiming {
  journeyId: string
  departureTime: string
  totalPlannedDuration: number // minutes
  estimatedCompletionTime: string
  trips: TripTiming[]
}

export class ETACalculator {
  constructor(private supabase: SupabaseClient) {}

  /**
   * Calculate ETAs for an entire journey
   */
  async calculateJourneyETAs(journeyId: string): Promise<JourneyTiming> {
    // 1. Get journey details
    const { data: journey, error: journeyError } = await this.supabase
      .from('irp_journeys')
      .select('*, driver:irp_drivers(*), truck:irp_trucks(*)')
      .eq('id', journeyId)
      .single()

    if (journeyError || !journey) {
      throw new Error(`Journey not found: ${journeyError?.message}`)
    }

    // 2. Get all trips in journey order
    const { data: trips, error: tripsError } = await this.supabase
      .from('irp_trips')
      .select(`
        *,
        trip_destinations:irp_trip_destinations(
          *,
          destination_type:irp_destination_types(*)
        )
      `)
      .eq('journey_id', journeyId)
      .order('journey_sequence', { ascending: true })

    if (tripsError || !trips) {
      throw new Error(`Failed to fetch trips: ${tripsError?.message}`)
    }

    // 3. Determine start time
    const departureTime = journey.actual_start_time 
      ? new Date(journey.actual_start_time)
      : this.combineDateTime(journey.date, journey.planned_departure_time || '08:00:00')

    // 4. Calculate ETAs for each trip and destination
    let currentTime = new Date(departureTime)
    let cumulativeTravelTime = 0
    let cumulativeServiceTime = 0
    const tripTimings: TripTiming[] = []

    for (const trip of trips) {
      // Add loading time at warehouse (beginning of trip)
      if (trip.loading_time) {
        currentTime = this.addMinutes(currentTime, trip.loading_time)
        cumulativeServiceTime += trip.loading_time
      }

      const tripStartTime = new Date(currentTime)
      const destinationETAs: DestinationETA[] = []

      // Sort destinations by sequence
      const sortedDestinations = (trip.trip_destinations || [])
        .sort((a, b) => (a.sequence || 0) - (b.sequence || 0))

      for (const dest of sortedDestinations) {
        // Add travel time to this destination
        if (dest.time_to_location) {
          currentTime = this.addMinutes(currentTime, dest.time_to_location)
          cumulativeTravelTime += dest.time_to_location
        }

        const arrivalTime = new Date(currentTime)

        // Calculate offloading time (base + extra from destination type)
        const baseOffloadingTime = dest.offloading_time || 15
        const extraOffloadingTime = dest.offloading_time_extra || 0
        const totalOffloadingTime = baseOffloadingTime + extraOffloadingTime

        // Add offloading time
        currentTime = this.addMinutes(currentTime, totalOffloadingTime)
        cumulativeServiceTime += totalOffloadingTime

        const departureTime = new Date(currentTime)

        destinationETAs.push({
          destinationId: dest.id,
          tripId: trip.id,
          sequence: dest.sequence || 0,
          estimatedArrivalTime: arrivalTime.toISOString(),
          estimatedDepartureTime: departureTime.toISOString(),
          cumulativeTravelTime,
          cumulativeServiceTime
        })
      }

      // Add return to warehouse time
      if (trip.return_to_warehouse_time) {
        currentTime = this.addMinutes(currentTime, trip.return_to_warehouse_time)
        cumulativeTravelTime += trip.return_to_warehouse_time
      }

      const tripEndTime = new Date(currentTime)
      const tripDuration = (tripEndTime.getTime() - tripStartTime.getTime()) / 60000 // minutes

      tripTimings.push({
        tripId: trip.id,
        plannedStartTime: tripStartTime.toISOString(),
        plannedEndTime: tripEndTime.toISOString(),
        totalDuration: tripDuration,
        destinations: destinationETAs
      })
    }

    const totalDuration = (currentTime.getTime() - departureTime.getTime()) / 60000

    return {
      journeyId,
      departureTime: departureTime.toISOString(),
      totalPlannedDuration: totalDuration,
      estimatedCompletionTime: currentTime.toISOString(),
      trips: tripTimings
    }
  }

  /**
   * Calculate ETAs for a single trip
   */
  async calculateTripETAs(tripId: string, startTime?: Date): Promise<TripTiming> {
    const { data: trip, error: tripError } = await this.supabase
      .from('irp_trips')
      .select(`
        *,
        journey:irp_journeys(*),
        trip_destinations:irp_trip_destinations(
          *,
          destination_type:irp_destination_types(*)
        )
      `)
      .eq('id', tripId)
      .single()

    if (tripError || !trip) {
      throw new Error(`Trip not found: ${tripError?.message}`)
    }

    // If no start time provided, calculate from journey
    if (!startTime && trip.journey) {
      const journeyTiming = await this.calculateJourneyETAs(trip.journey.id)
      const tripTiming = journeyTiming.trips.find(t => t.tripId === tripId)
      if (tripTiming) return tripTiming
    }

    // Calculate standalone trip ETAs
    let currentTime = startTime || new Date()

    // Add loading time
    if (trip.loading_time) {
      currentTime = this.addMinutes(currentTime, trip.loading_time)
    }

    const tripStartTime = new Date(currentTime)
    const destinationETAs: DestinationETA[] = []

    const sortedDestinations = (trip.trip_destinations || [])
      .sort((a, b) => (a.sequence || 0) - (b.sequence || 0))

    let cumulativeTravelTime = 0
    let cumulativeServiceTime = trip.loading_time || 0

    for (const dest of sortedDestinations) {
      if (dest.time_to_location) {
        currentTime = this.addMinutes(currentTime, dest.time_to_location)
        cumulativeTravelTime += dest.time_to_location
      }

      const arrivalTime = new Date(currentTime)

      const baseOffloadingTime = dest.offloading_time || 15
      const extraOffloadingTime = dest.offloading_time_extra || 0
      const totalOffloadingTime = baseOffloadingTime + extraOffloadingTime

      currentTime = this.addMinutes(currentTime, totalOffloadingTime)
      cumulativeServiceTime += totalOffloadingTime

      destinationETAs.push({
        destinationId: dest.id,
        tripId: trip.id,
        sequence: dest.sequence || 0,
        estimatedArrivalTime: arrivalTime.toISOString(),
        estimatedDepartureTime: currentTime.toISOString(),
        cumulativeTravelTime,
        cumulativeServiceTime
      })
    }

    if (trip.return_to_warehouse_time) {
      currentTime = this.addMinutes(currentTime, trip.return_to_warehouse_time)
    }

    const tripEndTime = new Date(currentTime)
    const tripDuration = (tripEndTime.getTime() - tripStartTime.getTime()) / 60000

    return {
      tripId: trip.id,
      plannedStartTime: tripStartTime.toISOString(),
      plannedEndTime: tripEndTime.toISOString(),
      totalDuration: tripDuration,
      destinations: destinationETAs
    }
  }

  /**
   * Save calculated ETAs to database
   */
  async saveETAsToDatabase(journeyTiming: JourneyTiming): Promise<void> {
    // Update journey total planned duration
    await this.supabase
      .from('irp_journeys')
      .update({
        total_planned_duration: journeyTiming.totalPlannedDuration
      })
      .eq('id', journeyTiming.journeyId)

    // Update each trip destination with ETA
    for (const trip of journeyTiming.trips) {
      for (const dest of trip.destinations) {
        await this.supabase
          .from('irp_trip_destinations')
          .update({
            estimated_arrival_time: this.extractTime(dest.estimatedArrivalTime)
          })
          .eq('id', dest.destinationId)
      }
    }
  }

  /**
   * Recalculate ETAs when journey departure time changes
   */
  async recalculateOnDepartureTimeChange(
    journeyId: string, 
    newDepartureTime: string
  ): Promise<JourneyTiming> {
    // Update journey departure time
    await this.supabase
      .from('irp_journeys')
      .update({ planned_departure_time: newDepartureTime })
      .eq('id', journeyId)

    // Recalculate and save ETAs
    const timing = await this.calculateJourneyETAs(journeyId)
    await this.saveETAsToDatabase(timing)

    return timing
  }

  /**
   * Recalculate ETAs when driver starts journey
   */
  async recalculateOnJourneyStart(journeyId: string): Promise<JourneyTiming> {
    const now = new Date().toISOString()

    // Update journey to active with actual start time
    await this.supabase
      .from('irp_journeys')
      .update({
        status: 'active',
        actual_start_time: now
      })
      .eq('id', journeyId)

    // Recalculate ETAs based on actual start time
    const timing = await this.calculateJourneyETAs(journeyId)
    await this.saveETAsToDatabase(timing)

    return timing
  }

  /**
   * Recalculate ETAs after drag & drop reordering
   */
  async recalculateOnReorder(affectedTripIds: string[]): Promise<void> {
    // Get journey ID from first trip
    if (affectedTripIds.length === 0) return

    const { data: trip } = await this.supabase
      .from('irp_trips')
      .select('journey_id')
      .eq('id', affectedTripIds[0])
      .single()

    if (trip?.journey_id) {
      const timing = await this.calculateJourneyETAs(trip.journey_id)
      await this.saveETAsToDatabase(timing)
    }
  }

  /**
   * Helper: Combine date and time
   */
  private combineDateTime(date: string, time: string): Date {
    return new Date(`${date}T${time}`)
  }

  /**
   * Helper: Add minutes to date
   */
  private addMinutes(date: Date, minutes: number): Date {
    return new Date(date.getTime() + minutes * 60000)
  }

  /**
   * Helper: Extract time from ISO timestamp
   */
  private extractTime(isoString: string): string {
    return new Date(isoString).toTimeString().split(' ')[0]
  }
}

/**
 * Singleton instance for use across the app
 */
let etaCalculator: ETACalculator | null = null

export function getETACalculator(supabase: SupabaseClient): ETACalculator {
  if (!etaCalculator) {
    etaCalculator = new ETACalculator(supabase)
  }
  return etaCalculator
}

export default ETACalculator
