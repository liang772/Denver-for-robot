/**
 * Telegram Driver Registration API
 * Stores phone → chat_id mapping for Telegram notifications
 */

import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phone, chat_id, driver_name } = body

    if (!phone || !chat_id) {
      return NextResponse.json(
        { success: false, error: 'Phone number and chat_id are required' },
        { status: 400 }
      )
    }

    // Store registration in localStorage on client side
    // For now, return success and let client handle storage
    // In production, you would store this in a database table

    return NextResponse.json({
      success: true,
      message: 'Driver registered successfully',
      data: {
        phone,
        chat_id,
        driver_name,
        registered_at: new Date().toISOString()
      }
    })
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to register driver' 
      },
      { status: 500 }
    )
  }
}

// Get chat_id by phone number
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const phone = searchParams.get('phone')

    if (!phone) {
      return NextResponse.json(
        { success: false, error: 'Phone number is required' },
        { status: 400 }
      )
    }

    // In a real implementation, query from database
    // For now, return instruction to use localStorage
    
    return NextResponse.json({
      success: false,
      error: 'Please register this phone number first',
      instruction: 'Driver must send /register command to Telegram bot'
    })
  } catch (error) {
    console.error('Lookup error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to lookup driver' 
      },
      { status: 500 }
    )
  }
}
