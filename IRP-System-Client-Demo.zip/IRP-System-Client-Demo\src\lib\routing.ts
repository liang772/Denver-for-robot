// Routing utility functions for getting actual road routes
// Using OpenRouteService API for free routing capabilities

export interface RoutePoint {
  lat: number
  lng: number
}

export interface RouteSegment {
  coordinates: RoutePoint[]
  distance: number
  duration: number
}

export interface RouteResponse {
  segments: RouteSegment[]
  totalDistance: number
  totalDuration: number
}

// OpenRouteService API endpoint (free tier)
const ROUTING_API_URL = 'https://api.openrouteservice.org/v2/directions/driving-car'

// You'll need to get a free API key from https://openrouteservice.org/
// For development, you can use a mock implementation
const USE_MOCK_ROUTING = true

export async function getRouteBetweenPoints(
  start: RoutePoint,
  end: RoutePoint
): Promise<RouteResponse> {
  if (USE_MOCK_ROUTING) {
    return getMockRoute(start, end)
  }

  try {
    const response = await fetch(ROUTING_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': process.env.NEXT_PUBLIC_OPENROUTE_API_KEY || '',
      },
      body: JSON.stringify({
        coordinates: [
          [start.lng, start.lat],
          [end.lng, end.lat]
        ],
        format: 'geojson',
        preference: 'fastest',
        units: 'km'
      })
    })

    if (!response.ok) {
      throw new Error(`Routing API error: ${response.status}`)
    }

    const data = await response.json()
    
    // Parse OpenRouteService response
    const coordinates = data.features[0].geometry.coordinates.map((coord: [number, number]) => ({
      lng: coord[0],
      lat: coord[1]
    }))

    return {
      segments: [{
        coordinates,
        distance: data.features[0].properties.summary.distance / 1000, // Convert to km
        duration: data.features[0].properties.summary.duration / 60 // Convert to minutes
      }],
      totalDistance: data.features[0].properties.summary.distance / 1000,
      totalDuration: data.features[0].properties.summary.duration / 60
    }
  } catch (error) {
    console.error('Routing API error:', error)
    // Fallback to mock routing
    return getMockRoute(start, end)
  }
}

// Mock routing that creates realistic-looking curved paths
function getMockRoute(start: RoutePoint, end: RoutePoint): RouteResponse {
  const distance = calculateDistance(start, end)
  const duration = distance * 2 // Rough estimate: 2 min per km
  
  // Create a curved path with control points
  const midPoint = {
    lat: (start.lat + end.lat) / 2,
    lng: (start.lng + end.lng) / 2
  }
  
  // Add some offset to create a curved path
  const offset = distance * 0.1 // 10% of distance as offset
  const controlPoint = {
    lat: midPoint.lat + (Math.random() - 0.5) * offset * 0.01,
    lng: midPoint.lng + (Math.random() - 0.5) * offset * 0.01
  }
  
  // Generate points along the curved path
  const numPoints = Math.max(10, Math.floor(distance * 20)) // More points for longer distances
  const coordinates: RoutePoint[] = []
  
  for (let i = 0; i <= numPoints; i++) {
    const t = i / numPoints
    const lat = quadraticBezier(start.lat, controlPoint.lat, end.lat, t)
    const lng = quadraticBezier(start.lng, controlPoint.lng, end.lng, t)
    coordinates.push({ lat, lng })
  }
  
  return {
    segments: [{
      coordinates,
      distance,
      duration
    }],
    totalDistance: distance,
    totalDuration: duration
  }
}

// Quadratic Bezier curve calculation for smooth curved paths
function quadraticBezier(p0: number, p1: number, p2: number, t: number): number {
  return Math.pow(1 - t, 2) * p0 + 2 * (1 - t) * t * p1 + Math.pow(t, 2) * p2
}

// Calculate distance between two points using Haversine formula
function calculateDistance(point1: RoutePoint, point2: RoutePoint): number {
  const R = 6371 // Earth's radius in kilometers
  const dLat = (point2.lat - point1.lat) * Math.PI / 180
  const dLng = (point2.lng - point1.lng) * Math.PI / 180
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(point1.lat * Math.PI / 180) * Math.cos(point2.lat * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

// Get route for multiple waypoints (optimized for delivery routes)
export async function getOptimizedRoute(
  waypoints: RoutePoint[],
  returnToStart: boolean = true
): Promise<RouteResponse> {
  if (waypoints.length < 2) {
    throw new Error('Need at least 2 waypoints for routing')
  }

  const allWaypoints = returnToStart ? [...waypoints, waypoints[0]] : waypoints
  const segments: RouteSegment[] = []
  let totalDistance = 0
  let totalDuration = 0

  for (let i = 0; i < allWaypoints.length - 1; i++) {
    const segment = await getRouteBetweenPoints(allWaypoints[i], allWaypoints[i + 1])
    segments.push(segment.segments[0])
    totalDistance += segment.totalDistance
    totalDuration += segment.totalDuration
  }

  return {
    segments,
    totalDistance,
    totalDuration
  }
}
