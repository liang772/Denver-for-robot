/**
 * Daily Notification Cron Job API
 * Workflow 1: D-1 Pre-delivery Time Window Notifications
 * 
 * Should be called daily at 19:00 (7 PM) to send next-day delivery notifications
 * 
 * Setup options:
 * 1. Use a cron service like Vercel Cron Jobs
 * 2. Use GitHub Actions scheduled workflow
 * 3. Use external cron service (cron-job.org, etc.)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase'

export async function GET(request: NextRequest) {
  try {
    // Verify cron secret to prevent unauthorized access
    const authHeader = request.headers.get('authorization')
    const cronSecret = process.env.CRON_SECRET || 'your-secret-key'
    
    if (authHeader !== `Bearer ${cronSecret}`) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized' },
        { status: 401 }
      )
    }

    const supabase = createClient()
    
    // Get tomorrow's date
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    const tomorrowDate = tomorrow.toISOString().split('T')[0]

    console.log(`[Daily Cron] Running D-1 notifications for ${tomorrowDate}`)

    // Get all journeys scheduled for tomorrow
    const { data: journeys, error: journeysError } = await supabase
      .from('irp_journeys')
      .select(`
        id,
        name,
        date,
        planned_departure_time,
        trips:irp_trips(
          id,
          trip_destinations:irp_trip_destinations(
            id,
            address,
            customer_phone,
            customer_name,
            estimated_arrival_time,
            load_pallets
          )
        )
      `)
      .eq('date', tomorrowDate)
      .eq('status', 'planned')

    if (journeysError) throw journeysError

    let totalNotificationsSent = 0
    let totalErrors = 0

    // Process each journey
    for (const journey of journeys || []) {
      for (const trip of journey.trips || []) {
        for (const destination of trip.trip_destinations || []) {
          if (!destination.customer_phone) continue

          try {
            // Determine time window based on ETA
            const timeWindow = getTimeWindow(destination.estimated_arrival_time)

            // Note: In production, look up chat_id from database
            // For now, the /api/telegram/send endpoint will attempt to use phone number

            const message = `🚚 Delivery Notification

📅 Date: ${tomorrowDate}
⏰ Time Window: ${timeWindow}
📍 Address: ${destination.address}
📦 Load: ${destination.load_pallets} pallets

We'll notify you when the driver is on the way!`

            // Send Telegram notification
            const telegramResponse = await fetch(`${request.nextUrl.origin}/api/telegram/send`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                phone: destination.customer_phone,
                message: message,
                type: 'd1_notification'
              }),
            })

            if (telegramResponse.ok) {
              totalNotificationsSent++
              
              // Log notification in database
              await supabase.from('irp_notifications').insert({
                destination_id: destination.id,
                notification_type: 'd1_time_window',
                channel: 'telegram',
                recipient: destination.customer_phone,
                message: message,
                status: 'sent',
                sent_at: new Date().toISOString()
              })
            } else {
              totalErrors++
            }
          } catch (error) {
            console.error(`Failed to send notification for destination ${destination.id}:`, error)
            totalErrors++
          }
        }
      }
    }

    console.log(`[Daily Cron] Completed: ${totalNotificationsSent} sent, ${totalErrors} errors`)

    return NextResponse.json({
      success: true,
      date: tomorrowDate,
      totalNotificationsSent,
      totalErrors,
      timestamp: new Date().toISOString()
    })
  } catch (error) {
    console.error('Daily cron job error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    )
  }
}

// Determine time window based on ETA
function getTimeWindow(eta: string | null): string {
  if (!eta) return '10:00-14:00'
  
  const hour = parseInt(eta.split(':')[0])
  
  if (hour < 14) {
    return '10:00-14:00'
  } else if (hour < 18) {
    return '14:00-18:00'
  } else {
    return '18:00-20:00'
  }
}

// Also support POST for manual triggering
export async function POST(request: NextRequest) {
  return GET(request)
}
