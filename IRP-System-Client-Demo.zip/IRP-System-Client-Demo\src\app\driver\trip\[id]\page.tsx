'use client'

/**
 * Driver Trip Page
 * Phase 3.2: Driver webpage with PDF viewing and photo upload
 * 
 * This page is accessed by drivers when they reach a destination
 * Provides:
 * - PDF delivery note viewing
 * - Photo upload for proof of delivery
 * - Digital signature capture
 */

import { useState, useEffect, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { db } from '@/lib/database'
import SignatureCanvas from 'react-signature-canvas'

interface TripInfo {
  id: string
  pdf_url?: string
  signature_url?: string
  photo_urls: string[]
  status: string
  trip_destinations: Array<{
    id: string
    address: string
    customer_name?: string
    load_pallets: number
  }>
}

export default function DriverTripPage() {
  const params = useParams()
  const router = useRouter()
  const tripId = params?.id as string
  
  const [trip, setTrip] = useState<TripInfo | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [uploadingPhotos, setUploadingPhotos] = useState(false)
  const [photos, setPhotos] = useState<string[]>([])
  const [signature, setSignature] = useState<string | null>(null)
  const [completionStatus, setCompletionStatus] = useState<'incomplete' | 'uploading' | 'complete'>('incomplete')
  
  const signaturePadRef = useRef<SignatureCanvas>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (tripId) {
      fetchTripInfo()
    }
  }, [tripId])

  const fetchTripInfo = async () => {
    try {
      setIsLoading(true)

      const { data, error } = await db.supabase
        .from('irp_trips')
        .select(`
          id,
          pdf_url,
          signature_url,
          photo_urls,
          status,
          trip_destinations:irp_trip_destinations(
            id,
            address,
            customer_name,
            load_pallets
          )
        `)
        .eq('id', tripId)
        .single()

      if (error) throw error

      setTrip(data)
      setPhotos(data.photo_urls || [])
      setSignature(data.signature_url)
      
      if (data.signature_url && data.photo_urls && data.photo_urls.length > 0) {
        setCompletionStatus('complete')
      }
    } catch (error) {
      console.error('Error fetching trip info:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    try {
      setUploadingPhotos(true)
      const newPhotoUrls: string[] = []

      for (const file of Array.from(files)) {
        // Upload to Supabase Storage
        const fileName = `${tripId}/${Date.now()}_${file.name}`
        const { data, error } = await db.supabase.storage
          .from('delivery-photos')
          .upload(fileName, file)

        if (error) throw error

        // Get public URL
        const { data: { publicUrl } } = db.supabase.storage
          .from('delivery-photos')
          .getPublicUrl(fileName)

        newPhotoUrls.push(publicUrl)
      }

      // Update trip with new photos
      const updatedPhotos = [...photos, ...newPhotoUrls]
      const { error: updateError } = await db.supabase
        .from('irp_trips')
        .update({ photo_urls: updatedPhotos })
        .eq('id', tripId)

      if (updateError) throw updateError

      setPhotos(updatedPhotos)
      alert('Photos uploaded successfully!')
    } catch (error) {
      console.error('Error uploading photos:', error)
      alert('Failed to upload photos. Please try again.')
    } finally {
      setUploadingPhotos(false)
    }
  }

  const handleSignatureSave = async () => {
    if (!signaturePadRef.current) return

    try {
      const signatureDataUrl = signaturePadRef.current.toDataURL()
      
      // Convert data URL to blob
      const response = await fetch(signatureDataUrl)
      const blob = await response.blob()

      // Upload to Supabase Storage
      const fileName = `${tripId}/signature_${Date.now()}.png`
      const { data, error } = await db.supabase.storage
        .from('delivery-signatures')
        .upload(fileName, blob)

      if (error) throw error

      // Get public URL
      const { data: { publicUrl } } = db.supabase.storage
        .from('delivery-signatures')
        .getPublicUrl(fileName)

      // Update trip with signature URL
      const { error: updateError } = await db.supabase
        .from('irp_trips')
        .update({ signature_url: publicUrl })
        .eq('id', tripId)

      if (updateError) throw updateError

      setSignature(publicUrl)
      alert('Signature saved successfully!')
    } catch (error) {
      console.error('Error saving signature:', error)
      alert('Failed to save signature. Please try again.')
    }
  }

  const handleClearSignature = () => {
    if (signaturePadRef.current) {
      signaturePadRef.current.clear()
    }
  }

  const handleCompleteTrip = async () => {
    if (photos.length === 0) {
      alert('Please upload at least one photo before completing.')
      return
    }

    if (!signature) {
      alert('Please provide a signature before completing.')
      return
    }

    try {
      setCompletionStatus('uploading')

      // Update trip status to completed
      const { error } = await db.supabase
        .from('irp_trips')
        .update({
          status: 'completed',
          completed_at: new Date().toISOString()
        })
        .eq('id', tripId)

      if (error) throw error

      setCompletionStatus('complete')
      
      // Trigger next trip notifications
      // TODO: Call notification service

      alert('Trip completed successfully! ✅')
      
      // Redirect after 2 seconds
      setTimeout(() => {
        router.push('/driver/dashboard')
      }, 2000)
    } catch (error) {
      console.error('Error completing trip:', error)
      alert('Failed to complete trip. Please try again.')
      setCompletionStatus('incomplete')
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading trip details...</p>
        </div>
      </div>
    )
  }

  if (!trip) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Trip not found</h2>
          <button
            onClick={() => router.push('/driver/dashboard')}
            className="text-blue-600 hover:text-blue-700"
          >
            ← Back to Dashboard
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4 shadow-lg">
        <h1 className="text-xl font-bold">Delivery Details</h1>
        <p className="text-sm text-blue-100">Trip ID: {tripId.slice(0, 8)}</p>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Destinations */}
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Destinations</h2>
          <div className="space-y-2">
            {trip.trip_destinations.map((dest, idx) => (
              <div key={dest.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                  {idx + 1}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{dest.address}</p>
                  {dest.customer_name && (
                    <p className="text-sm text-gray-600">Customer: {dest.customer_name}</p>
                  )}
                  <p className="text-sm text-gray-600">📦 {dest.load_pallets} pallets</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* PDF Delivery Note */}
        {trip.pdf_url && (
          <div className="bg-white rounded-lg shadow-md p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-3">Delivery Note</h2>
            <a
              href={trip.pdf_url}
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full px-4 py-3 bg-blue-600 text-white text-center rounded-lg hover:bg-blue-700 font-medium"
            >
              📄 View Delivery Note PDF
            </a>
          </div>
        )}

        {/* Photo Upload */}
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">
            Proof of Delivery Photos {photos.length > 0 && `(${photos.length})`}
          </h2>
          
          {photos.length > 0 && (
            <div className="grid grid-cols-2 gap-2 mb-4">
              {photos.map((photoUrl, idx) => (
                <img
                  key={idx}
                  src={photoUrl}
                  alt={`Delivery photo ${idx + 1}`}
                  className="w-full h-32 object-cover rounded-lg border border-gray-200"
                />
              ))}
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            capture="environment"
            onChange={handlePhotoUpload}
            className="hidden"
          />
          
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadingPhotos}
            className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium disabled:bg-green-300"
          >
            {uploadingPhotos ? '⏳ Uploading...' : '📸 Take / Upload Photos'}
          </button>
        </div>

        {/* Signature Pad */}
        <div className="bg-white rounded-lg shadow-md p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Customer Signature</h2>
          
          {signature ? (
            <div>
              <img
                src={signature}
                alt="Signature"
                className="w-full border-2 border-gray-300 rounded-lg mb-2"
              />
              <p className="text-sm text-green-600 font-medium">✓ Signature captured</p>
            </div>
          ) : (
            <div>
              <div className="border-2 border-gray-300 rounded-lg bg-white mb-2">
                <SignatureCanvas
                  ref={signaturePadRef}
                  penColor="black"
                  canvasProps={{
                    className: 'w-full h-48',
                  }}
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleClearSignature}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium"
                >
                  Clear
                </button>
                <button
                  onClick={handleSignatureSave}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                >
                  Save Signature
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Complete Trip Button */}
        <button
          onClick={handleCompleteTrip}
          disabled={completionStatus !== 'incomplete' || photos.length === 0 || !signature}
          className="w-full px-6 py-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-bold text-lg disabled:bg-gray-300 disabled:cursor-not-allowed shadow-lg"
        >
          {completionStatus === 'uploading' && '⏳ Completing...'}
          {completionStatus === 'complete' && '✅ Trip Completed!'}
          {completionStatus === 'incomplete' && '✓ Complete Trip'}
        </button>

        {photos.length === 0 || !signature ? (
          <p className="text-center text-sm text-gray-500">
            Please upload photos and capture signature to complete
          </p>
        ) : null}
      </div>
    </div>
  )
}
