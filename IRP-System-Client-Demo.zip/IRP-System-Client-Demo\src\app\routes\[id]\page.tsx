'use client'

import { useState, useEffect, useCallback } from 'react'
import { useParams } from 'next/navigation'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import EditRouteDialog from '../EditRouteDialog'
import dynamic from 'next/dynamic'
import { RouteWithDestinations, TripWithDestinations, UndeliverableDestination, Truck, TripDestination } from '@/types/route'
import { openGoogleMapsTrip, copyGoogleMapsUrl } from '@/lib/google-maps'
import { db } from '@/lib/database'
import { useAuth } from '@/contexts/AuthContext'
import {
  DndContext,
  DragEndEvent,
  DragStartEvent,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  closestCorners,
  useDroppable,
} from '@dnd-kit/core'
import {
  SortableContext,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable'
import {
  useSortable,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'


// Sortable Destination Component
interface SortableDestinationProps {
  destination: TripDestination
  tripNumber: number
  isDragging?: boolean
}

function SortableDestination({ destination, isDragging }: SortableDestinationProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: isSortableDragging,
  } = useSortable({ id: destination.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isSortableDragging ? 0.5 : 1,
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`flex items-center gap-3 p-3 bg-gray-50 rounded-lg ${
        isDragging ? 'shadow-lg border-2 border-blue-300' : ''
      }`}
      {...attributes}
      {...listeners}
    >
      <div className="flex-shrink-0 w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing">
        <svg className="w-3 h-3 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h16M4 16h16" />
        </svg>
      </div>
      <div className="flex-1">
        <p className="text-sm font-medium text-gray-900">
          {destination.address}
        </p>
        <div className="flex items-center gap-4 text-xs text-gray-600 mt-1">
          <span>📦 {destination.load_pallets || 0} pallets</span>
          {destination.requires_tailgate && (
            <span className="text-orange-600 font-medium">🚛 Tailgate Required</span>
          )}
          {destination.estimated_arrival_time && (
            <span>⏰ {destination.estimated_arrival_time}</span>
          )}
        </div>
        {/* New trip tracking fields */}
        <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
          {destination.truck && (
            <span className={`px-2 py-1 rounded text-xs font-medium ${
              destination.truck.is_internal
                ? 'bg-green-100 text-green-700'
                : 'bg-orange-100 text-orange-700'
            }`}>
              🚛 {destination.truck.display_name}
              {destination.truck.is_internal ? ' (Internal)' : ' (External)'}
            </span>
          )}
          {destination.time_to_location && (
            <span>⏱️ Travel: {destination.time_to_location}min</span>
          )}
          {destination.offloading_time && (
            <span>📦 Offload: {destination.offloading_time}min</span>
          )}
          {destination.offloading_time_extra && (
            <span className="text-orange-600">+{destination.offloading_time_extra}min</span>
          )}
          {destination.address_type && (
            <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded">{destination.address_type}</span>
          )}
        </div>
      </div>
      <div className="flex-shrink-0">
        <span className="text-xs font-medium text-gray-500">#{destination.trip_order}</span>
      </div>
    </div>
  )
}

// Empty Trip Drop Zone Component
interface EmptyTripDropZoneProps {
  tripId: string
}

function EmptyTripDropZone({ tripId }: EmptyTripDropZoneProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: `empty-trip-${tripId}`,
  })

  return (
    <div
      ref={setNodeRef}
      className={`p-4 rounded-lg border-2 border-dashed transition-colors ${
        isOver
          ? 'bg-blue-50 border-blue-400'
          : 'bg-yellow-50 border-yellow-300'
      }`}
    >
      <p className={`text-sm text-center ${
        isOver ? 'text-blue-700 font-medium' : 'text-yellow-700'
      }`}>
        {isOver ? 'Drop destination here' : 'No destinations assigned to this trip yet. Drag destinations here to add them.'}
      </p>
    </div>
  )
}

// Dynamically import TripMap to avoid SSR issues with Leaflet
const TripMap = dynamic(() => import('@/components/TripMap'), {
  ssr: false,
  loading: () => (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="animate-pulse">
        <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
        <div className="h-96 bg-gray-200 rounded"></div>
      </div>
    </div>
  )
})

export default function RouteDetailsPage() {
  const params = useParams()
  const routeId = params.id as string
  const { user } = useAuth()
  
  console.log('RouteDetailsPage - User:', user)
  console.log('RouteDetailsPage - RouteId:', routeId)
  
  const [route, setRoute] = useState<RouteWithDestinations | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [trips, setTrips] = useState<TripWithDestinations[]>([])
  const [isCalculatingTrips, setIsCalculatingTrips] = useState(false)
  const [showRealtimeToast, setShowRealtimeToast] = useState(false)
  const [realtimeStatus, setRealtimeStatus] = useState<'connected' | 'connecting' | 'disconnected'>('connecting')
  const [showCopyToast, setShowCopyToast] = useState(false)
  const [isWaitingForTrips, setIsWaitingForTrips] = useState(false)
  const [tripCalculationError, setTripCalculationError] = useState<string | null>(null)
  const [undeliverableDestinations, setUndeliverableDestinations] = useState<UndeliverableDestination[]>([])
  const [isLoadingUndeliverable, setIsLoadingUndeliverable] = useState(false)
  const [showAllDestinations, setShowAllDestinations] = useState(false)
  const [showAllUndeliverable, setShowAllUndeliverable] = useState(false)
  const [showAllTrips, setShowAllTrips] = useState(false)
  
  // Edit dialog state
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  
  // Truck management state
  const [availableTrucks, setAvailableTrucks] = useState<Truck[]>([])
  const [selectedTrucks, setSelectedTrucks] = useState<{[truckId: string]: number}>({})
  const [isLoadingTrucks, setIsLoadingTrucks] = useState(true)
  
  // Trucker working hours state
  const [truckerWorkingHours, setTruckerWorkingHours] = useState<number>(12.0)
  
  // Drag and drop state
  const [activeId, setActiveId] = useState<string | null>(null)

  // Destination editing state
  const [editingDestinationId, setEditingDestinationId] = useState<string | null>(null)
  const [editingAddress, setEditingAddress] = useState<string>('')
  const [isSavingAddress, setIsSavingAddress] = useState(false)
  
  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  )

  // Calculate total distance for all trips
  const calculateTotalDistance = () => {
    if (!trips.length || !route) return 0

    let totalDistance = 0

    trips.forEach(trip => {
      const destinations = trip.trip_destinations?.sort((a, b) => a.trip_order - b.trip_order) || []
      
      // Add distance from departure address to first destination
      if (destinations.length > 0 && route.departure_latitude && route.departure_longitude) {
        const firstDest = destinations[0]
        if (firstDest.latitude && firstDest.longitude) {
          totalDistance += calculateDistance(
            { lat: route.departure_latitude, lng: route.departure_longitude },
            { lat: firstDest.latitude, lng: firstDest.longitude }
          )
        }
      }

      // Add distances between consecutive destinations
      for (let i = 0; i < destinations.length - 1; i++) {
        const current = destinations[i]
        const next = destinations[i + 1]
        
        if (current.latitude && current.longitude && next.latitude && next.longitude) {
          totalDistance += calculateDistance(
            { lat: current.latitude, lng: current.longitude },
            { lat: next.latitude, lng: next.longitude }
          )
        }
      }
    })

    return totalDistance
  }

  // Calculate total time for all trips
  const calculateTotalTime = () => {
    if (!trips.length) return 0

    const totalMinutes = trips.reduce((sum, trip) => {
      return sum + (trip.estimated_duration || 0)
    }, 0)

    return (totalMinutes / 60).toFixed(1)
  }

  // Calculate estimated time with parallel truck operations
  const calculateParallelDeliveryTime = () => {
    if (!trips.length) return 0

    // Get total number of selected trucks
    const totalSelectedTrucks = Object.values(selectedTrucks).reduce((sum, count) => sum + count, 0)
    if (totalSelectedTrucks <= 0) return 0

    // Sort trips by duration (longest first) for optimal distribution
    const sortedTrips = [...trips].sort((a, b) => (b.estimated_duration || 0) - (a.estimated_duration || 0))
    
    // Distribute trips across trucks using a simple bin packing approach
    const truckLoads = new Array(totalSelectedTrucks).fill(0)
    
    sortedTrips.forEach(trip => {
      // Find the truck with the least current load
      const minLoadIndex = truckLoads.indexOf(Math.min(...truckLoads))
      truckLoads[minLoadIndex] += trip.estimated_duration || 0
    })
    
    // The longest truck load determines the total delivery time
    const maxLoad = Math.max(...truckLoads)
    
    return (maxLoad / 60).toFixed(1)
  }

  // Get total number of selected trucks
  const getTotalSelectedTrucks = () => {
    return Object.values(selectedTrucks).reduce((sum, count) => sum + count, 0)
  }

  // Fetch available trucks
  const fetchTrucks = useCallback(async () => {
    if (!user) {
      console.log('No user found, cannot fetch trucks')
      return
    }
    
    try {
      console.log('Fetching trucks for user:', user.id)
      setIsLoadingTrucks(true)
      const trucksData = await db.getUserTrucks(user.id)
      console.log('Trucks data received:', trucksData)
      setAvailableTrucks(trucksData)
      
      // Initialize selected trucks with default values (1 truck of each type if available)
      const initialSelection: {[truckId: string]: number} = {}
      trucksData.forEach(truck => {
        if (truck.available_count > 0) {
          initialSelection[truck.id] = 1
        }
      })
      console.log('Initial truck selection:', initialSelection)
      setSelectedTrucks(initialSelection)
    } catch (error) {
      console.error('Error fetching trucks:', error)
    } finally {
      setIsLoadingTrucks(false)
    }
  }, [user])

  // Handle truck quantity change
  const handleTruckQuantityChange = (truckId: string, quantity: number) => {
    setSelectedTrucks(prev => ({
      ...prev,
      [truckId]: Math.max(0, Math.min(quantity, availableTrucks.find(t => t.id === truckId)?.available_count || 0))
    }))
  }

  // Status indicator functions
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'planned':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active'
      case 'completed':
        return 'Completed'
      case 'planned':
        return 'Planned'
      case 'cancelled':
        return 'Cancelled'
      default:
        return 'Unknown'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
        )
      case 'completed':
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        )
      case 'planned':
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
          </svg>
        )
      case 'cancelled':
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        )
      default:
        return (
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
        )
    }
  }

  // Edit dialog handlers
  const handleEditRoute = () => {
    setIsEditDialogOpen(true)
  }

  const handleCloseEditDialog = () => {
    setIsEditDialogOpen(false)
  }

  const handleRouteUpdated = async () => {
    // Refresh route data after edit
    if (routeId) {
      try {
        const updatedRoute = await db.getRouteById(routeId)
        // Update the route state with the new data
        setRoute(prev => prev ? { ...prev, ...updatedRoute } : null)
      } catch (error) {
        console.error('Error refreshing route data:', error)
      }
    }
  }

  // Destination address editing handlers
  const handleStartEditingAddress = (destinationId: string, currentAddress: string) => {
    setEditingDestinationId(destinationId)
    setEditingAddress(currentAddress)
  }

  const handleCancelEditingAddress = () => {
    setEditingDestinationId(null)
    setEditingAddress('')
  }

  const handleSaveAddress = async (destinationId: string) => {
    if (!editingAddress.trim()) {
      alert('Address cannot be empty')
      return
    }

    setIsSavingAddress(true)
    try {
      // Update the destination in Supabase
      await db.updateDestination(destinationId, {
        address: editingAddress.trim()
      })

      // Update the local state
      setRoute(prev => {
        if (!prev) return prev
        return {
          ...prev,
          destinations: prev.destinations.map(dest =>
            dest.id === destinationId
              ? { ...dest, address: editingAddress.trim() }
              : dest
          )
        }
      })

      // Clear editing state
      setEditingDestinationId(null)
      setEditingAddress('')
    } catch (error) {
      console.error('Error updating destination address:', error)
      alert('Failed to update destination address. Please try again.')
    } finally {
      setIsSavingAddress(false)
    }
  }

  // Temporary function to create test trucks
  const createTestTrucks = async () => {
    if (!user) return
    
    try {
      console.log('Creating test trucks for user:', user.id)
      
      const testTrucks = [
        {
          user_id: user.id,
          display_name: 'Company Truck #1',
          is_internal: true,
          capacity_pallets: 24.5,
          available_count: 2,
          vehicle_type: 'standard'
        },
        {
          user_id: user.id,
          display_name: 'Company Truck #2',
          is_internal: true,
          capacity_pallets: 18.0,
          available_count: 1,
          vehicle_type: 'tailgate'
        },
        {
          user_id: user.id,
          display_name: 'Contractor Truck #1',
          is_internal: false,
          capacity_pallets: 30.0,
          available_count: 1,
          vehicle_type: 'refrigerated',
          contractor_name: 'ABC Logistics',
          contractor_rate: 150.00
        }
      ]
      
      for (const truckData of testTrucks) {
        await db.createTruck(truckData)
        console.log('Created truck:', truckData.display_name)
      }
      
      // Refresh trucks after creating
      await fetchTrucks()
      console.log('Test trucks created successfully')
    } catch (error) {
      console.error('Error creating test trucks:', error)
    }
  }

  // Calculate distance between two coordinates using Haversine formula
  const calculateDistance = (point1: { lat: number, lng: number }, point2: { lat: number, lng: number }) => {
    const R = 6371 // Earth's radius in kilometers
    const dLat = (point2.lat - point1.lat) * Math.PI / 180
    const dLng = (point2.lng - point1.lng) * Math.PI / 180
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(point1.lat * Math.PI / 180) * Math.cos(point2.lat * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
    return R * c
  }

  // Calculate distance for a specific trip
  const calculateTripDistance = (trip: TripWithDestinations) => {
    if (!trip.trip_destinations || trip.trip_destinations.length === 0 || !route) return 0

    const destinations = trip.trip_destinations?.sort((a, b) => a.trip_order - b.trip_order) || []
    let totalDistance = 0

    // Add distance from departure address to first destination
    if (destinations.length > 0 && route.departure_latitude && route.departure_longitude) {
      const firstDest = destinations[0]
      if (firstDest.latitude && firstDest.longitude) {
        totalDistance += calculateDistance(
          { lat: route.departure_latitude, lng: route.departure_longitude },
          { lat: firstDest.latitude, lng: firstDest.longitude }
        )
      }
    }

    // Add distances between consecutive destinations
    for (let i = 0; i < destinations.length - 1; i++) {
      const current = destinations[i]
      const next = destinations[i + 1]
      
      if (current.latitude && current.longitude && next.latitude && next.longitude) {
        totalDistance += calculateDistance(
          { lat: current.latitude, lng: current.longitude },
          { lat: next.latitude, lng: next.longitude }
        )
      }
    }

    return totalDistance
  }

  // Calculate time for a specific trip
  const calculateTripTime = (trip: TripWithDestinations) => {
    const durationMinutes = trip.estimated_duration || 0
    return (durationMinutes / 60).toFixed(1)
  }

  // Fetch undeliverable destinations
  const fetchUndeliverableDestinations = useCallback(async () => {
      if (!routeId) return
      
      try {
      setIsLoadingUndeliverable(true)
      const undeliverable = await db.getUndeliverableDestinations(routeId)
      setUndeliverableDestinations(undeliverable || [])
    } catch (error) {
      console.error('Error fetching undeliverable destinations:', error)
    } finally {
      setIsLoadingUndeliverable(false)
    }
  }, [routeId])

  // Refresh trips data from database
  const refreshTripsData = useCallback(async () => {
    if (!routeId) return

    try {
      console.log('Refreshing trips data from database...')
      const updatedTrips = await db.getRouteTrips(routeId)
      if (updatedTrips) {
        console.log('Fetched trips from database:', updatedTrips.length, 'trips')
        // Enrich trips with truck data
        const enrichedTrips = await db.enrichTripsWithTruckData(updatedTrips)
        console.log('First trip destinations:', enrichedTrips[0]?.trip_destinations?.map((d: TripDestination) => ({ id: d.id, order: d.trip_order })))
        setTrips(enrichedTrips)
        console.log('Trips state updated successfully')

        // Force a re-render by updating the trips state again
        setTimeout(() => {
          setTrips([...enrichedTrips])
          console.log('Forced trips state update')
        }, 100)
      } else {
        console.log('No trips data received from database')
      }
    } catch (error) {
      console.error('Error refreshing trips data:', error)
    }
  }, [routeId])

  // Drag and drop handlers
  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string)
  }

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event
    console.log('Drag end event:', { activeId: active.id, overId: over?.id })
    setActiveId(null)

    if (!over || active.id === over.id) {
      console.log('No valid drop target or same position')
      return
    }

    try {
      // Find the source trip and destination
      let sourceTrip: TripWithDestinations | null = null
      let sourceDestination: TripDestination | null = null
      let sourceIndex = -1

      for (const trip of trips) {
        if (trip.trip_destinations) {
          const index = trip.trip_destinations.findIndex(dest => dest.id === active.id)
          if (index !== -1) {
            sourceTrip = trip
            sourceDestination = trip.trip_destinations[index]
            sourceIndex = index
            break
          }
        }
      }

      if (!sourceTrip || !sourceDestination) {
        console.log('Source trip or destination not found')
        return
      }

      console.log('Source found:', { sourceTripId: sourceTrip.id, sourceDestinationId: sourceDestination.id, sourceIndex })

      // Check if dropping onto an empty trip drop zone
      const overId = String(over.id)
      const isEmptyTripDrop = overId.startsWith('empty-trip-')

      // Find the target trip and destination
      let targetTrip: TripWithDestinations | null = null
      let targetIndex = -1

      if (isEmptyTripDrop) {
        // Dropping onto an empty trip
        const targetTripId = overId.replace('empty-trip-', '')
        targetTrip = trips.find(trip => trip.id === targetTripId) || null
        targetIndex = 0 // First position in empty trip
        console.log('Dropping onto empty trip:', { targetTripId, targetTrip })
      } else {
        // Dropping onto an existing destination
        for (const trip of trips) {
          if (trip.trip_destinations) {
            const index = trip.trip_destinations.findIndex(dest => dest.id === over.id)
            if (index !== -1) {
              targetTrip = trip
              targetIndex = index
              break
            }
          }
        }
      }

      if (!targetTrip) {
        console.log('Target trip not found for over.id:', over.id)
        return
      }

      console.log('Target found:', { targetTripId: targetTrip.id, targetIndex, isEmptyTripDrop })
      
      if (sourceTrip.id === targetTrip.id) {
        // Reordering within the same trip
        console.log('Reordering within same trip')
        const reorderedDestinations = arrayMove(
          sourceTrip.trip_destinations || [],
          sourceIndex,
          targetIndex
        )
        
        // Update trip_order for all destinations
        const newDestinations = reorderedDestinations.map((dest, index) => ({
          ...dest,
          trip_order: index + 1
        }))
        
        console.log('New destinations order:', newDestinations.map(d => ({ id: d.id, order: d.trip_order })))
        
        // Update trip destinations with new order
        const updatedTrips = trips.map(trip => 
          trip.id === sourceTrip!.id 
            ? { ...trip, trip_destinations: newDestinations }
            : trip
        )
        
        setTrips(updatedTrips)
        
        // Update database
        try {
          await updateTripDestinationOrder(sourceTrip.id, newDestinations)
          console.log('Database updated successfully for within-trip reordering')
          // Refresh trips data from database to ensure UI reflects actual data
          await refreshTripsData()
        } catch (error) {
          console.error('Failed to update database for within-trip reordering:', error)
          // Revert the UI changes
          setTrips(trips)
        }
      } else {
        // Moving between different trips
        console.log('Moving between different trips')

        // Remove from source trip and update order
        const sourceDestinations = (sourceTrip.trip_destinations || [])
          .filter(dest => dest.id !== active.id)
          .map((dest, index) => ({ ...dest, trip_order: index + 1 }))

        // Add to target trip at the target position and update order
        const targetDestinations = [...(targetTrip.trip_destinations || [])]
        targetDestinations.splice(targetIndex, 0, { ...sourceDestination, trip_order: targetIndex + 1 })

        // Update trip_order for all destinations in target trip
        const updatedTargetDestinations = targetDestinations.map((dest, index) => ({
          ...dest,
          trip_order: index + 1
        }))

        // Calculate new total loads
        const newSourceLoad = sourceDestinations.reduce((sum, dest) => sum + (dest.load_pallets || 0), 0)
        const newTargetLoad = updatedTargetDestinations.reduce((sum, dest) => sum + (dest.load_pallets || 0), 0)

        console.log('Source destinations:', sourceDestinations.map(d => ({ id: d.id, order: d.trip_order })))
        console.log('Target destinations:', updatedTargetDestinations.map(d => ({ id: d.id, order: d.trip_order })))
        console.log('Capacity changes:', {
          sourceOldLoad: sourceTrip.total_load,
          sourceNewLoad: newSourceLoad,
          targetOldLoad: targetTrip.total_load,
          targetNewLoad: newTargetLoad
        })

        // Check if target trip exceeds truck capacity
        const targetTruckCapacity = targetTrip.truck?.capacity_pallets
        const capacityExceeded = targetTruckCapacity && newTargetLoad > targetTruckCapacity

        if (capacityExceeded) {
          console.warn(`Warning: Target trip ${targetTrip.trip_number} capacity exceeded!`, {
            capacity: targetTruckCapacity,
            newLoad: newTargetLoad,
            excess: newTargetLoad - targetTruckCapacity
          })
        }

        // Update trips state with new loads and destination counts
        const updatedTrips = trips.map(trip => {
          if (trip.id === sourceTrip!.id) {
            return {
              ...trip,
              trip_destinations: sourceDestinations,
              total_load: newSourceLoad,
              destination_count: sourceDestinations.length
            }
          } else if (trip.id === targetTrip.id) {
            return {
              ...trip,
              trip_destinations: updatedTargetDestinations,
              total_load: newTargetLoad,
              destination_count: updatedTargetDestinations.length
            }
          }
          return trip
        })

        setTrips(updatedTrips)

        // Update database
        try {
          await moveDestinationBetweenTrips(
            sourceDestination.id,
            sourceTrip.id,
            targetTrip.id,
            sourceDestinations,
            updatedTargetDestinations,
            newSourceLoad,
            newTargetLoad
          )
          console.log('Database updated successfully for between-trip reordering')
          // Refresh trips data from database to ensure UI reflects actual data
          await refreshTripsData()

          // Show capacity warning if exceeded
          if (capacityExceeded) {
            alert(`⚠️ Warning: Trip ${targetTrip.trip_number} now has ${newTargetLoad.toFixed(1)} pallets, which exceeds the truck capacity of ${targetTruckCapacity} pallets. The trip has been updated, but you may need to reassign destinations or use a different truck.`)
          }
        } catch (error) {
          console.error('Failed to update database for between-trip reordering:', error)
          // Revert the UI changes
          setTrips(trips)
        }
      }
      
      // Map will refresh automatically when trips state updates
      
    } catch (err) {
      console.error('Error reordering destinations:', err)
    }
  }

  // Database update functions
  const updateTripDestinationOrder = async (tripId: string, destinations: TripDestination[]) => {
    try {
      console.log('Updating database with destinations:', destinations.map(d => ({ id: d.id, trip_order: d.trip_order })))
      
      // Step 1: Set all destinations to temporary negative values to avoid constraint violations
      for (let i = 0; i < destinations.length; i++) {
        await db.updateTripDestination(destinations[i].id, { trip_order: -(i + 1) })
      }
      
      // Step 2: Set all destinations to their final positive values
      for (let i = 0; i < destinations.length; i++) {
        await db.updateTripDestination(destinations[i].id, { trip_order: destinations[i].trip_order })
      }
      
      console.log('All destinations updated successfully')
    } catch (error) {
      console.error('Error updating trip destination order:', error)
      throw error
    }
  }


  const moveDestinationBetweenTrips = async (
    destinationId: string,
    fromTripId: string,
    toTripId: string,
    sourceDestinations: TripDestination[],
    targetDestinations: TripDestination[],
    newSourceLoad: number,
    newTargetLoad: number
  ) => {
    try {
      console.log('Moving destination between trips:', { destinationId, fromTripId, toTripId })

      // Find the destination being moved
      const movedDestination = targetDestinations.find(dest => dest.id === destinationId)
      if (!movedDestination) {
        throw new Error('Destination not found in target destinations')
      }

      // Step 1: Set ALL destinations in both trips to very negative values to avoid any conflicts
      // Use very negative values to ensure no conflicts with existing positive values
      const veryNegativeStart = -10000

      // Update source trip destinations (excluding the moved one)
      const sourceDestinationsToUpdate = sourceDestinations.filter(dest => dest.id !== destinationId)
      for (let i = 0; i < sourceDestinationsToUpdate.length; i++) {
        await db.updateTripDestination(sourceDestinationsToUpdate[i].id, { trip_order: veryNegativeStart - i })
      }

      // Update target trip destinations
      for (let i = 0; i < targetDestinations.length; i++) {
        await db.updateTripDestination(targetDestinations[i].id, { trip_order: veryNegativeStart - i - 1000 })
      }

      // Step 2: Update the moved destination's trip_id and trip_order
      await db.updateTripDestination(destinationId, {
        trip_id: toTripId,
        trip_order: movedDestination.trip_order
      })

      // Step 3: Set all destinations to their final positive values
      // Source trip destinations (excluding the moved one)
      for (const dest of sourceDestinationsToUpdate) {
        await db.updateTripDestination(dest.id, { trip_order: dest.trip_order })
      }

      // Target trip destinations
      for (const dest of targetDestinations) {
        await db.updateTripDestination(dest.id, { trip_order: dest.trip_order })
      }

      // Step 4: Update trip total_load and destination_count
      await db.updateTrip(fromTripId, {
        total_load: newSourceLoad,
        // destination_count is updated automatically via trigger or we update it here
      })

      await db.updateTrip(toTripId, {
        total_load: newTargetLoad,
        // destination_count is updated automatically via trigger or we update it here
      })

      console.log('All destinations and trip loads updated successfully for between-trip move')
    } catch (error) {
      console.error('Error moving destination between trips:', error)
      throw error
    }
  }

  // Handle trip calculation
  const handleCalculateTrips = async () => {
    if (!route || !route.destinations || route.destinations.length === 0) return
    
    setIsCalculatingTrips(true)
    setTripCalculationError(null) // Clear any previous errors
    
    try {
      // Prepare truck data for API call
      const truckData = Object.entries(selectedTrucks)
        .filter(([, count]) => count > 0)
        .map(([truckId, count]) => {
          const truck = availableTrucks.find(t => t.id === truckId)
          return {
            truck_id: truckId,
            count: count,
            capacity_pallets: truck?.capacity_pallets || 0,
            vehicle_type: truck?.vehicle_type || 'standard'
          }
        })

      console.log('Sending truck data to API:', truckData)

      // Call our internal API to calculate trips (which proxies to external API)
      const response = await fetch(`/api/calculate-trips?route_id=${routeId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          trucks: truckData,
          trucker_working_hours: truckerWorkingHours
        }) // Send truck data and working hours in body
      })
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || `API call failed: ${response.status} ${response.statusText}`)
      }
      
      const result = await response.json()
      console.log('Trip calculation API called successfully:', result)
      
      // Set waiting state to show loading placeholders
      setIsWaitingForTrips(true)
      
      // The API will update the database, so we'll wait for real-time updates
      // or we can poll for updates. For now, we'll show loading state
      // and let the real-time subscription handle the updates
      
    } catch (error) {
      console.error('Error calculating trips:', error)
      setTripCalculationError(error instanceof Error ? error.message : 'Failed to calculate trips')
    } finally {
      setIsCalculatingTrips(false)
    }
  }

  // Handle trip recalculation
  const handleRecalculateTrips = async () => {
    if (!route || !route.destinations || route.destinations.length === 0) return
    
    // Show confirmation dialog
    if (!confirm('Are you sure you want to recalculate trips? This will delete all existing trips and undeliverable destinations, then create new ones.')) {
      return
    }
    
    setIsCalculatingTrips(true)
    setTripCalculationError(null) // Clear any previous errors
    
    try {
      // First, delete existing trips and undeliverable destinations
      await Promise.all([
        db.deleteRouteTrips(routeId),
        db.deleteRouteUndeliverableDestinations(routeId)
      ])
      
      // Clear trips and undeliverable destinations from state immediately
      setTrips([])
      setUndeliverableDestinations([])
      
      // Prepare truck data for API call
      const truckData = Object.entries(selectedTrucks)
        .filter(([, count]) => count > 0)
        .map(([truckId, count]) => {
          const truck = availableTrucks.find(t => t.id === truckId)
          return {
            truck_id: truckId,
            count: count,
            capacity_pallets: truck?.capacity_pallets || 0,
            vehicle_type: truck?.vehicle_type || 'standard'
          }
        })

      console.log('Recalculating with truck data:', truckData)

      // Then call the API to calculate new trips
      const response = await fetch(`/api/calculate-trips?route_id=${routeId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          trucks: truckData,
          trucker_working_hours: truckerWorkingHours
        }) // Send truck data and working hours in body
      })
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.error || `API call failed: ${response.status} ${response.statusText}`)
      }
      
      const result = await response.json()
      console.log('Trip recalculation API called successfully:', result)
      
      // Set waiting state to show loading placeholders
      setIsWaitingForTrips(true)
      
      // The API will update the database, so we'll wait for real-time updates
      // or we can poll for updates. For now, we'll show loading state
      // and let the real-time subscription handle the updates
      
    } catch (error) {
      console.error('Error recalculating trips:', error)
      setTripCalculationError(error instanceof Error ? error.message : 'Failed to recalculate trips')
    } finally {
      setIsCalculatingTrips(false)
    }
  }

  useEffect(() => {
    const fetchRouteData = async () => {
      if (!routeId || !user) return

      try {
        setIsLoading(true)

        // Fetch route with destinations from Supabase
        const routeData = await db.getRouteById(routeId)

        if (routeData) {
          setRoute(routeData)

          // Fetch trips for this route
          const routeTrips = await db.getRouteTrips(routeId)
          if (routeTrips) {
            // Enrich trips with truck data
            const enrichedTrips = await db.enrichTripsWithTruckData(routeTrips)
            setTrips(enrichedTrips)

            // Check for and fix any stuck destinations
            try {
              console.log('Checking for stuck destinations...')
              const allTrips = await db.getRouteTrips(routeId)
              if (allTrips) {
                let hasStuckDestinations = false
                for (const trip of allTrips) {
                  if (trip.trip_destinations) {
                    for (const dest of trip.trip_destinations) {
                      if (dest.trip_order < 0) {
                        hasStuckDestinations = true
                        console.log(`Found stuck destination: ${dest.id} with trip_order: ${dest.trip_order}`)
                      }
                    }
                  }
                }

                if (hasStuckDestinations) {
                  console.log('Fixing stuck destinations...')
                  // Refresh trips data to get the latest state
                  const updatedTrips = await db.getRouteTrips(routeId)
                  if (updatedTrips) {
                    const enrichedTrips = await db.enrichTripsWithTruckData(updatedTrips)
                    setTrips(enrichedTrips)
                  }
                }
              }
            } catch (error) {
              console.error('Error fixing stuck destinations:', error)
            }
          }

          // Fetch undeliverable destinations for this route
          try {
            setIsLoadingUndeliverable(true)
            const undeliverable = await db.getUndeliverableDestinations(routeId)
            setUndeliverableDestinations(undeliverable || [])
          } catch (error) {
            console.error('Error fetching undeliverable destinations:', error)
          } finally {
            setIsLoadingUndeliverable(false)
          }
        } else {
          console.error('Route not found')
        }

        // Fetch available trucks
        try {
          console.log('Fetching trucks for user:', user.id)
          setIsLoadingTrucks(true)
          const trucksData = await db.getUserTrucks(user.id)
          console.log('Trucks data received:', trucksData)
          setAvailableTrucks(trucksData)

          // Initialize selected trucks with default values (1 truck of each type if available)
          const initialSelection: {[truckId: string]: number} = {}
          trucksData.forEach(truck => {
            if (truck.available_count > 0) {
              initialSelection[truck.id] = 1
            }
          })
          console.log('Initial truck selection:', initialSelection)
          setSelectedTrucks(initialSelection)
        } catch (error) {
          console.error('Error fetching trucks:', error)
        } finally {
          setIsLoadingTrucks(false)
        }
      } catch (err) {
        console.error('Error fetching route:', err)
      } finally {
        setIsLoading(false)
      }
    }

    fetchRouteData()
    // Only depend on user?.id to avoid re-fetching when user object reference changes
    // but actual user hasn't changed (e.g., on tab switch)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routeId, user?.id])

  // Real-time subscription to trips
  // Note: We subscribe only to trips table changes since getRouteTrips()
  // fetches both trips and their destinations together, ensuring we get
  // complete data updates when any trip-related change occurs
  useEffect(() => {
    if (!routeId) return

    // Subscribe to real-time updates
    const subscription = db.subscribeToRouteTrips(routeId, async (payload) => {
      console.log('Real-time update received:', payload)
      
      // Refresh trips data when changes occur
      try {
        const updatedTrips = await db.getRouteTrips(routeId)
        if (updatedTrips) {
          // Enrich trips with truck data
          const enrichedTrips = await db.enrichTripsWithTruckData(updatedTrips)
          setTrips(enrichedTrips)
          // Clear waiting state if we were waiting for trips
          if (isWaitingForTrips) {
            setIsWaitingForTrips(false)
          }
          // Clear any trip calculation errors
          setTripCalculationError(null)
          // Show toast notification for relevant updates
          setShowRealtimeToast(true)
          setTimeout(() => setShowRealtimeToast(false), 3000)
        }
      } catch (error) {
        console.error('Error refreshing trips after real-time update:', error)
      }
    })

    // Handle subscription status
    subscription.on('presence', { event: 'sync' }, () => {
      setRealtimeStatus('connected')
    })

    subscription.on('presence', { event: 'join' }, () => {
      setRealtimeStatus('connected')
    })

    subscription.on('presence', { event: 'leave' }, () => {
      setRealtimeStatus('disconnected')
    })

    // Set initial status
    setRealtimeStatus('connected')

    // Cleanup subscription on unmount
    return () => {
      db.unsubscribeFromRouteTrips(routeId)
    }
  }, [routeId, isWaitingForTrips])

  if (isLoading) {
    return (
      <ProtectedRoute>
        <Layout currentPage="Routes">
          <div className="p-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="animate-pulse">
                <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
                <div className="space-y-4">
                  <div className="h-20 bg-gray-200 rounded"></div>
                  <div className="h-20 bg-gray-200 rounded"></div>
                  <div className="h-20 bg-gray-200 rounded"></div>
                  <div className="h-20 bg-gray-200 rounded"></div>
                </div>
              </div>
            </div>
          </div>
        </Layout>
      </ProtectedRoute>
    )
  }

  if (!route) {
    return (
      <ProtectedRoute>
        <Layout currentPage="Routes">
          <div className="p-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-center">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-gray-900">Route not found</h3>
                <p className="mt-1 text-sm text-gray-500">
                  The route you&apos;re looking for doesn&apos;t exist.
                </p>
              </div>
            </div>
          </div>
        </Layout>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Routes">
        <div className="p-6">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Singapore Central Delivery Route</h1>
                <p className="text-gray-600">Route ID: {route.id}</p>
                <div className="mt-2">
                  <span className={`inline-flex items-center gap-2 px-3 py-1.5 text-sm font-medium rounded-full border ${getStatusColor(route.status)}`}>
                    {getStatusIcon(route.status)}
                    {getStatusText(route.status)}
                  </span>
                </div>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={handleEditRoute}
                  className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Edit Route
                </button>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  Export Route
                </button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Route Information */}
            <div className="lg:col-span-2 space-y-6">
              {/* Route Overview */}
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Route Overview</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Route Date
                    </label>
                    <p className="text-gray-900">{new Date(route.date).toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Total Destinations
                    </label>
                    <p className="text-gray-900">{route.destinations.length} stops</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Total Load
                    </label>
                    <p className="text-gray-900">
                      {route.destinations.reduce((total, dest) => {
                        const pallets = dest.load_pallets || 0
                        return total + pallets
                      }, 0).toFixed(1)} pallets
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center gap-1.5 px-2 py-1 text-xs font-medium rounded-full border ${getStatusColor(route.status)}`}>
                        {getStatusIcon(route.status)}
                        {getStatusText(route.status)}
                      </span>
                    </div>
                  </div>

                </div>
              </div>

              {/* Departure Address */}
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Departure Point</h2>
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">Starting Point</p>
                    <p className="text-gray-600">{route.departure_address}</p>
                  </div>
                </div>
              </div>

              {/* Destinations */}
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">Destinations</h2>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">
                      {route.destinations.length} destination{route.destinations.length !== 1 ? 's' : ''}
                    </span>
                    {route.destinations.length > 5 && (
                      <button
                        onClick={() => setShowAllDestinations(!showAllDestinations)}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                      >
                        {showAllDestinations ? 'Show Less' : `Show All (${route.destinations.length})`}
                      </button>
                    )}
                  </div>
                </div>
                <div className="space-y-4">
                  {(showAllDestinations ? route.destinations : route.destinations.slice(0, 5)).map((destination) => (
                    <div key={destination.id} className="flex items-start gap-3 p-4 border border-gray-200 rounded-lg">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-blue-600">{destination.priority}</span>
                      </div>
                      <div className="flex-1">
                        {editingDestinationId === destination.id ? (
                          <div className="mb-2">
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={editingAddress}
                                onChange={(e) => setEditingAddress(e.target.value)}
                                className="flex-1 px-3 py-2 border border-blue-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Enter address"
                                disabled={isSavingAddress}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    handleSaveAddress(destination.id)
                                  } else if (e.key === 'Escape') {
                                    handleCancelEditingAddress()
                                  }
                                }}
                                autoFocus
                              />
                              <button
                                onClick={() => handleSaveAddress(destination.id)}
                                disabled={isSavingAddress}
                                className="px-3 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                {isSavingAddress ? 'Saving...' : 'Save'}
                              </button>
                              <button
                                onClick={handleCancelEditingAddress}
                                disabled={isSavingAddress}
                                className="px-3 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                Cancel
                              </button>
                            </div>
                          </div>
                        ) : (
                          <p className="text-sm font-medium text-gray-900 mb-1">
                            Stop {destination.priority}: {destination.address}
                          </p>
                        )}
                                                  <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-2">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              <span>Preferred delivery: {destination.preferred_delivery_time_start || 'Flexible'}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                              </svg>
                              <span className="font-medium text-blue-600">📦 {destination.load_pallets || 0} pallets</span>
                              {destination.load_info && destination.load_info !== `${destination.load_pallets || 0} pallets` && (
                                <span className="text-gray-500">({destination.load_info})</span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7v10l8 4" />
                              </svg>
                              <span className={`font-medium ${destination.requires_tailgate ? 'text-orange-600' : 'text-gray-500'}`}>
                                {destination.requires_tailgate ? 'Tailgate Required' : 'No Tailgate'}
                              </span>
                            </div>
                          </div>
                      </div>
                      <div className="flex-shrink-0 flex flex-col gap-1">
                        <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                          View Details
                        </button>
                        <button
                          onClick={() => handleStartEditingAddress(destination.id, destination.address)}
                          className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          Edit
                        </button>
                      </div>
                    </div>
                  ))}
                  
                  {/* Show More Indicator for Destinations */}
                  {!showAllDestinations && route.destinations.length > 5 && (
                    <div className="text-center py-4 border-t border-gray-200">
                      <button
                        onClick={() => setShowAllDestinations(true)}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center justify-center gap-2 mx-auto"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                        Show {route.destinations.length - 5} more destinations
                      </button>
                </div>
                  )}
              </div>
              </div>

              {/* Undeliverable Destinations */}
              {isLoadingUndeliverable ? (
                <div className="bg-white rounded-lg shadow p-6">
                  <div className="animate-pulse">
                    <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
                    <div className="space-y-4">
                      <div className="h-24 bg-gray-200 rounded"></div>
                      <div className="h-24 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                </div>
              ) : undeliverableDestinations.length > 0 && (
                <div className="bg-white rounded-lg shadow p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-900">Undeliverable Destinations</h2>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      <span className="text-sm text-red-600 font-medium">
                        {undeliverableDestinations.length} destination{undeliverableDestinations.length !== 1 ? 's' : ''}
                      </span>
                      {undeliverableDestinations.length > 5 && (
                        <button
                          onClick={() => setShowAllUndeliverable(!showAllUndeliverable)}
                          className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                        >
                          {showAllUndeliverable ? 'Show Less' : `Show All (${undeliverableDestinations.length})`}
                        </button>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    {(showAllUndeliverable ? undeliverableDestinations : undeliverableDestinations.slice(0, 5)).map((destination) => (
                      <div key={destination.id} className="flex items-start gap-3 p-4 border border-red-200 rounded-lg bg-red-50">
                        <div className="flex-shrink-0 w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                          <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                          </svg>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="text-sm font-medium text-gray-900 mb-1">
                                {destination.address}
                              </p>
                              <div className="flex items-center gap-4 text-sm text-gray-600">
                                <div className="flex items-center gap-2">
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                                  </svg>
                                  <span>Load: {destination.load_pallets} pallets</span>
                                </div>
                                {destination.requires_tailgate && (
                                  <div className="flex items-center gap-2">
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                    </svg>
                                    <span className="text-orange-600 font-medium">Tailgate Required</span>
                                  </div>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                destination.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                destination.status === 'rescheduled' ? 'bg-blue-100 text-blue-800' :
                                destination.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                                'bg-green-100 text-green-800'
                              }`}>
                                {destination.status}
                              </span>
                              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                destination.constraint_type === 'time_conflict' ? 'bg-purple-100 text-purple-800' :
                                destination.constraint_type === 'capacity_exceeded' ? 'bg-orange-100 text-orange-800' :
                                destination.constraint_type === 'vehicle_unavailable' ? 'bg-blue-100 text-blue-800' :
                                destination.constraint_type === 'geographical_constraint' ? 'bg-gray-100 text-gray-800' :
                                'bg-red-100 text-red-800'
                              }`}>
                                {destination.constraint_type.replace('_', ' ')}
                              </span>
                            </div>
                          </div>
                          
                          <div className="mt-3 p-3 bg-white rounded-lg border border-red-200">
                            <div className="text-sm">
                              <div className="mb-2">
                                <span className="font-medium text-red-800">Issue:</span>
                                <p className="text-red-700 mt-1">{destination.constraint_reason}</p>
                              </div>
                              {destination.suggested_resolution && (
                                <div className="mb-2">
                                  <span className="font-medium text-blue-800">Suggested Solution:</span>
                                  <p className="text-blue-700 mt-1">{destination.suggested_resolution}</p>
                                </div>
                              )}
                              {destination.reschedule_date && (
                                <div className="flex items-center gap-2 text-sm text-green-700">
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                  </svg>
                                  <span>Suggested reschedule: {new Date(destination.reschedule_date).toLocaleDateString()}</span>
                                  {destination.reschedule_time_start && destination.reschedule_time_end && (
                                    <span>at {destination.reschedule_time_start} - {destination.reschedule_time_end}</span>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex-shrink-0">
                          <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                            Reschedule
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Show More Indicator for Undeliverable Destinations */}
                  {!showAllUndeliverable && undeliverableDestinations.length > 5 && (
                    <div className="text-center py-4 border-t border-red-200">
                      <button
                        onClick={() => setShowAllUndeliverable(true)}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center justify-center gap-2 mx-auto"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                        Show {undeliverableDestinations.length - 5} more undeliverable destinations
                      </button>
                    </div>
                  )}
                  
                  <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                    <div className="flex items-center gap-2 text-sm text-yellow-800">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                      </svg>
                      <span>
                        <strong>Note:</strong> These destinations cannot be delivered due to constraints. 
                        Review the suggested solutions and consider rescheduling or adjusting your route parameters.
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Route Actions */}
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Route Actions</h3>
                <div className="space-y-3">
                  {/* Truck Selection */}
                  <div className="space-y-3">
                    <label className="block text-sm font-medium text-gray-700">
                      Available Trucks
                    </label>
                    {isLoadingTrucks ? (
                      <div className="text-center py-4">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                        <p className="text-sm text-gray-500 mt-2">Loading trucks...</p>
                      </div>
                    ) : availableTrucks.length === 0 ? (
                      <div className="text-center py-4 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-500">No trucks available</p>
                        <p className="text-xs text-gray-400 mt-1">Add trucks in the Truck Management section</p>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {availableTrucks.map((truck) => {
                          const isSelected = selectedTrucks[truck.id] > 0
                          const quantity = selectedTrucks[truck.id] || 0
                          
                          return (
                            <div key={truck.id} className={`p-2 rounded-lg border ${
                              isSelected ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'
                            }`}>
                              {/* First row: Checkbox + Truck name + Badges */}
                              <div className="flex items-center gap-2 mb-1">
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={(e) => {
                                    if (e.target.checked) {
                                      handleTruckQuantityChange(truck.id, 1)
                                    } else {
                                      handleTruckQuantityChange(truck.id, 0)
                                    }
                                  }}
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2 flex-shrink-0"
                                />
                                <span className="font-medium text-sm text-gray-900 truncate flex-1 min-w-0">
                                  {truck.display_name}
                                </span>
                                <div className="flex gap-1 flex-shrink-0">
                                  <span className={`px-1.5 py-0.5 text-xs rounded-full font-medium ${
                                    truck.is_internal ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                                  }`}>
                                    {truck.is_internal ? 'Co' : 'Ct'}
                                  </span>
                                  <span className={`px-1.5 py-0.5 text-xs rounded-full font-medium ${
                                    truck.vehicle_type === 'standard' ? 'bg-blue-100 text-blue-800' :
                                    truck.vehicle_type === 'tailgate' ? 'bg-green-100 text-green-800' :
                                    truck.vehicle_type === 'refrigerated' ? 'bg-purple-100 text-purple-800' :
                                    'bg-orange-100 text-orange-800'
                                  }`}>
                                    {truck.vehicle_type.charAt(0).toUpperCase()}
                                  </span>
                                </div>
                              </div>
                              
                              {/* Second row: Capacity info + Quantity selector */}
                              <div className="flex items-center justify-between">
                                <div className="text-xs text-gray-600">
                                  <span className="font-medium">{truck.capacity_pallets}</span> pallets • <span className="font-medium">{truck.available_count}</span> available
                                </div>
                                
                                {/* Compact quantity selector */}
                                {isSelected && (
                                  <div className="flex items-center gap-1">
                                    <button
                                      onClick={() => handleTruckQuantityChange(truck.id, quantity - 1)}
                                      disabled={quantity <= 0}
                                      className="w-5 h-5 rounded bg-gray-200 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                                    >
                                      <svg className="w-3 h-3 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                                      </svg>
                                    </button>
                                    <span className="w-6 text-center text-xs font-bold text-gray-900 bg-white border border-gray-300 rounded">
                                      {quantity}
                                    </span>
                                    <button
                                      onClick={() => handleTruckQuantityChange(truck.id, quantity + 1)}
                                      disabled={quantity >= truck.available_count}
                                      className="w-5 h-5 rounded bg-gray-200 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                                    >
                                      <svg className="w-3 h-3 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                      </svg>
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    )}
                    <div className="text-xs text-gray-500">
                      Total selected trucks: {getTotalSelectedTrucks()}
                      {getTotalSelectedTrucks() === 0 && (
                        <span className="text-red-500 ml-2">• Please select at least one truck</span>
                      )}
                    </div>
                    
                    {/* Selected trucks summary */}
                    {getTotalSelectedTrucks() > 0 && (
                      <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded text-xs">
                        <div className="font-medium text-blue-800 mb-1">Selected trucks:</div>
                        <div className="space-y-0.5">
                          {Object.entries(selectedTrucks)
                            .filter(([, count]) => count > 0)
                            .map(([truckId, count]) => {
                              const truck = availableTrucks.find(t => t.id === truckId)
                              return truck ? (
                                <div key={truckId} className="text-blue-700 flex justify-between">
                                  <span className="truncate flex-1 min-w-0">{truck.display_name}</span>
                                  <span className="ml-2 flex-shrink-0">{count} × {truck.capacity_pallets}p</span>
                                </div>
                              ) : null
                            })}
                        </div>
                      </div>
                    )}
                    
                    {/* Temporary button to create test trucks */}
                    {availableTrucks.length === 0 && (
                      <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
                        <p className="text-yellow-800 mb-1">No trucks found. Create test trucks:</p>
                        <button
                          onClick={createTestTrucks}
                          className="px-2 py-1 bg-yellow-600 text-white text-xs rounded hover:bg-yellow-700 transition-colors"
                        >
                          Create Test Trucks
                        </button>
                      </div>
                    )}
                  </div>
                  
                  {/* Trucker Working Hours Input */}
                  <div className="space-y-2">
                    <label htmlFor="trucker-hours" className="block text-sm font-medium text-gray-700">
                      Trucker Working Hours (per day)
                    </label>
                    <div className="relative">
                      <input
                        id="trucker-hours"
                        type="number"
                        min="0.5"
                        max="24"
                        step="0.5"
                        value={truckerWorkingHours}
                        onChange={(e) => setTruckerWorkingHours(parseFloat(e.target.value) || 12.0)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        placeholder="12.0"
                      />
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                        <span className="text-gray-500 text-sm">hours</span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500">
                      Specify how many hours truckers can work per day for trip calculations
                    </p>
                  </div>
                  
                  {trips.length > 0 ? (
                    <div className="space-y-3">
                      <div className="text-sm text-gray-600 p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center justify-between">
                          <p>✅ {trips.length} trip{trips.length !== 1 ? 's' : ''} calculated successfully</p>
                          <div className="flex items-center gap-2 text-xs">
                            <div className={`w-2 h-2 rounded-full ${
                              realtimeStatus === 'connected' ? 'bg-green-500 animate-pulse' :
                              realtimeStatus === 'connecting' ? 'bg-yellow-500 animate-pulse' :
                              'bg-red-500'
                            }`}></div>
                            <span className={
                              realtimeStatus === 'connected' ? 'text-green-600' :
                              realtimeStatus === 'connecting' ? 'text-yellow-600' :
                              'text-red-600'
                            }>
                              {realtimeStatus === 'connected' ? 'Live' :
                               realtimeStatus === 'connecting' ? 'Connecting' :
                               'Offline'}
                            </span>
                          </div>
                        </div>
                      </div>
        <button 
          onClick={handleRecalculateTrips}
          disabled={!route || route.destinations.length === 0 || isCalculatingTrips || isWaitingForTrips || getTotalSelectedTrucks() === 0}
          className="w-full px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
                        {isCalculatingTrips ? (
                          <>
                            <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                            </svg>
                            Recalculating...
                          </>
                        ) : (
                          <>
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                            </svg>
                            Recalculate Trips
                          </>
                        )}
                      </button>
                    </div>
                  ) : (
                    <button 
                      onClick={handleCalculateTrips}
                      disabled={!route || route.destinations.length === 0 || isCalculatingTrips || isWaitingForTrips || getTotalSelectedTrucks() === 0}
                      className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {isCalculatingTrips ? (
                        <>
                          <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          Calling API...
                        </>
                      ) : isWaitingForTrips ? (
                        <>
                          <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          Waiting for trips...
                        </>
                      ) : (
                        'Calculate Trips'
                      )}
                    </button>
                  )}
                  
                  {/* Error display */}
                  {tripCalculationError && (
                    <div className="p-3 bg-red-50 rounded-lg">
                      <div className="flex items-center gap-2 text-sm text-red-800">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                        </svg>
                        <span className="font-medium">Error:</span> {tripCalculationError}
                      </div>
                  </div>
                  )}
                  
                  <button className="w-full px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    Finalize Route
                  </button>
                  <button className="w-full px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    Share Route
                  </button>
                  
                  {/* Refresh undeliverable destinations */}
                  <button 
                    onClick={fetchUndeliverableDestinations}
                    disabled={isLoadingUndeliverable}
                    className="w-full px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {isLoadingUndeliverable ? (
                      <>
                        <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Refreshing...
                      </>
                    ) : (
                      'Refresh Undeliverable'
                    )}
                  </button>
                </div>
              </div>

              {/* Route Statistics */}
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Route Statistics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Total Distance</span>
                    <span className="text-sm font-medium text-gray-900">
                      {trips.length > 0 ? calculateTotalDistance().toFixed(1) : '--'} km
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Estimated Time</span>
                    <span className="text-sm font-medium text-gray-900">
                      {trips.length > 0 ? calculateTotalTime() : '--'} hrs
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <div className="flex items-center gap-1">
                      <span className="text-sm text-gray-600">Parallel Delivery Time ({getTotalSelectedTrucks()} trucks)</span>
                      <div className="group relative">
                        <svg className="w-4 h-4 text-gray-400 cursor-help" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                        </svg>
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-800 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10">
                          Time when trips run in parallel across {getTotalSelectedTrucks()} trucks
                        </div>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-blue-600">
                      {trips.length > 0 ? calculateParallelDeliveryTime() : '--'} hrs
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Created</span>
                    <span className="text-sm font-medium text-gray-900">
                      {new Date(route.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Last Updated</span>
                    <span className="text-sm font-medium text-gray-900">
                      {new Date(route.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Undeliverable</span>
                    <span className={`text-sm font-medium ${
                      undeliverableDestinations.length > 0 ? 'text-red-600' : 'text-green-600'
                    }`}>
                      {undeliverableDestinations.length} destination{undeliverableDestinations.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Trips Display */}
          <div className="mt-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                <h2 className="text-xl font-semibold text-gray-900">Trip Routes</h2>
                  {trips.length > 0 && trips.length > 5 && (
                    <button
                      onClick={() => setShowAllTrips(!showAllTrips)}
                      className="text-sm text-blue-600 hover:text-blue-800 font-medium"
                    >
                      {showAllTrips ? 'Show Less' : `Show All (${trips.length})`}
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-3">
                <div className="text-sm text-gray-600">
                    {trips.length > 0 ? `${trips.length} trip${trips.length !== 1 ? 's' : ''} generated` : 'Click Calculate Trips to generate'}
                  </div>
                  {trips.length > 0 && (
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2 text-xs">
                        <div className={`w-2 h-2 rounded-full ${
                          realtimeStatus === 'connected' ? 'bg-green-500 animate-pulse' :
                          realtimeStatus === 'connecting' ? 'bg-yellow-500 animate-pulse' :
                          'bg-red-500'
                        }`}></div>
                        <span className={
                          realtimeStatus === 'connected' ? 'text-green-600' :
                          realtimeStatus === 'connecting' ? 'text-yellow-600' :
                          'text-red-600'
                        }>
                          {realtimeStatus === 'connected' ? 'Live updates' :
                           realtimeStatus === 'connecting' ? 'Connecting...' :
                           'Disconnected'}
                        </span>
                      </div>
                      <button
                        onClick={async () => {
                          try {
                            const updatedTrips = await db.getRouteTrips(routeId)
                            if (updatedTrips) {
                              // Enrich trips with truck data
                              const enrichedTrips = await db.enrichTripsWithTruckData(updatedTrips)
                              setTrips(enrichedTrips)
                              setShowRealtimeToast(true)
                              setTimeout(() => setShowRealtimeToast(false), 2000)
                            }
                          } catch (error) {
                            console.error('Error manually refreshing trips:', error)
                          }
                        }}
                        className="text-xs text-blue-600 hover:text-blue-800 underline"
                        title="Refresh trips data"
                      >
                        Refresh
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              {isWaitingForTrips ? (
                <>
                  {/* Status message */}
                  <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 text-sm text-blue-800">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                                              <span>
                          <strong>Calculating trips...</strong> We&apos;ve called the optimization API and are waiting for the results. 
                          This usually takes a few seconds. The page will update automatically when trips are ready.
                        </span>
                    </div>
                  </div>
                  
                  {/* Loading placeholders - Google-style skeleton loading */}
                  <div className="space-y-6">
                  {[1, 2, 3].map((index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <div className="h-6 bg-gray-200 rounded w-20"></div>
                              <div className="h-5 bg-gray-200 rounded w-32"></div>
                            </div>
                            <div className="h-4 bg-gray-200 rounded w-48"></div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="h-5 bg-gray-200 rounded w-16 mb-1"></div>
                          <div className="h-4 bg-gray-200 rounded w-24"></div>
                        </div>
                      </div>
                      
                      {/* Trip Destinations Loading */}
                      <div className="space-y-3 mt-4">
                        <div className="h-4 bg-gray-200 rounded w-32 mb-2"></div>
                        {[1, 2, 3].map((destIndex) => (
                          <div key={destIndex} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                            <div className="w-6 h-6 bg-gray-200 rounded-full"></div>
                            <div className="flex-1">
                              <div className="h-4 bg-gray-200 rounded w-64 mb-2"></div>
                              <div className="flex items-center gap-4">
                                <div className="h-3 bg-gray-200 rounded w-20"></div>
                                <div className="h-3 bg-gray-200 rounded w-24"></div>
                                <div className="h-3 bg-gray-200 rounded w-16"></div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  
                                     {/* Summary loading placeholder */}
                   <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                     <div className="flex items-center gap-2">
                       <div className="w-4 h-4 bg-gray-200 rounded"></div>
                       <div className="space-y-2 flex-1">
                         <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                         <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                       </div>
                     </div>
                   </div>
                 </div>
                 </>
               ) : trips.length > 0 ? (
                <>
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCorners}
                    onDragStart={handleDragStart}
                    onDragEnd={handleDragEnd}
                  >
                    <SortableContext 
                      items={trips.flatMap(trip => trip.trip_destinations?.map(dest => dest.id) || [])}
                      strategy={verticalListSortingStrategy}
                    >
                      <div className="space-y-6">
                      {(showAllTrips ? trips : trips.slice(0, 5)).map((trip) => (
                      <div key={trip.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              trip.requires_tailgate
                                ? 'bg-orange-100'
                                : 'bg-blue-100'
                            }`}>
                              <span className={`text-sm font-medium ${
                                trip.requires_tailgate
                                  ? 'text-orange-600'
                                  : 'text-blue-600'
                              }`}>{trip.trip_number}</span>
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h3 className="text-lg font-medium text-gray-900">Trip {trip.trip_number}</h3>
                                {trip.requires_tailgate && (
                                  <span className="px-2 py-1 text-xs font-medium bg-orange-100 text-orange-800 rounded-full">
                                    🚛 Tailgate Required
                                  </span>
                                )}
                                {trip.truck && trip.total_load > trip.truck.capacity_pallets && (
                                  <span className="px-2 py-1 text-xs font-medium bg-red-100 text-red-800 rounded-full border border-red-300">
                                    ⚠️ Over Capacity
                                  </span>
                                )}
                              </div>
                              <p className="text-sm text-gray-600">
                                {trip.destination_count} destinations • {trip.total_load.toFixed(1)} pallets
                                {trip.truck && (
                                  <span className={trip.total_load > trip.truck.capacity_pallets ? 'text-red-600 font-medium' : ''}>
                                    {' '}/ {trip.truck.capacity_pallets} capacity
                                  </span>
                                )}
                              </p>
                              <div className="flex items-center gap-4 mt-1">
                                <span className="text-xs text-gray-500">
                                  📍 {calculateTripDistance(trip).toFixed(1)} km
                                </span>
                                <span className="text-xs text-gray-500">
                                  ⏱️ {calculateTripTime(trip)} hrs
                                </span>
                              </div>
                              {/* New trip tracking fields */}
                              <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                                {trip.truck && (
                                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                                    trip.truck.is_internal 
                                      ? 'bg-green-100 text-green-700' 
                                      : 'bg-orange-100 text-orange-700'
                                  }`}>
                                    🚛 {trip.truck.display_name}
                                    {trip.truck.is_internal ? ' (Internal)' : ' (External)'}
                                  </span>
                                )}
                                {trip.loading_time && (
                                  <span>📦 Loading: {trip.loading_time}min</span>
                                )}
                                {trip.return_to_warehouse_time && (
                                  <span>🏠 Return: {trip.return_to_warehouse_time}min</span>
                                )}
                                {trip.total_offloading_time && (
                                  <span>📦 Total Offload: {trip.total_offloading_time}min</span>
                                )}
                                {trip.total_offloading_time_extra && (
                                  <span className="text-orange-600">+{trip.total_offloading_time_extra}min extra</span>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-gray-900">
                              Trip {trip.trip_number}
                            </div>
                            <div className="text-sm text-gray-600">
                              Status: {trip.status}
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {calculateTripDistance(trip).toFixed(1)} km • {calculateTripTime(trip)} hrs
                            </div>
                            {/* Google Maps Actions */}
                            {trip.trip_destinations && trip.trip_destinations.length > 0 && (
                              <div className="flex items-center gap-2 mt-3">
                                <button
                                  onClick={() => {
                                    const destinations = (trip.trip_destinations || [])
                                      .sort((a, b) => a.trip_order - b.trip_order)
                                      .map(dest => ({
                                        address: dest.address,
                                        latitude: dest.latitude,
                                        longitude: dest.longitude
                                      }))
                                    openGoogleMapsTrip(route.departure_address || '', destinations, trip.trip_number, 'route')
                                  }}
                                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors"
                                  title="Open in Google Maps with turn-by-turn directions"
                                >
                                  <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                    <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                                  </svg>
                                  Navigate
                                </button>
                                <button
                                  onClick={async () => {
                                    try {
                                      const destinations = (trip.trip_destinations || [])
                                        .sort((a, b) => a.trip_order - b.trip_order)
                                        .map(dest => ({
                                          address: dest.address,
                                          latitude: dest.latitude,
                                          longitude: dest.longitude
                                        }))
                                      await copyGoogleMapsUrl(route.departure_address || '', destinations, trip.trip_number, 'route')
                                      setShowCopyToast(true)
                                      setTimeout(() => setShowCopyToast(false), 2000)
                                    } catch (error) {
                                      console.error('Failed to copy URL:', error)
                                    }
                                  }}
                                  className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors"
                                  title="Copy Google Maps link to clipboard"
                                >
                                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                  </svg>
                                  Copy Link
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {/* Trip Destinations */}
                        <div className="space-y-3 mt-4">
                          <h4 className="text-sm font-medium text-gray-700 mb-2">Destinations in Order:</h4>
                          {trip.trip_destinations && trip.trip_destinations.length > 0 ? (
                            trip.trip_destinations
                              .sort((a, b) => a.trip_order - b.trip_order)
                                .map((dest) => (
                                  <SortableDestination
                                    key={dest.id}
                                    destination={dest}
                                    tripNumber={trip.trip_number}
                                    isDragging={activeId === dest.id}
                                  />
                                ))
                          ) : (
                            <EmptyTripDropZone tripId={trip.id} />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Show More Indicator for Trips */}
                  {!showAllTrips && trips.length > 5 && (
                    <div className="text-center py-4 border-t border-gray-200">
                      <button
                        onClick={() => setShowAllTrips(true)}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center justify-center gap-2 mx-auto"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                        Show {trips.length - 5} more trips
                      </button>
                    </div>
                  )}
                  
                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 text-sm text-blue-800">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>
                        <strong>Trip Summary:</strong> Route has been processed into {trips.length} trips. 
                        Each trip is optimized for efficiency and load distribution.
                        <br/><br/>
                        <strong>Current Status:</strong> All trips are in planning stage and ready for execution.
                      </span>
                    </div>
                  </div>
                    </SortableContext>
                  </DndContext>
                  
                  {/* Drag Overlay */}
                  <DragOverlay>
                    {activeId ? (
                      <div className="opacity-50">
                        {/* Render the dragged item */}
                      </div>
                    ) : null}
                  </DragOverlay>
                </>
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-4">
                    <svg className="mx-auto h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.732-.894L15 4m0 13V4m0 0L9 7" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No trips yet</h3>
                  <p className="text-gray-600">
                    Click the &quot;Calculate Trips&quot; button above to generate optimized trips from your destinations.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Real-time Update Toast */}
        {showRealtimeToast && (
          <div className="fixed top-4 right-4 z-50 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span>Route updated in real-time</span>
          </div>
        )}

        {/* Copy Link Toast */}
        {showCopyToast && (
          <div className="fixed top-4 right-4 z-50 bg-blue-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
            </svg>
            <span>Google Maps link copied to clipboard!</span>
          </div>
        )}

        {/* Route Map */}
        {route && (trips.length > 0 || isWaitingForTrips) && (
          <div className="mt-8">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Route Map</h2>
                <div className="text-sm text-gray-600">
                  Visual representation of your route and trips
                </div>
              </div>
              
              {isWaitingForTrips ? (
                <div className="animate-pulse">
                  <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
                  <div className="h-96 bg-gray-200 rounded"></div>
                </div>
              ) : (
              <TripMap 
                key={`trips-${trips.length}-${trips.map(t => t.id).join('-')}`}
                trips={trips} 
                departureAddress={route.departure_address || ''} 
              />
              )}
            </div>
          </div>
        )}

        {/* Edit Route Dialog */}
        {routeId && (
          <EditRouteDialog
            isOpen={isEditDialogOpen}
            onClose={handleCloseEditDialog}
            routeId={routeId}
            onRouteUpdated={handleRouteUpdated}
          />
        )}
      </Layout>
    </ProtectedRoute>
  )
}
