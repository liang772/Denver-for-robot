'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import UploadRouteDialog from './UploadRouteDialog'
import EditRouteDialog from './EditRouteDialog'
import ExcelUpload from '@/components/ExcelUpload'

import { useAuth } from '@/contexts/AuthContext'
import { mockJourneys, mockTrips, mockDestinations } from '@/lib/mock-data'

interface RouteListItem {
  id: string
  name: string
  date: string
  departureAddress: string
  destinationCount: number
  totalLoad: string
  status: 'active' | 'completed' | 'planned' | 'cancelled'
  createdAt: string
}

type ViewMode = 'day' | 'week' | 'month'

export default function RoutesPage() {
  const { user } = useAuth()
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isExcelUploadOpen, setIsExcelUploadOpen] = useState(false)
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<ViewMode>('day')

  const [routes, setRoutes] = useState<RouteListItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  // Removed newRouteLoading state and localStorage logic since upload modal now waits for API response

  // Fetch routes from mock data
  useEffect(() => {
    const fetchRoutes = async () => {
      if (!user) return
      
      try {
        setIsLoading(true)
        setError(null)
        
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 500))
        
        // 使用 mock 数据生成路线列表
        const transformedRoutes: RouteListItem[] = mockJourneys.map(journey => {
          const trips = mockTrips.filter(t => t.journey_id === journey.id)
          const destinations = mockDestinations.filter(d => 
            trips.some(t => t.id === d.trip_id)
          )
          const totalLoad = destinations.reduce((sum, d) => 
            sum + (d.load_pallets > 0 ? d.load_pallets : 0), 0
          )
          
          return {
            id: journey.id,
            name: journey.name,
            date: journey.date,
            departureAddress: 'Beijing Distribution Center',
            destinationCount: destinations.length,
            totalLoad: `${totalLoad} pallets`,
            status: journey.status as 'active' | 'completed' | 'planned' | 'cancelled',
            createdAt: journey.created_at || new Date().toISOString()
          }
        })
        
        // Sort routes by date (most recent first)
        transformedRoutes.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        
        setRoutes(transformedRoutes)
      } catch (err) {
        console.error('Error fetching routes:', err)
        setError('Failed to load routes. Please try again.')
      } finally {
        setIsLoading(false)
      }
    }

    fetchRoutes()
  }, [user])

  // Removed auto-refresh logic since upload modal now waits for API response

  const getStatusColor = (status: RouteListItem['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200'
      case 'completed':
        return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'planned':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200'
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getStatusText = (status: RouteListItem['status']) => {
    switch (status) {
      case 'active':
        return 'Active'
      case 'completed':
        return 'Completed'
      case 'planned':
        return 'Planned'
      case 'cancelled':
        return 'Cancelled'
      default:
        return 'Unknown'
    }
  }

  const getStatusIcon = (status: RouteListItem['status']) => {
    switch (status) {
      case 'active':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
        )
      case 'completed':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        )
      case 'planned':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
          </svg>
        )
      case 'cancelled':
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        )
      default:
        return (
          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
        )
    }
  }

  const handleDeleteRoute = async (routeId: string) => {
    if (!confirm('Are you sure you want to delete this route? This action cannot be undone.')) return
    
    try {
      // Simulate delete operation
      console.log('Deleting route (mock):', routeId)
      
      // 从当前列表中移除
      setRoutes(prev => prev.filter(route => route.id !== routeId))
      
      alert('Route deleted successfully! (Demo mode)')
    } catch (err) {
      console.error('Error deleting route:', err)
      setError('Failed to delete route. Please try again.')
    }
  }

  const handleEditRoute = (routeId: string) => {
    setSelectedRouteId(routeId)
    setIsEditDialogOpen(true)
  }

  const handleCloseEditDialog = () => {
    setIsEditDialogOpen(false)
    setSelectedRouteId(null)
  }

  const handleRouteUpdated = async () => {
    await refreshRoutes()
  }

  const refreshRoutes = async () => {
    if (!user) return
    
    try {
      // 使用 mock 数据刷新路线列表
      const transformedRoutes: RouteListItem[] = mockJourneys.map(journey => {
        const trips = mockTrips.filter(t => t.journey_id === journey.id)
        const destinations = mockDestinations.filter(d => 
          trips.some(t => t.id === d.trip_id)
        )
        const totalLoad = destinations.reduce((sum, d) => 
          sum + (d.load_pallets > 0 ? d.load_pallets : 0), 0
        )
        
        return {
          id: journey.id,
          name: journey.name,
          date: journey.date,
          departureAddress: 'Beijing Distribution Center',
          destinationCount: destinations.length,
          totalLoad: `${totalLoad} pallets`,
          status: journey.status as 'active' | 'completed' | 'planned' | 'cancelled',
          createdAt: journey.created_at || new Date().toISOString()
        }
      })
      
      // Sort routes by date (most recent first)
      transformedRoutes.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      
      setRoutes(transformedRoutes)
    } catch (err) {
      console.error('Error refreshing routes:', err)
      setError('Failed to refresh routes. Please try again.')
    }
  }

  // Group routes by date based on view mode
  const groupRoutesByDate = (routes: RouteListItem[], mode: ViewMode) => {
    const grouped = routes.reduce((acc, route) => {
      const routeDate = new Date(route.date)
      let groupKey: string
      let groupDate: Date

      switch (mode) {
        case 'day':
          groupKey = routeDate.toDateString()
          groupDate = routeDate
          break
        case 'week':
          // Get start of week (Monday)
          const startOfWeek = new Date(routeDate)
          const day = startOfWeek.getDay()
          const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1) // Adjust when day is Sunday
          startOfWeek.setDate(diff)
          startOfWeek.setHours(0, 0, 0, 0)
          groupKey = `week-${startOfWeek.toISOString()}`
          groupDate = startOfWeek
          break
        case 'month':
          // Get start of month
          const startOfMonth = new Date(routeDate.getFullYear(), routeDate.getMonth(), 1)
          groupKey = `month-${startOfMonth.toISOString()}`
          groupDate = startOfMonth
          break
        default:
          groupKey = routeDate.toDateString()
          groupDate = routeDate
      }

      if (!acc[groupKey]) {
        acc[groupKey] = {
          groupDate,
          routes: []
        }
      }
      acc[groupKey].routes.push(route)
      return acc
    }, {} as Record<string, { groupDate: Date; routes: RouteListItem[] }>)

    // Convert to array and sort by date (most recent first)
    return Object.entries(grouped)
      .sort(([, a], [, b]) => b.groupDate.getTime() - a.groupDate.getTime())
      .map(([, group]) => ({
        date: group.groupDate,
        routes: group.routes
      }))
  }

  const formatDateHeader = (date: Date, mode: ViewMode) => {
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)
    
    switch (mode) {
      case 'day':
        if (date.toDateString() === today.toDateString()) {
          return 'Today'
        } else if (date.toDateString() === yesterday.toDateString()) {
          return 'Yesterday'
        } else {
          return date.toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })
        }
      case 'week':
        const endOfWeek = new Date(date)
        endOfWeek.setDate(date.getDate() + 6)
        
        if (date.getMonth() === endOfWeek.getMonth()) {
          // Same month
          return `${date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })} - Week of ${date.getDate()}`
        } else {
          // Different months
          return `${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endOfWeek.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`
        }
      case 'month':
        return date.toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long' 
        })
      default:
        return date.toLocaleDateString('en-US', { 
          weekday: 'long', 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })
    }
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Routes">
        <div className="p-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <h2 className="text-xl font-semibold text-gray-800">
                My Routes
              </h2>
              
              <div className="flex flex-col sm:flex-row gap-3">
                {/* View Mode Filter */}
                <div className="flex bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => setViewMode('day')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                      viewMode === 'day'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Day
                  </button>
                  <button
                    onClick={() => setViewMode('week')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                      viewMode === 'week'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Week
                  </button>
                  <button
                    onClick={() => setViewMode('month')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                      viewMode === 'month'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Month
                  </button>
                </div>
                
                <div className="flex gap-2">
                  <Link
                    href="/trips/new"
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200 flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Create Trip
                  </Link>
                  <button
                    onClick={() => setIsExcelUploadOpen(true)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                    </svg>
                    Import Excel
                  </button>
                  <button
                    onClick={() => setIsUploadDialogOpen(true)}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    Upload Route
                  </button>
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                          <div className="h-5 bg-gray-200 rounded w-16"></div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          {[1, 2, 3, 4].map((j) => (
                            <div key={j} className="h-4 bg-gray-200 rounded w-24"></div>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="h-6 bg-gray-200 rounded w-20"></div>
                        <div className="h-6 bg-gray-200 rounded w-16"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="bg-red-50 rounded-lg p-6">
                <div className="text-center">
                  <svg className="mx-auto h-12 w-12 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                  <h3 className="mt-2 text-sm font-medium text-red-900">Error loading routes</h3>
                  <p className="mt-1 text-sm text-red-600">{error}</p>
                  <button
                    onClick={() => window.location.reload()}
                    className="mt-4 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    Try Again
                  </button>
                </div>
              </div>
            ) : routes.length > 0 ? (
              <div className="space-y-6">
                {/* Grouped Routes with Date Separators */}
                {groupRoutesByDate(routes, viewMode).map(({ date, routes: groupRoutes }) => (
                  <div key={date.toISOString()} className="space-y-4">
                    {/* Date Separator */}
                    <div className="flex items-center gap-4">
                      <div className="flex-1 border-t border-gray-200"></div>
                      <div className="px-4 py-2 bg-gray-50 rounded-lg border border-gray-200">
                        <h3 className="text-sm font-semibold text-gray-700">
                          {formatDateHeader(date, viewMode)}
                        </h3>
                        <p className="text-xs text-gray-500 mt-1">
                          {groupRoutes.length} route{groupRoutes.length !== 1 ? 's' : ''}
                        </p>
                      </div>
                      <div className="flex-1 border-t border-gray-200"></div>
                    </div>
                    
                    {/* Routes for this date */}
                    <div className="space-y-4">
                      {groupRoutes.map((route) => (
                        <div key={route.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-lg font-medium text-gray-900">
                                  <Link href={`/routes/${route.id}`} className="hover:text-blue-600 transition-colors">
                                    {route.name}
                                  </Link>
                                </h3>
                                <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-full border ${getStatusColor(route.status)}`}>
                                  {getStatusIcon(route.status)}
                                  {getStatusText(route.status)}
                                </span>
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                                <div>
                                  <span className="font-medium">Date:</span> {new Date(route.date).toLocaleDateString()}
                                </div>
                                <div>
                                  <span className="font-medium">From:</span> {route.departureAddress}
                                </div>
                                <div>
                                  <span className="font-medium">Stops:</span> {route.destinationCount} destinations
                                </div>
                                <div>
                                  <span className="font-medium">Total Load:</span> {route.totalLoad}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Link
                                href={`/routes/${route.id}`}
                                className="px-3 py-1 text-sm text-blue-600 hover:text-blue-800 font-medium"
                              >
                                View Details
                              </Link>
                              <button 
                                onClick={() => handleEditRoute(route.id)}
                                className="px-3 py-1 text-sm text-gray-600 hover:text-blue-800 transition-colors"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => handleDeleteRoute(route.id)}
                                className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                                title="Delete route"
                              >
                                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                </svg>
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 rounded-lg p-6">
                <div className="text-center">
                  <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.732-.894L15 4m0 13V4m0 0L9 7" />
                  </svg>
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No routes yet</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Get started by uploading a route file to create your first route.
                  </p>
                  <div className="mt-6 flex justify-center">
                    <button
                      onClick={() => setIsUploadDialogOpen(true)}
                      className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                    >
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                      </svg>
                      Upload Route
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Upload Route Dialog */}
        <UploadRouteDialog
          isOpen={isUploadDialogOpen}
          onClose={() => setIsUploadDialogOpen(false)}
        />

        {/* Excel Upload Dialog */}
        {isExcelUploadOpen && (
          <ExcelUpload
            onTripsUploaded={async (trips) => {
              // Handle the imported trips
              console.log('Imported trips:', trips)
              // TODO: Create trips in database
              setIsExcelUploadOpen(false)
              // Refresh routes list (mock)
              await refreshRoutes()
            }}
            onCancel={() => setIsExcelUploadOpen(false)}
          />
        )}

        {/* Edit Route Dialog */}
        {selectedRouteId && (
          <EditRouteDialog
            isOpen={isEditDialogOpen}
            onClose={handleCloseEditDialog}
            routeId={selectedRouteId}
            onRouteUpdated={handleRouteUpdated}
          />
        )}

      </Layout>
    </ProtectedRoute>
  )
}
