/**
 * Notification Scheduler
 * Phase 4.3: Batch processing task scheduling
 * 
 * Implements scheduled tasks for automatic notifications:
 * - D-1 pre-delivery notifications (daily at 19:00)
 * - Can be run as a cron job or serverless function
 */

import { createClient } from '@supabase/supabase-js'
import { getNotificationService } from './notificationService'

// Initialize Supabase client (use service role key for server-side operations)
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

const supabase = createClient(supabaseUrl, supabaseServiceKey)

/**
 * D-1 Pre-delivery notification task
 * Should be run daily at 19:00 (7 PM)
 */
export async function runD1PreDeliveryTask(): Promise<void> {
  console.log('🕒 [Scheduler] Starting D-1 pre-delivery notification task')
  
  try {
    // Calculate tomorrow's date
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    const tomorrowDate = tomorrow.toISOString().split('T')[0]

    console.log(`📅 [Scheduler] Sending notifications for deliveries on ${tomorrowDate}`)

    // Get notification service
    const notificationService = getNotificationService(supabase)

    // Send D-1 notifications
    await notificationService.sendD1PreDeliveryNotifications(tomorrowDate)

    console.log('✅ [Scheduler] D-1 notification task completed successfully')
  } catch (error) {
    console.error('❌ [Scheduler] Error in D-1 notification task:', error)
    throw error
  }
}

/**
 * Main scheduler runner
 * This can be called by:
 * 1. Node-cron (for standalone server)
 * 2. Supabase Edge Functions (serverless)
 * 3. External cron service (e.g., cron-job.org, GitHub Actions)
 */
export async function runScheduledTasks(): Promise<void> {
  const now = new Date()
  const hour = now.getHours()
  const minute = now.getMinutes()

  console.log(`⏰ [Scheduler] Running scheduled tasks at ${hour}:${minute}`)

  // Run D-1 notifications at 19:00 (7 PM)
  if (hour === 19 && minute < 5) {
    await runD1PreDeliveryTask()
  }

  // Add more scheduled tasks here as needed
}

/**
 * Setup cron job (for Node.js server environment)
 * 
 * Usage in server:
 * ```
 * import { setupScheduler } from './scheduler'
 * setupScheduler()
 * ```
 */
export function setupScheduler(): void {
  // Dynamic import to avoid issues in browser environment
  import('node-cron').then(cron => {
    console.log('📋 [Scheduler] Setting up scheduled tasks with node-cron')

    // D-1 notifications - every day at 19:00
    cron.default.schedule('0 19 * * *', async () => {
      console.log('🔔 [Scheduler] Triggered: D-1 pre-delivery notifications')
      await runD1PreDeliveryTask()
    }, {
      timezone: 'Asia/Shanghai' // Adjust to your timezone
    })

    console.log('✅ [Scheduler] Scheduled tasks initialized')
    console.log('   - D-1 notifications: Daily at 19:00')
  }).catch(error => {
    console.error('❌ [Scheduler] Failed to setup scheduler:', error)
    console.log('💡 [Scheduler] Make sure node-cron is installed: npm install node-cron @types/node-cron')
  })
}

/**
 * Manual trigger endpoint handler
 * Can be exposed as an API route for manual testing
 * 
 * Usage in API route (app/api/scheduler/route.ts):
 * ```
 * import { handleManualTrigger } from '@/lib/scheduler'
 * 
 * export async function POST(request: Request) {
 *   return handleManualTrigger(request)
 * }
 * ```
 */
export async function handleManualTrigger(request: Request): Promise<Response> {
  try {
    const { task, date } = await request.json()

    console.log(`🔧 [Scheduler] Manual trigger requested for task: ${task}`)

    switch (task) {
      case 'd1-notifications':
        const targetDate = date || new Date(Date.now() + 86400000).toISOString().split('T')[0]
        const notificationService = getNotificationService(supabase)
        await notificationService.sendD1PreDeliveryNotifications(targetDate)
        return Response.json({ success: true, message: `D-1 notifications sent for ${targetDate}` })

      default:
        return Response.json({ success: false, error: 'Unknown task' }, { status: 400 })
    }
  } catch (error) {
    console.error('❌ [Scheduler] Error in manual trigger:', error)
    return Response.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

export default {
  runD1PreDeliveryTask,
  runScheduledTasks,
  setupScheduler,
  handleManualTrigger
}
