'use client'

/**
 * Journey Detail Page with Drag & Drop
 * Phase 2.2: Cross-journey drag and drop functionality
 * Phase 2.3: Insert destination功能
 */

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'
import { db } from '@/lib/database'
import { createClient } from '@/lib/supabase'
import { getETACalculator } from '@/lib/etaCalculator'
import { getCapacityValidator } from '@/lib/capacityValidator'
import JourneyTimeEditor from '@/components/JourneyTimeEditor'
import InsertDestinationDialog from '@/components/InsertDestinationDialog'
import BatchOperationsDialog from '@/components/BatchOperationsDialog'
import SaveAsTemplateDialog from '@/components/SaveAsTemplateDialog'
import {
  DndContext,
  DragEndEvent,
  DragStartEvent,
  closestCorners,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core'
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'

interface TripDestination {
  id: string
  sequence: number
  address: string
  load_pallets: number
  delivery_type: 'delivery' | 'refund_pickup' | 'pickup'
  estimated_arrival_time?: string
  offloading_time?: number
  requires_tailgate: boolean
  status: string
}

interface Trip {
  id: string
  journey_sequence: number
  trip_destinations: TripDestination[]
  truck?: {
    display_name: string
    capacity_pallets: number
  }
}

interface Journey {
  id: string
  name: string
  date: string
  driver?: { name: string }
  truck?: { display_name: string }
  planned_departure_time?: string
  total_planned_duration?: number
  status: string
}

export default function JourneyDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const journeyId = params?.id as string

  const [journey, setJourney] = useState<Journey | null>(null)
  const [trips, setTrips] = useState<Trip[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [showInsertDialog, setShowInsertDialog] = useState(false)
  const [selectedTrip, setSelectedTrip] = useState<string | null>(null)
  const [insertPosition, setInsertPosition] = useState<number>(0)
  const [showBatchDialog, setShowBatchDialog] = useState(false)
  const [batchMode, setBatchMode] = useState<'import' | 'edit' | 'delete'>('import')
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>([])
  const [showSaveTemplateDialog, setShowSaveTemplateDialog] = useState(false)

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  )

  useEffect(() => {
    if (journeyId && user) {
      fetchJourneyDetails()
    }
  }, [journeyId, user])

  const fetchJourneyDetails = async () => {
    try {
      setIsLoading(true)

      // Get supabase client
      const supabase = createClient()

      // Fetch journey
      const { data: journeyData, error: journeyError } = await supabase
        .from('irp_journeys')
        .select(`
          *,
          driver:irp_drivers(name),
          truck:irp_trucks(display_name)
        `)
        .eq('id', journeyId)
        .single()

      if (journeyError) throw journeyError
      setJourney(journeyData)

      // Fetch trips with destinations
      const { data: tripsData, error: tripsError } = await supabase
        .from('irp_trips')
        .select(`
          *,
          truck:irp_trucks(display_name, capacity_pallets),
          trip_destinations:irp_trip_destinations(*)
        `)
        .eq('journey_id', journeyId)
        .order('journey_sequence', { ascending: true })

      if (tripsError) throw tripsError

      // Sort destinations within each trip
      const sortedTrips = tripsData.map((trip: any) => ({
        ...trip,
        trip_destinations: (trip.trip_destinations || []).sort(
          (a: any, b: any) => (a.sequence || 0) - (b.sequence || 0)
        ),
      }))

      setTrips(sortedTrips)
    } catch (error) {
      console.error('Error fetching journey details:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string)
  }

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event
    setActiveId(null)

    if (!over || active.id === over.id) return

    // Find source destination
    let sourceTrip: Trip | null = null
    let sourceDestination: TripDestination | null = null
    let sourceIndex = -1

    for (const trip of trips) {
      const index = trip.trip_destinations?.findIndex(
        (dest) => dest.id === active.id
      )
      if (index !== -1) {
        sourceTrip = trip
        sourceDestination = trip.trip_destinations[index]
        sourceIndex = index
        break
      }
    }

    if (!sourceTrip || !sourceDestination) return

    // Find target trip and position
    let targetTrip: Trip | null = null
    let targetIndex = -1

    for (const trip of trips) {
      const index = trip.trip_destinations?.findIndex(
        (dest) => dest.id === over.id
      )
      if (index !== -1) {
        targetTrip = trip
        targetIndex = index
        break
      }
    }

    if (!targetTrip) return

    // Same trip reordering
    if (sourceTrip.id === targetTrip.id) {
      await reorderWithinTrip(sourceTrip.id, sourceIndex, targetIndex)
    } else {
      // Cross-trip move
      await moveAcrossTrips(
        sourceDestination.id,
        sourceTrip.id,
        targetTrip.id,
        targetIndex
      )
    }

    // Refresh data
    await fetchJourneyDetails()
  }

  const reorderWithinTrip = async (
    tripId: string,
    fromIndex: number,
    toIndex: number
  ) => {
    const trip = trips.find((t) => t.id === tripId)
    if (!trip) return

    const reordered = [...trip.trip_destinations]
    const [removed] = reordered.splice(fromIndex, 1)
    reordered.splice(toIndex, 0, removed)

    // Get supabase client
    const supabase = createClient()

    // Update sequences in database
    for (let i = 0; i < reordered.length; i++) {
      await supabase
        .from('irp_trip_destinations')
        .update({ sequence: i })
        .eq('id', reordered[i].id)
    }

    // Recalculate ETAs
    const etaCalculator = getETACalculator(supabase)
    await etaCalculator.recalculateOnReorder([tripId])
  }

  const moveAcrossTrips = async (
    destinationId: string,
    fromTripId: string,
    toTripId: string,
    insertIndex: number
  ) => {
    try {
      // Get supabase client
      const supabase = createClient()

      // Validate capacity
      const validator = getCapacityValidator(supabase)
      const validation = await validator.validateMoveDestination(
        destinationId,
        fromTripId,
        toTripId
      )

      if (!validation.isValid) {
        alert(`Cannot move: ${validation.message}`)
        return
      }

      // Update destination's trip
      await supabase
        .from('irp_trip_destinations')
        .update({
          trip_id: toTripId,
          sequence: insertIndex,
        })
        .eq('id', destinationId)

      // Resequence target trip
      const targetTrip = trips.find((t) => t.id === toTripId)
      if (targetTrip) {
        const destinations = [...targetTrip.trip_destinations]
        for (let i = 0; i < destinations.length; i++) {
          if (destinations[i].id !== destinationId) {
            const newSeq = i >= insertIndex ? i + 1 : i
            await supabase
              .from('irp_trip_destinations')
              .update({ sequence: newSeq })
              .eq('id', destinations[i].id)
          }
        }
      }

      // Resequence source trip
      const sourceTrip = trips.find((t) => t.id === fromTripId)
      if (sourceTrip) {
        const remaining = sourceTrip.trip_destinations.filter(
          (d) => d.id !== destinationId
        )
        for (let i = 0; i < remaining.length; i++) {
          await supabase
            .from('irp_trip_destinations')
            .update({ sequence: i })
            .eq('id', remaining[i].id)
        }
      }

      // Recalculate ETAs for both trips
      const etaCalculator = getETACalculator(supabase)
      await etaCalculator.recalculateOnReorder([fromTripId, toTripId])
    } catch (error) {
      console.error('Error moving destination:', error)
      alert('Failed to move destination')
    }
  }

  const handleInsertDestination = async (
    tripId: string,
    position: number
  ) => {
    setSelectedTrip(tripId)
    setInsertPosition(position)
    setShowInsertDialog(true)
  }

  const handleDoInsertDestination = async (destinationData: {
    address: string
    load_pallets: number
    delivery_type: 'delivery' | 'refund_pickup' | 'pickup'
    requires_tailgate: boolean
    customer_name?: string
    customer_phone?: string
    notes?: string
    insertPosition: number
  }) => {
    if (!selectedTrip) return

    try {
      // Get supabase client for validators
      const supabase = createClient()
      
      // Validate capacity before insertion
      const validator = getCapacityValidator(supabase)
      const validation = await validator.validateAddDestination(selectedTrip, {
        loadPallets: destinationData.load_pallets,
        deliveryType: destinationData.delivery_type,
        insertPosition: destinationData.insertPosition,
      })

      if (!validation.isValid) {
        throw new Error(`Capacity validation failed: ${validation.message}`)
      }

      // Insert destination using proper API
      await db.addDestinationToTrip(selectedTrip, {
        address: destinationData.address,
        load_pallets: destinationData.load_pallets,
        requires_tailgate: destinationData.requires_tailgate,
        trip_order: destinationData.insertPosition,
        load_info: destinationData.customer_name || '',
        latitude: 0, // Will be geocoded by backend
        longitude: 0,
      })

      // Resequence destinations in the trip
      const trip = trips.find((t) => t.id === selectedTrip)
      if (trip) {
        for (let i = 0; i < trip.trip_destinations.length; i++) {
          if (i >= destinationData.insertPosition) {
            await db.updateTripDestination(trip.trip_destinations[i].id, {
              trip_order: i + 1,
            })
          }
        }
      }

      // Recalculate ETAs
      const etaCalculator = getETACalculator(supabase)
      await etaCalculator.recalculateOnReorder([selectedTrip])

      // Refresh data
      await fetchJourneyDetails()
    } catch (error) {
      console.error('Error inserting destination:', error)
      throw error
    }
  }

  const handleBatchImport = () => {
    setBatchMode('import')
    setShowBatchDialog(true)
  }

  const handleBatchEdit = () => {
    if (selectedDestinations.length === 0) {
      alert('Please select destinations to edit')
      return
    }
    setBatchMode('edit')
    setShowBatchDialog(true)
  }

  const handleBatchDelete = () => {
    if (selectedDestinations.length === 0) {
      alert('Please select destinations to delete')
      return
    }
    setBatchMode('delete')
    setShowBatchDialog(true)
  }

  const toggleDestinationSelection = (destinationId: string) => {
    setSelectedDestinations(prev => 
      prev.includes(destinationId)
        ? prev.filter(id => id !== destinationId)
        : [...prev, destinationId]
    )
  }

  const selectAllDestinations = () => {
    const allIds = trips.flatMap(trip => trip.trip_destinations.map(dest => dest.id))
    setSelectedDestinations(allIds)
  }

  const clearSelection = () => {
    setSelectedDestinations([])
  }

  const getDeliveryTypeIcon = (type: string) => {
    switch (type) {
      case 'delivery':
        return '📦'
      case 'refund_pickup':
        return '📥'
      case 'pickup':
        return '🔄'
      default:
        return '📦'
    }
  }

  const getDeliveryTypeColor = (type: string) => {
    switch (type) {
      case 'delivery':
        return 'bg-blue-100 text-blue-700'
      case 'refund_pickup':
        return 'bg-orange-100 text-orange-700'
      case 'pickup':
        return 'bg-purple-100 text-purple-700'
      default:
        return 'bg-gray-100 text-gray-700'
    }
  }

  if (isLoading) {
    return (
      <ProtectedRoute>
        <Layout>
          <div className="flex justify-center items-center min-h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        </Layout>
      </ProtectedRoute>
    )
  }

  if (!journey) {
    return (
      <ProtectedRoute>
        <Layout>
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Journey not found
              </h2>
              <button
                onClick={() => router.push('/journeys')}
                className="text-blue-600 hover:text-blue-700"
              >
                ← Back to Journeys
              </button>
            </div>
          </div>
        </Layout>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <Layout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-6">
            <button
              onClick={() => router.push('/journeys')}
              className="text-sm text-blue-600 hover:text-blue-700 mb-2 flex items-center gap-1"
            >
              ← Back to Journeys
            </button>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {journey.name}
            </h1>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>📅 {journey.date}</span>
              {journey.driver && <span>👤 {journey.driver.name}</span>}
              {journey.truck && <span>🚛 {journey.truck.display_name}</span>}
            </div>
          </div>

          {/* Batch Operations Toolbar */}
          <div className="mb-6 bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h3 className="text-sm font-semibold text-gray-900">Batch Operations</h3>
                {selectedDestinations.length > 0 && (
                  <span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded-full">
                    {selectedDestinations.length} selected
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleBatchImport}
                  className="px-4 py-2 text-sm bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
                >
                  📥 Import CSV
                </button>
                <button
                  onClick={handleBatchEdit}
                  disabled={selectedDestinations.length === 0}
                  className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  ✏️ Batch Edit ({selectedDestinations.length})
                </button>
                <button
                  onClick={handleBatchDelete}
                  disabled={selectedDestinations.length === 0}
                  className="px-4 py-2 text-sm bg-red-600 text-white rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  🗑️ Batch Delete ({selectedDestinations.length})
                </button>
                {selectedDestinations.length > 0 ? (
                  <button
                    onClick={clearSelection}
                    className="px-3 py-2 text-sm text-gray-600 hover:text-gray-800"
                  >
                    Clear
                  </button>
                ) : (
                  <button
                    onClick={selectAllDestinations}
                    className="px-3 py-2 text-sm text-gray-600 hover:text-gray-800"
                  >
                    Select All
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content - Trips */}
            <div className="lg:col-span-2 space-y-6">
              <DndContext
                sensors={sensors}
                collisionDetection={closestCorners}
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
              >
                {trips.map((trip, tripIndex) => (
                  <div
                    key={trip.id}
                    className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm"
                  >
                    {/* Trip Header */}
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">
                        Trip {tripIndex + 1}
                      </h3>
                      <div className="flex items-center gap-2">
                        {trip.truck && (
                          <span className="text-sm text-gray-600">
                            🚛 {trip.truck.display_name}
                          </span>
                        )}
                        <button
                          onClick={() => handleInsertDestination(trip.id, 0)}
                          className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200"
                        >
                          + Add Destination
                        </button>
                      </div>
                    </div>

                    {/* Destinations */}
                    <SortableContext
                      items={trip.trip_destinations.map((d) => d.id)}
                      strategy={verticalListSortingStrategy}
                    >
                      <div className="space-y-2">
                        {trip.trip_destinations.map((dest, destIndex) => (
                          <SortableDestinationCard
                            key={dest.id}
                            destination={dest}
                            tripNumber={tripIndex + 1}
                            destinationNumber={destIndex + 1}
                            isActive={activeId === dest.id}
                            isSelected={selectedDestinations.includes(dest.id)}
                            onToggleSelect={toggleDestinationSelection}
                          />
                        ))}
                      </div>
                    </SortableContext>

                    {trip.trip_destinations.length === 0 && (
                      <div className="text-center py-8 text-gray-400">
                        No destinations. Add one to get started.
                      </div>
                    )}
                  </div>
                ))}
              </DndContext>

              {trips.length === 0 && (
                <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
                  <div className="text-4xl mb-4">📦</div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    No trips yet
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Create trips to organize deliveries
                  </p>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Journey Time Editor */}
              <JourneyTimeEditor
                journeyId={journeyId}
                currentDepartureTime={journey.planned_departure_time}
                totalPlannedDuration={journey.total_planned_duration}
                onUpdate={fetchJourneyDetails}
              />

              {/* Journey Stats */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                <h3 className="text-sm font-semibold text-gray-900 mb-3">
                  Statistics
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Trips:</span>
                    <span className="font-semibold">{trips.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Total Destinations:</span>
                    <span className="font-semibold">
                      {trips.reduce(
                        (sum, t) => sum + t.trip_destinations.length,
                        0
                      )}
                    </span>
                  </div>
                </div>
              </div>

              {/* Save as Template Button */}
              <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                <button
                  onClick={() => setShowSaveTemplateDialog(true)}
                  disabled={trips.length === 0 || trips.every(t => t.trip_destinations.length === 0)}
                  className="w-full px-4 py-2 text-sm font-medium text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Save as Template
                </button>
                <p className="text-xs text-gray-500 text-center mt-2">
                  Save this route configuration for future use
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Insert Destination Dialog */}
        {showInsertDialog && selectedTrip && (
          <InsertDestinationDialog
            isOpen={showInsertDialog}
            tripId={selectedTrip}
            existingDestinations={
              trips.find(t => t.id === selectedTrip)?.trip_destinations.map(d => ({
                id: d.id,
                address: d.address,
                sequence: d.sequence
              })) || []
            }
            onClose={() => {
              setShowInsertDialog(false)
              setSelectedTrip(null)
            }}
            onInsert={handleDoInsertDestination}
          />
        )}

        {/* Batch Operations Dialog */}
        {showBatchDialog && user && (
          <BatchOperationsDialog
            isOpen={showBatchDialog}
            mode={batchMode}
            journeyId={journeyId}
            userId={user.id}
            selectedDestinations={selectedDestinations}
            onClose={() => {
              setShowBatchDialog(false)
              setSelectedDestinations([])
            }}
            onSuccess={() => {
              fetchJourneyDetails()
              setSelectedDestinations([])
            }}
          />
        )}

        {/* Save as Template Dialog */}
        {showSaveTemplateDialog && user && (
          <SaveAsTemplateDialog
            isOpen={showSaveTemplateDialog}
            userId={user.id}
            journeyData={{
              destinations: trips.flatMap(trip => 
                trip.trip_destinations.map(dest => ({
                  address: dest.address,
                  load_pallets: dest.load_pallets,
                  estimated_arrival_time: dest.estimated_arrival_time,
                  requires_tailgate: dest.requires_tailgate
                }))
              ),
              settings: {
                planned_departure_time: journey?.planned_departure_time
              }
            }}
            onClose={() => setShowSaveTemplateDialog(false)}
            onSuccess={() => {
              setShowSaveTemplateDialog(false)
              alert('Template saved successfully!')
            }}
          />
        )}
      </Layout>
    </ProtectedRoute>
  )
}

// Sortable Destination Card Component
interface SortableDestinationCardProps {
  destination: TripDestination
  tripNumber: number
  destinationNumber: number
  isActive?: boolean
  isSelected?: boolean
  onToggleSelect?: (destinationId: string) => void
}

function SortableDestinationCard({
  destination,
  tripNumber,
  destinationNumber,
  isActive,
  isSelected,
  onToggleSelect,
}: SortableDestinationCardProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: destination.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const getDeliveryTypeIcon = (type: string) => {
    switch (type) {
      case 'delivery':
        return '📦'
      case 'refund_pickup':
        return '📥'
      case 'pickup':
        return '🔄'
      default:
        return '📦'
    }
  }

  const getDeliveryTypeColor = (type: string) => {
    switch (type) {
      case 'delivery':
        return 'bg-blue-100 text-blue-700'
      case 'refund_pickup':
        return 'bg-orange-100 text-orange-700'
      case 'pickup':
        return 'bg-purple-100 text-purple-700'
      default:
        return 'bg-gray-100 text-gray-700'
    }
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`flex items-center gap-3 p-3 rounded-lg border ${
        isSelected
          ? 'bg-blue-50 border-blue-400'
          : isActive
          ? 'bg-gray-50 border-blue-300 shadow-lg'
          : 'bg-gray-50 border-gray-200'
      }`}
    >
      {/* Checkbox */}
      {onToggleSelect && (
        <input
          type="checkbox"
          checked={isSelected || false}
          onChange={(e) => {
            e.stopPropagation()
            onToggleSelect(destination.id)
          }}
          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
        />
      )}

      {/* Drag Handle */}
      <div className="flex-shrink-0 w-6 h-6 bg-gray-200 rounded flex items-center justify-center cursor-grab active:cursor-grabbing"
        {...attributes}
        {...listeners}
      >
        <svg
          className="w-3 h-3 text-gray-600"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M4 8h16M4 16h16"
          />
        </svg>
      </div>

      {/* Content */}
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs font-medium text-gray-500">
            #{destinationNumber}
          </span>
          <span
            className={`px-2 py-0.5 rounded text-xs font-medium ${getDeliveryTypeColor(
              destination.delivery_type
            )}`}
          >
            {getDeliveryTypeIcon(destination.delivery_type)}{' '}
            {destination.delivery_type}
          </span>
        </div>
        <p className="text-sm font-medium text-gray-900">{destination.address}</p>
        <div className="flex items-center gap-3 text-xs text-gray-600 mt-1">
          <span>📦 {destination.load_pallets || 0} pallets</span>
          {destination.estimated_arrival_time && (
            <span>⏰ ETA: {destination.estimated_arrival_time}</span>
          )}
          {destination.requires_tailgate && (
            <span className="text-orange-600 font-medium">🚛 Tailgate</span>
          )}
        </div>
      </div>
    </div>
  )
}
