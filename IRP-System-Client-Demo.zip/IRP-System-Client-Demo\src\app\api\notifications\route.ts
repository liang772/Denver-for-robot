/**
 * Notification API Endpoint
 * Manual trigger for notification workflows
 */

import { NextRequest, NextResponse } from 'next/server'
import { getNotificationService } from '@/lib/notificationService'
import { createClient } from '@/lib/supabase'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, journeyId, date } = body

    const supabase = createClient()
    const notificationService = getNotificationService(supabase)

    let result

    switch (type) {
      case 'd1-pre-delivery':
        // D-1 Pre-delivery notifications (evening before delivery)
        if (!date) {
          return NextResponse.json({ error: 'Date is required for D-1 notifications' }, { status: 400 })
        }
        result = await notificationService.sendD1PreDeliveryNotifications(date)
        break

      case 'on-the-way':
        // On-the-way notifications (when journey starts)
        if (!journeyId) {
          return NextResponse.json({ error: 'Journey ID is required' }, { status: 400 })
        }
        result = await notificationService.sendOnTheWayNotifications(journeyId)
        break

      case 'next-trip':
        // Next trip notifications (when trip completes)
        if (!journeyId) {
          return NextResponse.json({ error: 'Journey ID is required' }, { status: 400 })
        }
        result = await notificationService.sendNextTripNotifications(journeyId)
        break

      default:
        return NextResponse.json({ error: 'Invalid notification type' }, { status: 400 })
    }

    return NextResponse.json({
      success: true,
      message: `${type} notifications sent successfully`,
      result
    })
  } catch (error) {
    console.error('Notification API error:', error)
    return NextResponse.json(
      { error: 'Failed to send notifications', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

// GET endpoint to test notification configuration
export async function GET() {
  const twilioConfigured = !!(
    process.env.TWILIO_ACCOUNT_SID &&
    process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_PHONE_NUMBER
  )

  return NextResponse.json({
    status: 'online',
    twilioConfigured,
    availableTypes: ['d1-pre-delivery', 'on-the-way', 'next-trip'],
    message: twilioConfigured
      ? 'Notification system is ready'
      : 'Twilio not configured. Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER in environment variables.'
  })
}
