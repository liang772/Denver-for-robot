'use client'

import { useAuth } from '@/contexts/AuthContext'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import TemplateManager from '@/components/TemplateManager'
import { useRouter } from 'next/navigation'

export default function TemplatesPage() {
  const { user } = useAuth()
  const router = useRouter()

  return (
    <ProtectedRoute>
      <Layout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  Route Templates
                </h1>
                <p className="text-gray-600">
                  Save and reuse your frequently used route configurations
                </p>
              </div>
              <button
                onClick={() => router.push('/journeys')}
                className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                Back to Journeys
              </button>
            </div>
          </div>

          {/* Template Manager */}
          {user && (
            <TemplateManager userId={user.id} mode="manage" />
          )}

          {/* Help Section */}
          <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
            <h3 className="text-lg font-semibold text-blue-900 mb-3">
              How to use Route Templates
            </h3>
            <ul className="space-y-2 text-sm text-blue-800">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Save any journey as a template from the journey detail page</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Load templates when creating new journeys to quickly set up routes</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Duplicate templates to create variations of existing routes</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-0.5">•</span>
                <span>Templates include all destination details, settings, and configurations</span>
              </li>
            </ul>
          </div>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
