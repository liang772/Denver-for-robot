'use client'

/**
 * Live Tracking Map Page
 * Phase 2.4: Real-time driver location tracking
 */

import { useState } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'
import { mockJourneys, mockDrivers, mockTruckLocations } from '@/lib/mock-data'
import dynamic from 'next/dynamic'
import { useEffect, useRef } from 'react'
import type * as L from 'leaflet'

// Dynamic import for map components to avoid SSR issues
const LiveTrackingMap = dynamic(() => Promise.resolve(LiveTrackingMapComponent), {
  ssr: false,
  loading: () => <div className="h-full flex items-center justify-center">Loading map...</div>
})

const GoogleMap = dynamic(() => import('@/components/GoogleMap'), {
  ssr: false,
  loading: () => <div className="h-full flex items-center justify-center">Loading Google Maps...</div>
})

type DriverLocation = {
  driver_id: string
  driver_name: string
  truck_name: string
  latitude: number
  longitude: number
  journey_id: string
  journey_name: string
  journey_status: string
  current_trip: number
  total_trips: number
  last_updated: string
}

// LiveTrackingMap Component
function LiveTrackingMapComponent({ drivers }: { drivers: DriverLocation[] }) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<L.Map | null>(null)

  useEffect(() => {
    if (typeof window === 'undefined') return

    // Dynamically import Leaflet only on client side
    import('leaflet').then((L) => {
      // CSS is imported globally

      if (!mapRef.current || mapInstanceRef.current) return

      // Fix for default markers in Next.js
      delete (L.Icon.Default.prototype as unknown as Record<string, unknown>)._getIconUrl
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      })

      // Initialize map centered on Beijing
      const map = L.map(mapRef.current).setView([39.9042, 116.4074], 11)
      mapInstanceRef.current = map

      // Add OpenStreetMap tiles
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(map)

      // Add driver markers
      drivers.forEach((driver) => {
        const iconHtml = `
          <div style="
            background-color: ${driver.journey_status === 'active' ? '#10B981' : '#F59E0B'};
            border: 3px solid white;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          ">
            🚛
          </div>
        `

        const driverIcon = L.divIcon({
          html: iconHtml,
          className: 'driver-marker',
          iconSize: [40, 40],
          iconAnchor: [20, 20],
        })

        const popupContent = `
          <div style="min-width: 200px;">
            <h3 style="font-weight: bold; margin-bottom: 8px; font-size: 16px;">
              🚛 ${driver.driver_name}
            </h3>
            <div style="font-size: 13px; line-height: 1.6;">
              <div style="margin-bottom: 4px;">
                <strong>Truck:</strong> ${driver.truck_name}
              </div>
              <div style="margin-bottom: 4px;">
                <strong>Journey:</strong> ${driver.journey_name}
              </div>
              <div style="margin-bottom: 4px;">
                <strong>Status:</strong> 
                <span style="
                  padding: 2px 8px;
                  border-radius: 12px;
                  background-color: ${driver.journey_status === 'active' ? '#D1FAE5' : '#FEF3C7'};
                  color: ${driver.journey_status === 'active' ? '#065F46' : '#92400E'};
                  font-weight: 600;
                  font-size: 11px;
                ">
                  ${driver.journey_status === 'active' ? '🟢 Active' : '🟡 In Progress'}
                </span>
              </div>
              <div style="margin-bottom: 4px;">
                <strong>Progress:</strong> Trip ${driver.current_trip} of ${driver.total_trips}
              </div>
              <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #E5E7EB; color: #6B7280; font-size: 11px;">
                Last updated: ${formatLastUpdated(driver.last_updated)}
              </div>
            </div>
          </div>
        `

        L.marker([driver.latitude, driver.longitude], { icon: driverIcon })
          .bindPopup(popupContent)
          .addTo(map)
      })

      // Fit map to show all drivers
      if (drivers.length > 0) {
        const group = new L.FeatureGroup(
          drivers.map(driver => L.marker([driver.latitude, driver.longitude]))
        )
        map.fitBounds(group.getBounds().pad(0.1))
      }
    })

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [drivers])

  const formatLastUpdated = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins}m ago`
    const diffHours = Math.floor(diffMins / 60)
    return `${diffHours}h ago`
  }

  return (
    <div 
      ref={mapRef} 
      className="w-full h-full"
      style={{ minHeight: '400px' }}
    />
  )
}

export default function LiveTrackingPage() {
  const { } = useAuth()
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0])
  const [autoRefresh, setAutoRefresh] = useState(false)
  const [mapProvider, setMapProvider] = useState<'openstreetmap' | 'google'>('openstreetmap')
  const isLoading = false
  
  // 直接用 mock 数据生成 drivers 列表
  const drivers: DriverLocation[] = mockJourneys.filter(j => j.date === selectedDate && (j.status === 'active' || j.status === 'in_progress')).map(journey => {
    const driver = journey.driver || mockDrivers.find(d => d.id === journey.driver_id)
    const truck = journey.truck
    const location = mockTruckLocations.find(l => l.truck_id === truck?.id)
    return {
      driver_id: driver?.id || '',
      driver_name: driver?.name || 'Unknown',
      truck_name: truck?.display_name || 'Unknown',
      latitude: location?.latitude || 0,
      longitude: location?.longitude || 0,
      journey_id: journey.id,
      journey_name: journey.name,
      journey_status: journey.status,
      current_trip: 1,
      total_trips: journey.total_trips,
      last_updated: location?.timestamp || ''
    }
  })

  const fetchDriverLocations = () => {
    // Mock function for refresh button
    console.log('Refreshing driver locations...')
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
      case 'in_progress':
        return 'text-green-600'
      case 'pending':
        return 'text-yellow-600'
      case 'completed':
        return 'text-blue-600'
      default:
        return 'text-gray-600'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
      case 'in_progress':
        return '🚛'
      case 'pending':
        return '⏳'
      case 'completed':
        return '✅'
      default:
        return '📦'
    }
  }

  const formatLastUpdated = (timestamp: string) => {
    const date = new Date(timestamp)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)

    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins}m ago`
    const diffHours = Math.floor(diffMins / 60)
    return `${diffHours}h ago`
  }

  return (
    <ProtectedRoute>
      <Layout>
        <div className="h-screen flex flex-col">
          {/* Header */}
          <div className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Live Tracking
                </h1>
                <p className="text-sm text-gray-600 mt-1">
                  Real-time driver locations and journey status
                </p>
              </div>

              <div className="flex items-center gap-4">
                {/* Date Selector */}
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm"
                />

                {/* Auto Refresh Toggle */}
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={autoRefresh}
                    onChange={(e) => setAutoRefresh(e.target.checked)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">Auto-refresh (30s)</span>
                </label>

                {/* Map Provider Selector */}
                <select
                  value={mapProvider}
                  onChange={(e) => setMapProvider(e.target.value as 'openstreetmap' | 'google')}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm"
                >
                  <option value="openstreetmap">🗺️ OpenStreetMap</option>
                  <option value="google">🌍 Google Maps</option>
                </select>

                {/* Manual Refresh */}
                <button
                  onClick={fetchDriverLocations}
                  disabled={isLoading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-blue-300 text-sm font-medium"
                >
                  {isLoading ? '⏳ Refreshing...' : '🔄 Refresh'}
                </button>
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 flex overflow-hidden">
            {/* Map */}
            <div className="flex-1 relative">
              {drivers.length > 0 ? (
                mapProvider === 'google' ? (
                  <GoogleMap drivers={drivers} />
                ) : (
                  <LiveTrackingMap drivers={drivers} />
                )
              ) : (
                <div className="h-full flex items-center justify-center bg-gray-50">
                  <div className="text-center">
                    <div className="text-6xl mb-4">🗺️</div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      No active drivers
                    </h3>
                    <p className="text-gray-600">
                      No drivers are currently on active journeys for {selectedDate}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Driver List Sidebar */}
            <div className="w-96 bg-white border-l border-gray-200 overflow-y-auto">
              <div className="p-4">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Active Drivers ({drivers.length})
                </h2>

                {drivers.length === 0 && !isLoading && (
                  <div className="text-center py-8 text-gray-500">
                    No active drivers
                  </div>
                )}

                <div className="space-y-3">
                  {drivers.map((driver) => (
                    <div
                      key={driver.driver_id}
                      className="bg-gray-50 border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      {/* Driver Info */}
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-gray-900">
                            {driver.driver_name}
                          </h3>
                          <p className="text-sm text-gray-600">
                            🚛 {driver.truck_name}
                          </p>
                        </div>
                        <span className={`text-lg ${getStatusColor(driver.journey_status)}`}>
                          {getStatusIcon(driver.journey_status)}
                        </span>
                      </div>

                      {/* Journey Info */}
                      <div className="mb-2">
                        <p className="text-sm font-medium text-gray-700">
                          {driver.journey_name}
                        </p>
                        <p className="text-xs text-gray-500">
                          Trip {driver.current_trip} of {driver.total_trips}
                        </p>
                      </div>

                      {/* Progress Bar */}
                      <div className="mb-2">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-500 h-2 rounded-full transition-all"
                            style={{
                              width: `${(driver.current_trip / driver.total_trips) * 100}%`
                            }}
                          />
                        </div>
                      </div>

                      {/* Last Updated */}
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>📍 Location updated</span>
                        <span>{formatLastUpdated(driver.last_updated)}</span>
                      </div>

                      {/* View Details Button */}
                      <button
                        onClick={() => window.location.href = `/journeys/${driver.journey_id}`}
                        className="mt-3 w-full px-3 py-2 bg-blue-50 text-blue-700 rounded text-sm font-medium hover:bg-blue-100"
                      >
                        View Journey Details →
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
