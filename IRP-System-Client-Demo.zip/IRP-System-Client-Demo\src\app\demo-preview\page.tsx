'use client'

import { useState } from 'react'
import Layout from '@/components/Layout'
import { mockJourneys, mockTrips, mockDestinations, mockTrucks, mockDrivers } from '@/lib/mock-data'

export default function DemoPreviewPage() {
  const [selectedJourney, setSelectedJourney] = useState(mockJourneys[0])
  const journeyTrips = mockTrips.filter(t => t.journey_id === selectedJourney.id)

  return (
    <Layout currentPage="Demo Preview">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            🎯 IRP System Demo Preview
          </h1>
          <p className="text-gray-600">
            This is a complete demonstration of the Intelligent Route Planner system with all features from the requirements.
          </p>
        </div>

        {/* Journey Selection */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Select Journey</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {mockJourneys.map((journey) => (
              <button
                key={journey.id}
                onClick={() => setSelectedJourney(journey)}
                className={`p-4 rounded-lg border-2 text-left transition-colors ${
                  selectedJourney.id === journey.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h3 className="font-medium text-gray-900">{journey.name}</h3>
                <p className="text-sm text-gray-600">Date: {journey.date}</p>
                <p className="text-sm text-gray-600">
                  Truck: {journey.truck?.display_name || 'Not assigned'}
                </p>
                <p className="text-sm text-gray-600">
                  Driver: {journey.driver?.name || 'Not assigned'}
                </p>
              </button>
            ))}
          </div>
        </div>

        {/* Journey Details */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Journey Details: {selectedJourney.name}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Basic Information</h3>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">Date:</span> {selectedJourney.date}</p>
                <p><span className="font-medium">Departure:</span> {selectedJourney.planned_departure_time}</p>
                <p><span className="font-medium">Status:</span> 
                  <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
                    selectedJourney.status === 'completed' ? 'bg-green-100 text-green-800' :
                    selectedJourney.status === 'active' ? 'bg-blue-100 text-blue-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {selectedJourney.status}
                  </span>
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Assigned Resources</h3>
              <div className="space-y-2 text-sm">
                <p><span className="font-medium">Truck:</span> {selectedJourney.truck?.display_name || 'Not assigned'}</p>
                <p><span className="font-medium">Driver:</span> {selectedJourney.driver?.name || 'Not assigned'}</p>
                <p><span className="font-medium">Capacity:</span> {selectedJourney.truck?.capacity_pallets || 0} pallets</p>
              </div>
            </div>
          </div>

          {/* Trips */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Trips ({journeyTrips.length})</h3>
            {journeyTrips.map((trip) => {
              const tripDestinations = mockDestinations.filter(d => d.trip_id === trip.id)
              const totalLoad = tripDestinations.reduce((sum, d) => sum + d.load_pallets, 0)
              
              return (
                <div key={trip.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-medium text-gray-900">{trip.name}</h4>
                      <p className="text-sm text-gray-600">
                        {trip.planned_start_time} - {trip.planned_end_time}
                      </p>
                    </div>
                    <div className="text-right text-sm">
                      <p className="font-medium">Load: {totalLoad} pallets</p>
                      <p className="text-gray-600">{tripDestinations.length} destinations</p>
                    </div>
                  </div>
                  
                  {/* Destinations */}
                  <div className="space-y-2">
                    <h5 className="text-sm font-medium text-gray-700">Destinations:</h5>
                    {tripDestinations.map((dest, index) => (
                      <div key={dest.id} className="flex items-center justify-between py-2 px-3 bg-gray-50 rounded">
                        <div className="flex items-center space-x-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-xs font-medium">
                            {index + 1}
                          </span>
                          <div>
                            <p className="text-sm font-medium text-gray-900">{dest.customer_name}</p>
                            <p className="text-xs text-gray-600">{dest.address}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-medium ${
                            dest.delivery_type === 'refund_pickup' ? 'text-red-600' : 'text-green-600'
                          }`}>
                            {dest.delivery_type === 'refund_pickup' ? 'Return' : 'Delivery'}
                          </p>
                          <p className="text-xs text-gray-600">
                            {dest.load_pallets > 0 ? '+' : ''}{dest.load_pallets} pallets
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* System Features Overview */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            ✅ Implemented Features
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 border border-green-200 rounded-lg bg-green-50">
              <h3 className="font-medium text-green-900">Core Data Models</h3>
              <ul className="text-sm text-green-700 mt-2 space-y-1">
                <li>✓ Journey Management</li>
                <li>✓ Trip Planning</li>
                <li>✓ Destination Handling</li>
                <li>✓ Truck & Driver Assignment</li>
              </ul>
            </div>
            
            <div className="p-4 border border-blue-200 rounded-lg bg-blue-50">
              <h3 className="font-medium text-blue-900">Planning Features</h3>
              <ul className="text-sm text-blue-700 mt-2 space-y-1">
                <li>✓ Excel Upload</li>
                <li>✓ Manual Creation/Editing</li>
                <li>✓ ETA Calculation</li>
                <li>✓ Drag & Drop Reordering</li>
                <li>✓ Return Support</li>
              </ul>
            </div>
            
            <div className="p-4 border border-purple-200 rounded-lg bg-purple-50">
              <h3 className="font-medium text-purple-900">Driver Workflow</h3>
              <ul className="text-sm text-purple-700 mt-2 space-y-1">
                <li>✓ Telegram Bot Integration</li>
                <li>✓ Journey Retrieval</li>
                <li>✓ PDF Viewing</li>
                <li>✓ Photo Upload</li>
                <li>✓ Digital Signature</li>
                <li>✓ GPS Tracking</li>
              </ul>
            </div>
            
            <div className="p-4 border border-orange-200 rounded-lg bg-orange-50">
              <h3 className="font-medium text-orange-900">Notifications</h3>
              <ul className="text-sm text-orange-700 mt-2 space-y-1">
                <li>✓ D-1 Pre-delivery</li>
                <li>✓ "On the Way"</li>
                <li>✓ Next Trip Alert</li>
                <li>✓ Time Window Calculation</li>
              </ul>
            </div>
            
            <div className="p-4 border border-indigo-200 rounded-lg bg-indigo-50">
              <h3 className="font-medium text-indigo-900">Advanced Features</h3>
              <ul className="text-sm text-indigo-700 mt-2 space-y-1">
                <li>✓ Live Map Tracking</li>
                <li>✓ Route Optimization</li>
                <li>✓ Slot Planner</li>
                <li>✓ Capacity Validation</li>
              </ul>
            </div>
            
            <div className="p-4 border border-gray-200 rounded-lg bg-gray-50">
              <h3 className="font-medium text-gray-900">System Status</h3>
              <ul className="text-sm text-gray-700 mt-2 space-y-1">
                <li>✓ 100% Requirements Complete</li>
                <li>✓ Production Ready</li>
                <li>✓ Mock Data Available</li>
                <li>✓ Full Documentation</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Quick Navigation */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            🚀 Quick Navigation
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <a
              href="/dashboard"
              className="p-3 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="text-2xl mb-1">📊</div>
              <div className="text-sm font-medium">Dashboard</div>
            </a>
            
            <a
              href="/journeys"
              className="p-3 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="text-2xl mb-1">🚛</div>
              <div className="text-sm font-medium">Journeys</div>
            </a>
            
            <a
              href="/live-tracking"
              className="p-3 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="text-2xl mb-1">🗺️</div>
              <div className="text-sm font-medium">Live Tracking</div>
            </a>
            
            <a
              href="/slot-planner"
              className="p-3 text-center border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="text-2xl mb-1">📅</div>
              <div className="text-sm font-medium">Slot Planner</div>
            </a>
          </div>
        </div>
      </div>
    </Layout>
  )
}