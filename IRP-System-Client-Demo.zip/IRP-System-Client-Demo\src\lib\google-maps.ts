/**
 * Google Maps integration utilities for route planning
 */

export interface GoogleMapsDestination {
  address: string
  latitude?: number
  longitude?: number
}

/**
 * Generate a Google Maps URL for a trip with all destinations plotted
 * @param departureAddress - The starting point address
 * @param destinations - Array of destinations with addresses and coordinates
 * @param tripNumber - The trip number for display purposes
 * @returns Google Maps URL that opens with all destinations plotted
 */
export function generateGoogleMapsTripUrl(
  departureAddress: string,
  destinations: GoogleMapsDestination[]
): string {
  // Start with the departure address
  const waypoints: string[] = []

  // Add all destinations as waypoints
  // Always use addresses to avoid "Dropped Pin" issue on iOS
  destinations.forEach((dest) => {
    // Always use address instead of coordinates to ensure the address is displayed
    // This fixes the iOS issue where coordinates show as "Dropped Pin"
    waypoints.push(encodeURIComponent(dest.address))
  })

  // Create the Google Maps URL
  const baseUrl = 'https://www.google.com/maps/dir/'

  // Start with departure address
  const startPoint = encodeURIComponent(departureAddress)

  // Add all waypoints
  const waypointsParam = waypoints.join('/')

  // Construct the full URL
  const fullUrl = `${baseUrl}${startPoint}/${waypointsParam}`

  return fullUrl
}

/**
 * Generate a Google Maps URL for viewing all destinations on a map (without routing)
 * @param departureAddress - The starting point address
 * @param destinations - Array of destinations with addresses and coordinates
 * @param tripNumber - The trip number for display purposes
 * @returns Google Maps URL that opens with all destinations marked
 */
export function generateGoogleMapsViewUrl(
  departureAddress: string,
  destinations: GoogleMapsDestination[]
): string {
  // Collect all points (departure + destinations)
  const allPoints: string[] = []

  // Add departure point
  allPoints.push(encodeURIComponent(departureAddress))

  // Add all destinations
  // Always use addresses to avoid "Dropped Pin" issue on iOS
  destinations.forEach((dest) => {
    // Always use address instead of coordinates to ensure the address is displayed
    allPoints.push(encodeURIComponent(dest.address))
  })

  // Create the Google Maps URL for viewing multiple points
  const baseUrl = 'https://www.google.com/maps/search/'
  const pointsParam = allPoints.join('/')

  return `${baseUrl}${pointsParam}`
}

/**
 * Open Google Maps in a new tab for a trip
 * @param departureAddress - The starting point address
 * @param destinations - Array of destinations with addresses and coordinates
 * @param tripNumber - The trip number for display purposes
 * @param mode - 'route' for turn-by-turn directions, 'view' for just viewing all points
 */
export function openGoogleMapsTrip(
  departureAddress: string,
  destinations: GoogleMapsDestination[],
  tripNumber: number,
  mode: 'route' | 'view' = 'route'
): void {
  const url = mode === 'route' 
    ? generateGoogleMapsTripUrl(departureAddress, destinations)
    : generateGoogleMapsViewUrl(departureAddress, destinations)
  
  // Open in new tab
  window.open(url, '_blank', 'noopener,noreferrer')
}

/**
 * Copy Google Maps URL to clipboard
 * @param departureAddress - The starting point address
 * @param destinations - Array of destinations with addresses and coordinates
 * @param tripNumber - The trip number for display purposes
 * @param mode - 'route' for turn-by-turn directions, 'view' for just viewing all points
 * @returns Promise that resolves when URL is copied to clipboard
 */
export async function copyGoogleMapsUrl(
  departureAddress: string,
  destinations: GoogleMapsDestination[],
  tripNumber: number,
  mode: 'route' | 'view' = 'route'
): Promise<void> {
  const url = mode === 'route' 
    ? generateGoogleMapsTripUrl(departureAddress, destinations)
    : generateGoogleMapsViewUrl(departureAddress, destinations)
  
  try {
    await navigator.clipboard.writeText(url)
  } catch (error) {
    console.error('Failed to copy URL to clipboard:', error)
    // Fallback: show the URL in an alert
    alert(`Google Maps URL for Trip ${tripNumber}:\n\n${url}`)
  }
}

