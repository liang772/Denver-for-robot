'use client'

import { useEffect, useRef, useState } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { getOptimizedRoute, RoutePoint } from '@/lib/routing'
import { createClient } from '@/lib/supabase'

// Fix for default markers in Next.js
delete (L.Icon.Default.prototype as unknown as Record<string, unknown>)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
})

interface DriverLocation {
  id: string
  driver_id: string
  truck_id: string
  journey_id: string | null
  latitude: number
  longitude: number
  accuracy?: number
  heading?: number
  speed?: number
  source: string
  created_at: string
  driver?: {
    name: string
  }
  truck?: {
    display_name: string
  }
  journey?: {
    name: string
    status: string
  }
}

interface Destination {
  id: string
  address: string
  preferredDeliveryTime: string
  order: number
  loadInfo: string
  tailgate: boolean
}

interface TripDestination {
  id: string
  trip_id: string
  trip_order: number
  address: string
  latitude?: number
  longitude?: number
  load_info?: string
  load_pallets: number
  requires_tailgate: boolean
  estimated_arrival_time?: string
  actual_arrival_time?: string
  actual_departure_time?: string
  notes?: string
  created_at: string
  updated_at: string
}

interface Trip {
  id: string
  trip_number: number
  trip_destinations?: TripDestination[]
  destinations?: Destination[] // For backward compatibility
  totalLoad?: number
  total_load?: number
  estimatedDuration?: string
  startTime?: string
  endTime?: string
}

interface TripMapProps {
  trips: Trip[]
  departureAddress: string
  showDriverLocations?: boolean
  userId?: string
}

// Get coordinates from destination data or fallback to geocoding
const getCoordinates = (destination: TripDestination | Destination): [number, number] => {
  // If we have exact coordinates, use them (preferred)
  if ('latitude' in destination && 'longitude' in destination && 
      destination.latitude && destination.longitude) {
    return [destination.latitude, destination.longitude]
  }
  
  // Fallback to address-based coordinates for backward compatibility
  const coordinateMap: { [key: string]: [number, number] } = {
    '20 Changi Business Park Central 2, Singapore 486031': [1.3344, 103.9632], // Departure
    '1 Jurong West Central 2, Jurong Gateway, Singapore 648886': [1.3402, 103.7070],
    '10 Tampines Central 1, Tampines Mall, Singapore 529536': [1.3496, 103.9426],
    '68 Orchard Road, Plaza Singapura, Singapore 238839': [1.3006, 103.8449],
    '23 Serangoon Central, NEX Mall, Singapore 556083': [1.3505, 103.8719],
    '2 Jurong East Street 21, IMM Building, Singapore 609601': [1.3335, 103.7403],
    '3 Temasek Boulevard, Suntec City, Singapore 038983': [1.2953, 103.8584],
    '1 Woodlands Square, Causeway Point, Singapore 738099': [1.4361, 103.7860],
    '930 Yishun Avenue 2, Northpoint City, Singapore 769098': [1.4297, 103.8359],
  }
  
  return coordinateMap[destination.address] || [1.3521, 103.8198] // Default to Singapore center
}

// Get coordinates for departure address (string-based)
const getDepartureCoordinates = (address: string): [number, number] => {
  const coordinateMap: { [key: string]: [number, number] } = {
    '20 Changi Business Park Central 2, Singapore 486031': [1.3344, 103.9632], // Departure
    '1 Jurong West Central 2, Jurong Gateway, Singapore 648886': [1.3402, 103.7070],
    '10 Tampines Central 1, Tampines Mall, Singapore 529536': [1.3496, 103.9426],
    '68 Orchard Road, Plaza Singapura, Singapore 238839': [1.3006, 103.8449],
    '23 Serangoon Central, NEX Mall, Singapore 556083': [1.3505, 103.8719],
    '2 Jurong East Street 21, IMM Building, Singapore 609601': [1.3335, 103.7403],
    '3 Temasek Boulevard, Suntec City, Singapore 038983': [1.2953, 103.8584],
    '1 Woodlands Square, Causeway Point, Singapore 738099': [1.4361, 103.7860],
    '930 Yishun Avenue 2, Northpoint City, Singapore 769098': [1.4297, 103.8359],
  }
  
  return coordinateMap[address] || [1.3521, 103.8198] // Default to Singapore center
}

// Trip colors
const getTripColor = (tripNumber: number): string => {
  const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4']
  return colors[(tripNumber - 1) % colors.length]
}



export default function TripMap({ trips, departureAddress, showDriverLocations = true, userId }: TripMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<L.Map | null>(null)
  const [isRouting, setIsRouting] = useState(false)
  const [visibleTrips, setVisibleTrips] = useState<Set<number>>(new Set(trips.map(trip => trip.trip_number)))
  const [driverLocations, setDriverLocations] = useState<DriverLocation[]>([])
  const driverMarkersRef = useRef<Map<string, L.Marker>>(new Map())
  const locationUpdateIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Function to toggle trip visibility
  const toggleTripVisibility = (tripNumber: number) => {
    setVisibleTrips(prev => {
      const newSet = new Set(prev)
      if (newSet.has(tripNumber)) {
        newSet.delete(tripNumber)
      } else {
        newSet.add(tripNumber)
      }
      return newSet
    })
  }

  // Function to fetch driver locations
  const fetchDriverLocations = async () => {
    if (!userId || !showDriverLocations) return

    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from('irp_latest_driver_locations')
        .select(`
          *,
          driver:irp_drivers(name),
          truck:irp_trucks(display_name),
          journey:irp_journeys(name, status)
        `)
        .eq('user_id', userId)

      if (error) throw error
      setDriverLocations(data || [])
    } catch (error) {
      console.error('Error fetching driver locations:', error)
    }
  }

  // Function to add/update driver markers on map
  const updateDriverMarkers = (map: L.Map, locations: DriverLocation[]) => {
    if (!map || !locations) return

    // Remove markers for drivers no longer in list
    const currentDriverIds = new Set(locations.map(loc => loc.driver_id))
    for (const [driverId, marker] of driverMarkersRef.current.entries()) {
      if (!currentDriverIds.has(driverId)) {
        marker.remove()
        driverMarkersRef.current.delete(driverId)
      }
    }

    // Add or update markers for each driver
    locations.forEach(location => {
      const { latitude, longitude, driver_id, driver, truck, journey, speed, heading, created_at } = location

      // Create custom driver icon
      const iconHtml = `
        <div style="
          background-color: ${journey?.status === 'in_progress' ? '#10B981' : '#F59E0B'};
          border: 3px solid white;
          border-radius: 50%;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          ${heading ? `transform: rotate(${heading}deg);` : ''}
        ">
          🚛
        </div>
      `

      const driverIcon = L.divIcon({
        html: iconHtml,
        className: 'driver-marker',
        iconSize: [40, 40],
        iconAnchor: [20, 20],
      })

      // Create popup content
      const timeSince = getTimeSince(created_at)
      const popupContent = `
        <div style="min-width: 200px;">
          <h3 style="font-weight: bold; margin-bottom: 8px; font-size: 16px;">
            🚛 ${driver?.name || 'Unknown Driver'}
          </h3>
          <div style="font-size: 13px; line-height: 1.6;">
            <div style="margin-bottom: 4px;">
              <strong>Truck:</strong> ${truck?.display_name || 'N/A'}
            </div>
            ${journey ? `
              <div style="margin-bottom: 4px;">
                <strong>Journey:</strong> ${journey.name}
              </div>
              <div style="margin-bottom: 4px;">
                <strong>Status:</strong> 
                <span style="
                  padding: 2px 8px;
                  border-radius: 12px;
                  background-color: ${journey.status === 'in_progress' ? '#D1FAE5' : '#FEF3C7'};
                  color: ${journey.status === 'in_progress' ? '#065F46' : '#92400E'};
                  font-weight: 600;
                  font-size: 11px;
                ">
                  ${journey.status === 'in_progress' ? '🟢 Active' : '🟡 Idle'}
                </span>
              </div>
            ` : ''}
            ${speed !== null && speed !== undefined ? `
              <div style="margin-bottom: 4px;">
                <strong>Speed:</strong> ${speed.toFixed(1)} km/h
              </div>
            ` : ''}
            <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #E5E7EB; color: #6B7280; font-size: 11px;">
              Last updated: ${timeSince}
            </div>
          </div>
        </div>
      `

      // Update existing marker or create new one
      const existingMarker = driverMarkersRef.current.get(driver_id)
      if (existingMarker) {
        existingMarker.setLatLng([latitude, longitude])
        existingMarker.setIcon(driverIcon)
        existingMarker.setPopupContent(popupContent)
      } else {
        const marker = L.marker([latitude, longitude], { icon: driverIcon })
          .bindPopup(popupContent)
          .addTo(map)
        driverMarkersRef.current.set(driver_id, marker)
      }
    })
  }

  // Helper function to calculate time since last update
  const getTimeSince = (timestamp: string): string => {
    const now = new Date()
    const then = new Date(timestamp)
    const seconds = Math.floor((now.getTime() - then.getTime()) / 1000)

    if (seconds < 60) return `${seconds}s ago`
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
    return `${Math.floor(seconds / 86400)}d ago`
  }

  // Function to add road routes to the map
  const addRoadRoutes = async (map: L.Map, trips: Trip[], departureCoords: [number, number]) => {
    // Safety check - ensure map is valid and fully initialized
    if (!map || !map.getContainer() || !map.getContainer().parentNode) {
      console.warn('Map not properly initialized, skipping road routes')
      return
    }
    
    // Additional check to ensure map is ready for DOM manipulation
    if (!map.getContainer().isConnected) {
      console.warn('Map container not connected to DOM, skipping road routes')
      return
    }
    
    // Safety check - ensure we have valid trips
    if (!trips || trips.length === 0) {
      console.warn('No trips provided, skipping road routes')
      return
    }
    
    setIsRouting(true)
    
    try {
      for (const trip of trips) {
        // Safety check - ensure trip is valid
        if (!trip || !trip.trip_number) {
          console.warn('Invalid trip data, skipping')
          continue
        }
        
        // Skip if trip is not visible
        if (!visibleTrips.has(trip.trip_number)) {
          continue
        }
        
        const tripColor = getTripColor(trip.trip_number)
        
        // Create waypoints for this trip: departure -> destinations -> return to departure
        const destinations = trip.trip_destinations || trip.destinations || []
        
        // Safety check - ensure we have destinations
        if (destinations.length === 0) {
          console.warn(`No destinations found for trip ${trip.trip_number}, skipping`)
          continue
        }
        
        const waypoints: RoutePoint[] = [
          { lat: departureCoords[0], lng: departureCoords[1] },
          ...destinations.map(dest => {
            const coords = getCoordinates(dest)
            return { lat: coords[0], lng: coords[1] }
          }),
          { lat: departureCoords[0], lng: departureCoords[1] } // Return to start
        ]
        
        // Get the optimized route for this trip
        const route = await getOptimizedRoute(waypoints, false) // Don't add return automatically since we already included it
        
        // Safety check - ensure route and segments exist
        if (!route || !route.segments || route.segments.length === 0) {
          console.warn(`No route segments found for trip ${trip.trip_number}`)
          return
        }
        
        // Draw each segment of the route
        route.segments.forEach((segment, segmentIndex) => {
          // Safety check - ensure segment and coordinates exist
          if (!segment || !segment.coordinates || segment.coordinates.length === 0) {
            console.warn(`No coordinates found for trip ${trip.trip_number}, segment ${segmentIndex}`)
            return
          }
          
          const segmentCoords: [number, number][] = segment.coordinates.map(coord => [coord.lat, coord.lng])
          
          // Additional safety check for valid coordinates
          if (segmentCoords.length === 0) {
            console.warn(`Empty coordinates array for trip ${trip.trip_number}, segment ${segmentIndex}`)
            return
          }
          
          // Create the polyline for this segment
          const polyline = L.polyline(segmentCoords, {
            color: tripColor,
            weight: 4,
            opacity: 0.8,
            dashArray: trip.trip_number > 1 ? '8, 8' : undefined // Dashed line for subsequent trips
          })
          
          // Safety check before adding to map
          if (map && map.getContainer() && polyline && map.getContainer().parentNode) {
            try {
              polyline.addTo(map)
            } catch (error) {
              console.warn(`Failed to add polyline to map for trip ${trip.trip_number}, segment ${segmentIndex}:`, error)
              // Continue with other segments even if one fails
            }
          } else {
            console.warn(`Map not ready for polyline addition for trip ${trip.trip_number}, segment ${segmentIndex}`)
          }
          
          // Add popup with trip information
          const destinations = trip.trip_destinations || trip.destinations || []
          const totalLoad = trip.total_load || trip.totalLoad || 0
          const estimatedDuration = trip.estimatedDuration || 'Unknown'
          
          polyline.bindPopup(`
            <strong>Trip ${trip.trip_number} - Segment ${segmentIndex + 1}</strong><br/>
            ${destinations.length} destinations<br/>
            Load: ${totalLoad.toFixed(1)} pallets<br/>
            Duration: ${estimatedDuration}<br/>
            <em>Distance: ${segment.distance.toFixed(1)} km</em>
          `)
        })
      }
    } catch (error) {
      console.error('Error adding road routes:', error)
    } finally {
      setIsRouting(false)
    }
  }

  // Effect for initial map setup
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return

    // Ensure the map container is properly mounted
    if (!mapRef.current.parentElement) {
      console.warn('Map container not properly mounted')
      return
    }

    // Initialize map centered on Singapore
    const map = L.map(mapRef.current).setView([1.3521, 103.8198], 11)
    mapInstanceRef.current = map

    // Add OpenStreetMap tiles
    try {
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(map)
    } catch (error) {
      console.warn('Failed to add tile layer:', error)
    }

    // Add departure point marker
    const departureCoords = getDepartureCoordinates(departureAddress)
    const departureIcon = L.divIcon({
      html: `<div style="background-color: #059669; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">🏠</div>`,
      className: 'custom-div-icon',
      iconSize: [30, 30],
      iconAnchor: [15, 15]
    })
    
    try {
      L.marker(departureCoords, { icon: departureIcon })
        .addTo(map)
        .bindPopup(`<strong>Departure Point</strong><br/>${departureAddress}`)
    } catch (error) {
      console.warn('Failed to add departure marker:', error)
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [departureAddress])

  // Separate effect to handle trips updates without recreating the map
  useEffect(() => {
    if (!mapInstanceRef.current || !trips || trips.length === 0) return

    const map = mapInstanceRef.current
    
    // Clear existing routes and markers (except departure)
    map.eachLayer((layer) => {
      if (layer instanceof L.Polyline) {
        map.removeLayer(layer)
      } else if (layer instanceof L.Marker) {
        const popup = layer.getPopup()
        if (popup) {
          const content = popup.getContent()
          if (typeof content === 'string' && !content.includes('Departure Point')) {
            map.removeLayer(layer)
          } else if (typeof content === 'object' && content && 'textContent' in content && !content.textContent?.includes('Departure Point')) {
            map.removeLayer(layer)
          }
        } else {
          map.removeLayer(layer)
        }
      }
    })

    // Add markers and routes for updated trips
    const departureCoords = getDepartureCoordinates(departureAddress)
    const allCoords: [number, number][] = [departureCoords]
    
    trips.forEach((trip) => {
      // Skip if trip is not visible
      if (!visibleTrips.has(trip.trip_number)) {
        return
      }
      
      const destinations = trip.trip_destinations || trip.destinations || []
      destinations.forEach((destination, index) => {
        const coords = getCoordinates(destination)
        allCoords.push(coords)

        // Create custom marker for each destination
        const markerIcon = L.divIcon({
          html: `<div style="background-color: ${getTripColor(trip.trip_number)}; color: white; width: 25px; height: 25px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.2);">${index + 1}</div>`,
          className: 'custom-div-icon',
          iconSize: [25, 25],
          iconAnchor: [12.5, 12.5]
        })

        // Get destination info with fallbacks for different data structures
        const timeInfo = 'estimated_arrival_time' in destination ? destination.estimated_arrival_time : 
          ('preferredDeliveryTime' in destination ? destination.preferredDeliveryTime : 'Flexible')
        const loadInfo = 'load_pallets' in destination ? `${destination.load_pallets} pallets` : 
          ('loadInfo' in destination ? destination.loadInfo : 'Unknown')
        const tailgateInfo = 'requires_tailgate' in destination ? destination.requires_tailgate : 
          ('tailgate' in destination ? destination.tailgate : false)

        try {
          L.marker(coords, { icon: markerIcon })
            .addTo(map)
            .bindPopup(`
              <strong>Trip ${trip.trip_number} - Stop ${index + 1}</strong><br/>
              ${destination.address}<br/>
              <em>Time: ${timeInfo}</em><br/>
              <em>Load: ${loadInfo}</em><br/>
              <em>Tailgate: ${tailgateInfo ? 'Required 🚛' : 'Not Required 📦'}</em>
            `)
        } catch (error) {
          console.warn(`Failed to add marker for trip ${trip.trip_number}, destination ${index + 1}:`, error)
        }
      })
    })

    // Add road routes
    if (map && trips.length > 0) {
      const addRoutesWhenReady = () => {
        if (map.getContainer() && map.getContainer().isConnected) {
          addRoadRoutes(map, trips, departureCoords)
        } else {
          setTimeout(addRoutesWhenReady, 50)
        }
      }
      setTimeout(addRoutesWhenReady, 200)
    }

    // Fit map to show all markers
    if (allCoords.length > 1) {
      const group = new L.FeatureGroup(
        allCoords.map(coord => L.marker(coord))
      )
      map.fitBounds(group.getBounds().pad(0.1))
    }
  }, [trips, departureAddress, visibleTrips])

  // Effect for driver location tracking
  useEffect(() => {
    if (!showDriverLocations || !userId || !mapInstanceRef.current) return

    const map = mapInstanceRef.current

    // Initial fetch
    fetchDriverLocations()

    // Set up auto-refresh interval (every 30 seconds)
    locationUpdateIntervalRef.current = setInterval(() => {
      fetchDriverLocations()
    }, 30000)

    // Cleanup on unmount or when dependencies change
    return () => {
      if (locationUpdateIntervalRef.current) {
        clearInterval(locationUpdateIntervalRef.current)
        locationUpdateIntervalRef.current = null
      }
      // Remove all driver markers
      driverMarkersRef.current.forEach(marker => marker.remove())
      driverMarkersRef.current.clear()
    }
  }, [showDriverLocations, userId])

  // Effect to update driver markers when locations change
  useEffect(() => {
    if (!mapInstanceRef.current || !showDriverLocations || driverLocations.length === 0) return
    updateDriverMarkers(mapInstanceRef.current, driverLocations)
  }, [driverLocations, showDriverLocations])

  // Early return if no trips or invalid data
  if (!trips || trips.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Trip Route Map</h2>
          <div className="text-sm text-gray-600">
            No trips to display
          </div>
        </div>
        <div className="w-full h-96 rounded-lg border border-gray-200 flex items-center justify-center bg-gray-50">
          <div className="text-center text-gray-500">
            <svg className="mx-auto h-12 w-12 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.732-.894L15 4m0 13V4m0 0L9 7" />
            </svg>
            <p>No trips available to display on the map</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-900">Trip Route Map</h2>
        <div className="text-sm text-gray-600">
          Interactive map showing all trip routes
        </div>
      </div>
      
      {/* Legend */}
      <div className="mb-4 p-3 bg-gray-50 rounded-lg">
        <div className="flex flex-wrap items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-600 rounded-full flex items-center justify-center text-white text-xs">🏠</div>
            <span className="text-black font-medium">Starting Location</span>
          </div>
          {showDriverLocations && driverLocations.length > 0 && (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-green-500 rounded flex items-center justify-center text-white text-xs shadow-md">🚛</div>
              <span className="text-black font-medium">Live Driver ({driverLocations.length})</span>
            </div>
          )}
          {trips.map((trip) => {
            const destinations = trip.trip_destinations || trip.destinations || []
            const hasTailgate = destinations.some(dest => 
              'requires_tailgate' in dest ? dest.requires_tailgate : dest.tailgate
            )
            const isVisible = visibleTrips.has(trip.trip_number)
            return (
              <div 
                key={trip.id} 
                className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all duration-200 hover:bg-gray-100 ${
                  isVisible ? 'bg-white shadow-sm' : 'bg-gray-200 opacity-60'
                }`}
                onClick={() => toggleTripVisibility(trip.trip_number)}
                title={`Click to ${isVisible ? 'hide' : 'show'} Delivery Route ${trip.trip_number}`}
              >
                <div 
                  className={`w-4 h-4 rounded-full flex items-center justify-center text-white text-xs font-bold transition-all duration-200 ${
                    hasTailgate ? 'ring-2 ring-orange-400' : ''
                  } ${!isVisible ? 'opacity-50' : ''}`}
                  style={{ backgroundColor: isVisible ? getTripColor(trip.trip_number) : '#9CA3AF' }}
                >
                  {trip.trip_number}
                </div>
                <div className="flex items-center gap-2">
                  <span className={`font-medium transition-colors duration-200 ${
                    isVisible ? 'text-black' : 'text-gray-500'
                  }`}>
                    Delivery Route {trip.trip_number} ({destinations.length} stops)
                  </span>
                  {hasTailgate && (
                    <span className={`px-2 py-1 text-xs font-medium rounded-full transition-opacity duration-200 ${
                      isVisible ? 'bg-orange-100 text-orange-800' : 'bg-gray-300 text-gray-600'
                    }`}>
                      🚛 Tailgate
                    </span>
                  )}
                  <span className={`text-xs transition-opacity duration-200 ${
                    isVisible ? 'text-green-600' : 'text-gray-400'
                  }`}>
                    {isVisible ? '●' : '○'}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
        <div className="mt-3 pt-3 border-t border-gray-200">
          <div className="flex items-center gap-2 text-xs text-blue-600 mb-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
            </svg>
            <span><strong>Interactive Legend:</strong> Click on any delivery route to show/hide its waypoints on the map</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-600 mb-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>Routes now follow realistic road paths instead of direct lines</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-600">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
            <span>🚛 = Tailgate required, 📦 = No tailgate needed</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-600">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>⏰ = Time-constrained delivery windows</span>
          </div>
        </div>
      </div>

      {/* Map container */}
      <div className="relative">
        <div 
          ref={mapRef} 
          className="w-full h-96 rounded-lg border border-gray-200"
          style={{ minHeight: '400px' }}
        />
        
        {/* Loading overlay */}
        {isRouting && (
          <div className="absolute inset-0 bg-white bg-opacity-80 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-3"></div>
              <p className="text-gray-700 font-medium">Calculating road routes...</p>
              <p className="text-sm text-gray-500">This may take a few seconds</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="mt-3 text-xs text-gray-500">
        Map data © OpenStreetMap contributors. Click markers for details.
      </div>
    </div>
  )
}
