'use client'

/**
 * Journey Time Editor Component
 * Phase 2.1: Editable departure time with ETA recalculation
 */

import { useState } from 'react'
import { getETACalculator } from '@/lib/etaCalculator'
import { db } from '@/lib/database'
import { createClient } from '@/lib/supabase'

interface JourneyTimeEditorProps {
  journeyId: string
  currentDepartureTime?: string
  totalPlannedDuration?: number
  onUpdate?: (newTiming: any) => void
}

export default function JourneyTimeEditor({
  journeyId,
  currentDepartureTime,
  totalPlannedDuration,
  onUpdate
}: JourneyTimeEditorProps) {
  const [departureTime, setDepartureTime] = useState(currentDepartureTime || '08:00')
  const [isEditing, setIsEditing] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSave = async () => {
    try {
      setIsUpdating(true)
      setError(null)

      // Get ETA calculator
      const supabase = createClient()
      const etaCalculator = getETACalculator(supabase)

      // Recalculate ETAs with new departure time
      const newTiming = await etaCalculator.recalculateOnDepartureTimeChange(
        journeyId,
        departureTime
      )

      setIsEditing(false)
      
      if (onUpdate) {
        onUpdate(newTiming)
      }
    } catch (err) {
      console.error('Failed to update departure time:', err)
      setError(err instanceof Error ? err.message : 'Failed to update')
    } finally {
      setIsUpdating(false)
    }
  }

  const handleCancel = () => {
    setDepartureTime(currentDepartureTime || '08:00')
    setIsEditing(false)
    setError(null)
  }

  const formatDuration = (minutes?: number) => {
    if (!minutes) return 'N/A'
    const hours = Math.floor(minutes / 60)
    const mins = Math.round(minutes % 60)
    return `${hours}h ${mins}m`
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-gray-900">Journey Timing</h3>
        {!isEditing && (
          <button
            onClick={() => setIsEditing(true)}
            className="text-xs text-blue-600 hover:text-blue-700 font-medium"
          >
            ✏️ Edit
          </button>
        )}
      </div>

      <div className="space-y-3">
        {/* Departure Time */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Planned Departure:</span>
          {isEditing ? (
            <input
              type="time"
              value={departureTime}
              onChange={(e) => setDepartureTime(e.target.value)}
              className="px-2 py-1 border border-blue-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          ) : (
            <span className="text-sm font-semibold text-gray-900">
              {departureTime}
            </span>
          )}
        </div>

        {/* Total Planned Duration */}
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Total Duration:</span>
          <span className="text-sm font-semibold text-gray-900">
            {formatDuration(totalPlannedDuration)}
          </span>
        </div>

        {/* Estimated Completion */}
        {departureTime && totalPlannedDuration && (
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Est. Completion:</span>
            <span className="text-sm font-semibold text-gray-900">
              {calculateCompletionTime(departureTime, totalPlannedDuration)}
            </span>
          </div>
        )}
      </div>

      {/* Error Message */}
      {error && (
        <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-600">
          {error}
        </div>
      )}

      {/* Edit Actions */}
      {isEditing && (
        <div className="mt-4 flex gap-2">
          <button
            onClick={handleSave}
            disabled={isUpdating}
            className="flex-1 px-3 py-2 bg-blue-600 text-white text-sm font-medium rounded hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed"
          >
            {isUpdating ? '⏳ Recalculating ETAs...' : '💾 Save & Recalculate'}
          </button>
          <button
            onClick={handleCancel}
            disabled={isUpdating}
            className="px-3 py-2 bg-gray-200 text-gray-700 text-sm font-medium rounded hover:bg-gray-300 disabled:bg-gray-100"
          >
            Cancel
          </button>
        </div>
      )}

      {isUpdating && (
        <div className="mt-3 text-xs text-gray-500 italic">
          ⚡ Recalculating all destination ETAs...
        </div>
      )}
    </div>
  )
}

/**
 * Helper function to calculate completion time
 */
function calculateCompletionTime(departureTime: string, durationMinutes: number): string {
  try {
    const [hours, minutes] = departureTime.split(':').map(Number)
    const departureDate = new Date()
    departureDate.setHours(hours, minutes, 0, 0)
    
    const completionDate = new Date(departureDate.getTime() + durationMinutes * 60000)
    
    return completionDate.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    })
  } catch {
    return 'N/A'
  }
}
