'use client'

import { useState } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'

export default function TelegramPage() {
  useAuth() // Ensure user is authenticated
  const [phoneNumber, setPhoneNumber] = useState('')
  const [chatId, setChatId] = useState('')
  const [driverName, setDriverName] = useState('')
  const [message, setMessage] = useState('')
  const [testResult, setTestResult] = useState<string | null>(null)
  const [registrationResult, setRegistrationResult] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleTestNotification = async () => {
    if (!phoneNumber && !chatId) {
      alert('Please enter a phone number or chat ID')
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          phone: phoneNumber,
          chat_id: chatId,
          message: message || 'Test notification from IRP System',
          type: 'test'
        }),
      })

      const data = await response.json()

      if (response.ok && data.success) {
        setTestResult(`✅ Success: ${data.message}\n\nTimestamp: ${data.timestamp}`)
      } else {
        setTestResult(`❌ ${data.error || data.message}\n\n${data.note || data.details || ''}`)
      }
    } catch (error) {
      setTestResult(`❌ Error: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSendDeliveryNotification = async () => {
    if (!phoneNumber && !chatId) {
      alert('Please enter a phone number or chat ID')
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          phone: phoneNumber,
          chat_id: chatId,
          message: '🚚 Your delivery is scheduled for tomorrow between 09:00-12:00.\n\n📍 Address: 123 Main St\n📦 Items: 5 pallets\n\nTrack your delivery: https://irp.example.com/track/12345',
          type: 'delivery_notification'
        }),
      })

      const data = await response.json()

      if (response.ok && data.success) {
        setTestResult(`✅ Delivery notification sent: ${data.message}`)
      } else {
        setTestResult(`❌ ${data.error || data.message}\n\n${data.note || data.details || ''}`)
      }
    } catch (error) {
      setTestResult(`❌ Error: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleRegisterDriver = async () => {
    if (!phoneNumber || !chatId) {
      alert('Please enter both phone number and chat ID to register')
      return
    }

    setIsLoading(true)
    setRegistrationResult(null)

    try {
      // Store in localStorage for quick lookup
      const registrations = JSON.parse(localStorage.getItem('telegram_registrations') || '{}')
      registrations[phoneNumber] = {
        chat_id: chatId,
        driver_name: driverName || 'Unknown Driver',
        registered_at: new Date().toISOString()
      }
      localStorage.setItem('telegram_registrations', JSON.stringify(registrations))

      setRegistrationResult(`✅ Driver registered successfully!\n\nPhone: ${phoneNumber}\nChat ID: ${chatId}\n\nThis mapping is now available for sending notifications.`)
      
      // Clear form
      setDriverName('')
    } catch (error) {
      setRegistrationResult(`❌ Registration failed: ${error instanceof Error ? error.message : 'Unknown error'}`)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <ProtectedRoute>
      <Layout>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Telegram Bot Integration
            </h1>
            <p className="text-gray-600">
              Send delivery notifications via Telegram
            </p>
          </div>

          {/* Bot Information */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
            <h2 className="text-lg font-semibold text-blue-900 mb-4">
              📱 How to Use Telegram Notifications
            </h2>
            <ol className="space-y-2 text-sm text-blue-800">
              <li className="flex items-start gap-2">
                <span className="font-semibold">1.</span>
                <span>Customer searches for your bot on Telegram (e.g., @YourDeliveryBot)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">2.</span>
                <span>Customer sends /start command to activate notifications</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">3.</span>
                <span>Customer registers their phone number using /register +1234567890</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">4.</span>
                <span>Bot responds with their chat_id - copy this and register below</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold">5.</span>
                <span>System automatically sends delivery updates to registered customers</span>
              </li>
            </ol>
          </div>

          {/* Driver Registration Form */}
          <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              👤 Register Driver/Customer
            </h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  placeholder="+65 9123 4567"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Chat ID *
                </label>
                <input
                  type="text"
                  placeholder="123456789"
                  value={chatId}
                  onChange={(e) => setChatId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Get this from bot when customer sends /register command
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Driver/Customer Name (Optional)
                </label>
                <input
                  type="text"
                  placeholder="John Doe"
                  value={driverName}
                  onChange={(e) => setDriverName(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <button
              onClick={handleRegisterDriver}
              disabled={isLoading || !phoneNumber || !chatId}
              className="w-full px-6 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Registering...' : '✓ Register Phone → Chat ID Mapping'}
            </button>

            {registrationResult && (
              <div className={`mt-4 p-4 rounded-lg ${
                registrationResult.startsWith('✅') 
                  ? 'bg-green-50 border border-green-200 text-green-800' 
                  : 'bg-red-50 border border-red-200 text-red-800'
              }`}>
                <p className="text-sm whitespace-pre-wrap">{registrationResult}</p>
              </div>
            )}
          </div>

          {/* Test Notification Form */}
          <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              Test Telegram Notification
            </h2>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number (with country code)
                </label>
                <input
                  type="tel"
                  placeholder="+65 9123 4567"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Customer must have registered this number with the bot first
                </p>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">OR</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Chat ID (Direct)
                </label>
                <input
                  type="text"
                  placeholder="123456789"
                  value={chatId}
                  onChange={(e) => setChatId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Use chat ID for direct testing (get it from bot interactions)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Custom Message (Optional)
                </label>
                <textarea
                  placeholder="Enter custom message or leave empty for default test message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleTestNotification}
                disabled={isLoading}
                className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Sending...' : '📤 Send Test Message'}
              </button>

              <button
                onClick={handleSendDeliveryNotification}
                disabled={isLoading}
                className="flex-1 px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? 'Sending...' : '🚚 Send Delivery Notification'}
              </button>
            </div>

            {testResult && (
              <div className={`mt-4 p-4 rounded-lg ${
                testResult.startsWith('✅') 
                  ? 'bg-green-50 border border-green-200 text-green-800' 
                  : 'bg-red-50 border border-red-200 text-red-800'
              }`}>
                <p className="text-sm whitespace-pre-wrap">{testResult}</p>
              </div>
            )}
          </div>

          {/* Bot Commands Reference */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Available Bot Commands
            </h2>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">/start</code>
                <p className="text-sm text-gray-600">Activate the bot and get welcome message</p>
              </div>
              <div className="flex items-start gap-3">
                <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">/register +phone</code>
                <p className="text-sm text-gray-600">Register your phone number for delivery notifications</p>
              </div>
              <div className="flex items-start gap-3">
                <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">/track [code]</code>
                <p className="text-sm text-gray-600">Track your delivery using tracking code</p>
              </div>
              <div className="flex items-start gap-3">
                <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">/help</code>
                <p className="text-sm text-gray-600">Get help and list of available commands</p>
              </div>
              <div className="flex items-start gap-3">
                <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">/settings</code>
                <p className="text-sm text-gray-600">Manage notification preferences</p>
              </div>
            </div>
          </div>

          {/* Configuration Info */}
          <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-6">
            <h3 className="text-sm font-semibold text-yellow-900 mb-3">
              ⚙️ Bot Configuration Required
            </h3>
            <p className="text-sm text-yellow-800 mb-3">
              To use Telegram notifications, ensure the following environment variables are set:
            </p>
            <div className="bg-yellow-100 rounded p-3 font-mono text-xs">
              <div>TELEGRAM_BOT_TOKEN=your_bot_token_here</div>
              <div>NEXT_PUBLIC_TELEGRAM_BOT_USERNAME=@YourBotUsername</div>
            </div>
            <p className="text-xs text-yellow-700 mt-3">
              Get your bot token from @BotFather on Telegram
            </p>
          </div>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
