'use client'

import { useState, useEffect } from 'react'

interface RouteTemplate {
  id: string
  name: string
  description: string
  template_data: {
    destinations: Array<{
      address: string
      postal_code?: string
      load_pallets?: number
      estimated_arrival_time?: string
      requires_tailgate?: boolean
      notes?: string
    }>
    settings?: {
      departure_address?: string
      planned_departure_time?: string
      truck_capacity?: number
    }
  }
  created_at: string
  updated_at: string
}

interface TemplateManagerProps {
  userId: string
  onSelectTemplate?: (template: RouteTemplate) => void
  mode?: 'select' | 'manage'
}

export default function TemplateManager({
  userId,
  onSelectTemplate,
  mode = 'manage'
}: TemplateManagerProps) {
  const [templates, setTemplates] = useState<RouteTemplate[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedTemplate, setSelectedTemplate] = useState<RouteTemplate | null>(null)
  const [showDetails, setShowDetails] = useState(false)

  const fetchTemplates = async () => {
    try {
      setIsLoading(true)
      
      // Use mock data instead of database queries
      const mockTemplates: RouteTemplate[] = [
        {
          id: 'template-1',
          name: 'Beijing City Center Route',
          description: 'Standard delivery route covering major shopping centers in Beijing',
          template_data: {
            destinations: [
              {
                address: 'Guomao Shopping Center, Chaoyang District, Beijing',
                load_pallets: 8,
                estimated_arrival_time: '09:00',
                requires_tailgate: false,
                notes: 'Use loading dock entrance'
              },
              {
                address: 'Zhongguancun Plaza, Haidian District, Beijing',
                load_pallets: 6,
                estimated_arrival_time: '11:00',
                requires_tailgate: false,
                notes: 'Contact security first'
              },
              {
                address: 'Wangfujing Department Store, Dongcheng District, Beijing',
                load_pallets: -3,
                estimated_arrival_time: '13:00',
                requires_tailgate: false,
                notes: 'Return pickup - damaged goods'
              }
            ],
            settings: {
              departure_address: 'Beijing Distribution Center',
              planned_departure_time: '08:00',
              truck_capacity: 30
            }
          },
          created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          updated_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
          id: 'template-2',
          name: 'Suburban Mall Route',
          description: 'Weekly route for suburban shopping malls and retail centers',
          template_data: {
            destinations: [
              {
                address: 'Fengtai Wanda Plaza, Fengtai District, Beijing',
                load_pallets: 10,
                estimated_arrival_time: '10:00',
                requires_tailgate: true,
                notes: 'Large items delivery'
              },
              {
                address: 'Shijingshan Wanda Plaza, Shijingshan District, Beijing',
                load_pallets: 7,
                estimated_arrival_time: '14:00',
                requires_tailgate: false,
                notes: 'Standard delivery'
              }
            ],
            settings: {
              departure_address: 'Beijing Distribution Center',
              planned_departure_time: '09:00',
              truck_capacity: 25
            }
          },
          created_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
          updated_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
        }
      ]
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 500))
      
      setTemplates(mockTemplates)
    } catch (err) {
      console.error('Error fetching templates:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch templates')
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchTemplates()
  }, [userId])

  const handleDelete = async (templateId: string) => {
    if (!confirm('Are you sure you want to delete this template? This action cannot be undone.')) {
      return
    }

    try {
      // Simulate delete operation
      setTemplates(prev => prev.filter(t => t.id !== templateId))
      if (selectedTemplate?.id === templateId) {
        setSelectedTemplate(null)
        setShowDetails(false)
      }
    } catch (err) {
      console.error('Error deleting template:', err)
      alert(err instanceof Error ? err.message : 'Failed to delete template')
    }
  }

  const handleSelect = (template: RouteTemplate) => {
    if (mode === 'select' && onSelectTemplate) {
      onSelectTemplate(template)
    } else {
      setSelectedTemplate(template)
      setShowDetails(true)
    }
  }

  const handleDuplicate = async (template: RouteTemplate) => {
    try {
      // Create a new template copy
      const newTemplate: RouteTemplate = {
        id: `template-${Date.now()}`,
        name: `${template.name} (Copy)`,
        description: template.description,
        template_data: template.template_data,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }

      setTemplates(prev => [newTemplate, ...prev])
    } catch (err) {
      console.error('Error duplicating template:', err)
      alert(err instanceof Error ? err.message : 'Failed to duplicate template')
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-6 bg-red-50 border border-red-200 rounded-lg">
        <p className="text-red-800">{error}</p>
      </div>
    )
  }

  if (templates.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
        <svg className="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No templates yet</h3>
        <p className="text-gray-600">
          Create your first route template by saving a journey configuration
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map((template) => {
          const destinationCount = template.template_data.destinations?.length || 0
          const formattedDate = new Date(template.updated_at).toLocaleDateString()

          return (
            <div
              key={template.id}
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => handleSelect(template)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {template.name}
                  </h3>
                  {template.description && (
                    <p className="text-sm text-gray-600 line-clamp-2">
                      {template.description}
                    </p>
                  )}
                </div>
                <div className="ml-2 flex-shrink-0">
                  <svg className="w-6 h-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  {destinationCount} stops
                </span>
                <span className="flex items-center gap-1">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {formattedDate}
                </span>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-gray-200">
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    handleSelect(template)
                  }}
                  className="flex-1 px-3 py-1.5 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {mode === 'select' ? 'Use Template' : 'View'}
                </button>
                {mode === 'manage' && (
                  <>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDuplicate(template)
                      }}
                      className="px-3 py-1.5 text-sm bg-gray-200 text-gray-700 rounded hover:bg-gray-300 focus:outline-none"
                      title="Duplicate"
                    >
                      📋
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDelete(template.id)
                      }}
                      className="px-3 py-1.5 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200 focus:outline-none"
                      title="Delete"
                    >
                      🗑️
                    </button>
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {/* Template Details Modal */}
      {showDetails && selectedTemplate && mode === 'manage' && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{selectedTemplate.name}</h2>
                <button
                  onClick={() => {
                    setShowDetails(false)
                    setSelectedTemplate(null)
                  }}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {selectedTemplate.description && (
                <p className="text-gray-600 mb-6">{selectedTemplate.description}</p>
              )}

              {/* Settings */}
              {selectedTemplate.template_data.settings && (
                <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                  <h3 className="text-sm font-semibold text-gray-900 mb-3">Settings</h3>
                  <div className="space-y-2 text-sm">
                    {selectedTemplate.template_data.settings.departure_address && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Departure:</span>
                        <span className="font-medium">{selectedTemplate.template_data.settings.departure_address}</span>
                      </div>
                    )}
                    {selectedTemplate.template_data.settings.planned_departure_time && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Departure Time:</span>
                        <span className="font-medium">{selectedTemplate.template_data.settings.planned_departure_time}</span>
                      </div>
                    )}
                    {selectedTemplate.template_data.settings.truck_capacity && (
                      <div className="flex justify-between">
                        <span className="text-gray-600">Truck Capacity:</span>
                        <span className="font-medium">{selectedTemplate.template_data.settings.truck_capacity} pallets</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Destinations */}
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-900 mb-3">
                  Destinations ({selectedTemplate.template_data.destinations?.length || 0})
                </h3>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {selectedTemplate.template_data.destinations?.map((dest, idx) => (
                    <div key={idx} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-medium text-gray-500">#{idx + 1}</span>
                            {dest.requires_tailgate && (
                              <span className="px-2 py-0.5 text-xs bg-orange-100 text-orange-700 rounded">
                                🚛 Tailgate
                              </span>
                            )}
                          </div>
                          <p className="text-sm font-medium text-gray-900">{dest.address}</p>
                          <div className="flex items-center gap-3 text-xs text-gray-600 mt-1">
                            {dest.load_pallets !== undefined && (
                              <span>📦 {dest.load_pallets} pallets</span>
                            )}
                            {dest.estimated_arrival_time && (
                              <span>⏰ {dest.estimated_arrival_time}</span>
                            )}
                          </div>
                          {dest.notes && (
                            <p className="text-xs text-gray-500 mt-1 italic">{dest.notes}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => {
                    setShowDetails(false)
                    setSelectedTemplate(null)
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Close
                </button>
                <button
                  onClick={() => handleDuplicate(selectedTemplate)}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
                >
                  Duplicate Template
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
