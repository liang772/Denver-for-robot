import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

export async function POST(request: NextRequest) {
  try {
    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 })
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    // 创建卡车
    const { data: trucks } = await supabase
      .from('irp_trucks')
      .insert([
        { user_id: userId, license_plate: 'A12345', model: '东风天龙', capacity_pallets: 30, status: 'available' },
        { user_id: userId, license_plate: 'B67890', model: '解放J6', capacity_pallets: 25, status: 'available' }
      ])
      .select()

    if (!trucks || trucks.length === 0) {
      return NextResponse.json({ error: '创建卡车失败' }, { status: 500 })
    }

    const truck1 = trucks[0]
    const truck2 = trucks[1]

    // 创建司机
    const { data: drivers } = await supabase
      .from('irp_drivers')
      .insert([
        { user_id: userId, name: '张师傅', phone: '13800138001', license_number: 'D1234567', status: 'available' },
        { user_id: userId, name: '李师傅', phone: '13900139002', license_number: 'D2345678', status: 'available' }
      ])
      .select()

    if (!drivers || drivers.length === 0) {
      return NextResponse.json({ error: '创建司机失败' }, { status: 500 })
    }

    const driver1 = drivers[0]
    const driver2 = drivers[1]

    // 创建Routes
    const today = new Date().toISOString().split('T')[0]
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0]

    const { data: routes } = await supabase
      .from('irp_routes')
      .insert([
        { user_id: userId, name: `演示路线 - ${today}`, date: today, status: 'pending' },
        { user_id: userId, name: `演示路线 - ${tomorrow}`, date: tomorrow, status: 'pending' }
      ])
      .select()

    if (!routes || routes.length === 0) {
      return NextResponse.json({ error: '创建路线失败' }, { status: 500 })
    }

    const route1 = routes[0]
    const route2 = routes[1]

    // 创建Trips
    const { data: trips } = await supabase
      .from('irp_trips')
      .insert([
        { user_id: userId, route_id: route1.id, truck_id: truck1.id, driver_id: driver1.id, sequence: 1, loading_time: 30, status: 'pending' },
        { user_id: userId, route_id: route1.id, truck_id: truck1.id, driver_id: driver1.id, sequence: 2, loading_time: 25, status: 'pending' },
        { user_id: userId, route_id: route2.id, truck_id: truck2.id, driver_id: driver2.id, sequence: 1, loading_time: 30, status: 'pending' }
      ])
      .select()

    if (!trips || trips.length === 0) {
      return NextResponse.json({ error: '创建行程失败' }, { status: 500 })
    }

    const trip1 = trips[0]
    const trip2 = trips[1]
    const trip3 = trips[2]

    // 创建Destinations
    const destinations = [
      // Trip 1
      { trip_id: trip1.id, sequence: 0, address: '北京市朝阳区建国门外大街1号 - 国贸商城', latitude: 39.9087, longitude: 116.4585, load_pallets: 8, time_to_location: 25, offloading_time: 20, delivery_type: 'delivery' },
      { trip_id: trip1.id, sequence: 1, address: '北京市海淀区中关村大街27号 - 中关村广场', latitude: 39.9806, longitude: 116.3142, load_pallets: 6, time_to_location: 30, offloading_time: 15, delivery_type: 'delivery' },
      { trip_id: trip1.id, sequence: 2, address: '北京市东城区王府井大街255号 - 王府井百货', latitude: 39.9155, longitude: 116.4093, load_pallets: -3, time_to_location: 20, offloading_time: 15, delivery_type: 'refund_pickup' },
      { trip_id: trip1.id, sequence: 3, address: '北京市西城区金融街35号 - 金融街购物中心', latitude: 39.9153, longitude: 116.3644, load_pallets: 5, time_to_location: 18, offloading_time: 12, delivery_type: 'delivery' },
      // Trip 2
      { trip_id: trip2.id, sequence: 0, address: '北京市丰台区南三环西路16号 - 丰台万达广场', latitude: 39.8547, longitude: 116.2869, load_pallets: 10, time_to_location: 35, offloading_time: 25, delivery_type: 'delivery' },
      { trip_id: trip2.id, sequence: 1, address: '北京市石景山区石景山路22号 - 万达广场', latitude: 39.9067, longitude: 116.2223, load_pallets: -5, time_to_location: 25, offloading_time: 18, delivery_type: 'refund_pickup' },
      { trip_id: trip2.id, sequence: 2, address: '北京市海淀区复兴路51号 - 五棵松购物中心', latitude: 39.9065, longitude: 116.2812, load_pallets: 7, time_to_location: 15, offloading_time: 15, delivery_type: 'delivery' },
      // Trip 3
      { trip_id: trip3.id, sequence: 0, address: '北京市朝阳区大望路SOHO现代城', latitude: 39.9088, longitude: 116.4722, load_pallets: 12, time_to_location: 30, offloading_time: 20, delivery_type: 'delivery' },
      { trip_id: trip3.id, sequence: 1, address: '北京市朝阳区三里屯太古里', latitude: 39.9349, longitude: 116.4553, load_pallets: 8, time_to_location: 20, offloading_time: 18, delivery_type: 'delivery' }
    ]

    await supabase.from('irp_trip_destinations').insert(destinations)

    // 创建位置数据
    await supabase
      .from('irp_truck_latest_location')
      .insert([
        { truck_id: truck1.id, latitude: 39.9042, longitude: 116.4074, timestamp: new Date().toISOString(), speed: 35.5, heading: 90 },
        { truck_id: truck2.id, latitude: 39.9163, longitude: 116.3972, timestamp: new Date().toISOString(), speed: 28.3, heading: 180 }
      ])

    return NextResponse.json({
      success: true,
      data: {
        trucks: trucks.length,
        drivers: drivers.length,
        routes: routes.length,
        trips: trips.length,
        destinations: destinations.length
      }
    })

  } catch (error: any) {
    console.error('创建演示数据失败:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
