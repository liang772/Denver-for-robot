'use client'

/**
 * Feature Demo & Testing Page
 * Demonstrate and test all newly implemented features
 */

import { useState } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'
import Link from 'next/link'
import { mockJourneys, mockTrips, mockDestinations, mockTrucks } from '@/lib/mock-data'

export default function DemoPage() {
  const { } = useAuth()
  const [activeDemo, setActiveDemo] = useState<string>('eta')
  const [demoResults, setDemoResults] = useState<Record<string, any> | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Demo 1: ETA Calculation Demo
  const demoETACalculation = async () => {
    setIsLoading(true)
    setError(null)
    setDemoResults(null)

    try {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Use mock data to simulate ETA calculation
      const journey = mockJourneys[0]
      const trips = mockTrips.filter(t => t.journey_id === journey.id)
      const destinations = mockDestinations.filter(d => 
        trips.some(t => t.id === d.trip_id)
      )

      // Simulate ETA calculation
      let cumulativeTime = 0
      const departureTime = new Date()
      departureTime.setHours(8, 0, 0, 0) // 8:00 AM

      const etaResults = destinations.map((dest, idx) => {
        cumulativeTime += (dest.time_to_location || 20) + (dest.offloading_time || 15)
        const eta = new Date(departureTime.getTime() + cumulativeTime * 60000)
        
        return {
          address: dest.address,
          estimatedArrivalTime: eta.toISOString(),
          cumulativeTravelTime: cumulativeTime,
          cumulativeServiceTime: (idx + 1) * 15
        }
      })

      setDemoResults({
        type: 'eta',
        title: 'ETA Calculation Results',
        journeyId: journey.id,
        summary: {
          departureTime: departureTime.toISOString(),
          totalDuration: `${Math.floor(cumulativeTime / 60)}h ${cumulativeTime % 60}m`,
          totalTrips: trips.length,
          totalDestinations: destinations.length
        },
        destinations: etaResults
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'ETA calculation failed')
    } finally {
      setIsLoading(false)
    }
  }

  // Demo 2: Capacity Validation Demo
  const demoCapacityValidation = async () => {
    setIsLoading(true)
    setError(null)
    setDemoResults(null)

    try {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Use mock data for capacity validation
      const journey = mockJourneys[0]
      const truck = mockTrucks.find(t => t.id === journey.truck_id)
      const destinations = mockDestinations.filter(d => 
        mockTrips.some(t => t.journey_id === journey.id && t.id === d.trip_id)
      )

      // Simulate capacity calculation
      let currentLoad = 0
      let maxLoad = 0
      const violations: Array<{destination: string, load: number, capacity: number}> = []

      destinations.forEach((dest) => {
        currentLoad += dest.load_pallets
        if (currentLoad > maxLoad) maxLoad = currentLoad
        
        if (currentLoad > (truck?.capacity_pallets || 30)) {
          violations.push({
            destination: dest.address,
            load: currentLoad,
            capacity: truck?.capacity_pallets || 30
          })
        }
      })

      const isValid = violations.length === 0

      setDemoResults({
        type: 'capacity',
        title: 'Capacity Validation Results',
        analysis: {
          isValid,
          truckCapacity: truck?.capacity_pallets || 30,
          maxLoadReached: maxLoad,
          finalLoad: currentLoad,
          violations
        },
        summary: {
          isValid,
          totalViolations: violations.length,
          truckCapacity: truck?.capacity_pallets || 30,
          utilization: ((maxLoad / (truck?.capacity_pallets || 30)) * 100).toFixed(1) + '%'
        }
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Capacity validation failed')
    } finally {
      setIsLoading(false)
    }
  }

  // Demo 3: Delivery Types Demo
  const demoDeliveryTypes = async () => {
    setIsLoading(true)
    setError(null)
    setDemoResults(null)

    try {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Use mock data to show different delivery types
      const destinations = mockDestinations.slice(0, 5).map(dest => ({
        address: dest.address,
        type: dest.delivery_type,
        load: dest.load_pallets,
        icon: dest.delivery_type === 'delivery' ? '📦' : '📥',
        color: dest.delivery_type === 'delivery' ? 'blue' : 'orange',
        description: dest.delivery_type === 'delivery' 
          ? `Delivery: ${dest.load_pallets} pallets (reduces load)` 
          : `Pickup: ${Math.abs(dest.load_pallets)} pallets (increases load)`
      }))

      setDemoResults({
        type: 'delivery',
        title: 'Delivery Types Demo',
        destinations
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Delivery types demo failed')
    } finally {
      setIsLoading(false)
    }
  }

  // Demo 4: Notifications Demo
  const demoNotifications = async () => {
    setIsLoading(true)
    setError(null)
    setDemoResults(null)

    try {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Simulate notification workflows
      const workflows = [
        {
          name: 'D-1 Pre-notification',
          description: 'Sent daily at 7:00 PM for next day delivery windows',
          status: 'simulated',
          details: {
            recipients: 3,
            timeWindow: '10:00-14:00',
            deliveryDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
            channels: ['WhatsApp', 'SMS'],
            message: 'Your delivery is scheduled for tomorrow between 10:00-14:00'
          }
        },
        {
          name: 'On-the-way Notification',
          description: 'Sent when driver starts the journey',
          status: 'simulated',
          details: {
            recipients: 3,
            driver: 'Driver Zhang',
            message: 'Driver Zhang is on the way, expected arrival in 30 minutes',
            channels: ['WhatsApp', 'SMS']
          }
        },
        {
          name: 'Next Trip Notification',
          description: 'Sent when trip is completed to notify next batch of customers',
          status: 'simulated',
          details: {
            recipients: 2,
            message: 'Good news! Your delivery will start soon, please be ready to receive',
            channels: ['WhatsApp', 'SMS']
          }
        }
      ]

      setDemoResults({
        type: 'notifications',
        title: 'Notification Workflows Demo',
        workflows
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Notifications demo failed')
    } finally {
      setIsLoading(false)
    }
  }

  // Demo 5: Time Slot Suggestion Demo
  const demoSlotSuggestion = async () => {
    setIsLoading(true)
    setError(null)
    setDemoResults(null)

    try {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 1000))

      // Generate mock slot data for 7 days
      const slots = []
      for (let i = 0; i < 7; i++) {
        const date = new Date()
        date.setDate(date.getDate() + i)
        const dateStr = date.toISOString().split('T')[0]

        const morningTime = Math.floor(Math.random() * 420) // 0-7h in minutes
        const afternoonTime = Math.floor(Math.random() * 420)

        slots.push({
          date: dateStr,
          morning: {
            slot: '10:00-14:00',
            drivingTime: morningTime,
            destinations: Math.floor(Math.random() * 15),
            status: morningTime < 180 ? 'green' : morningTime <= 360 ? 'yellow' : 'red'
          },
          afternoon: {
            slot: '14:00-18:00',
            drivingTime: afternoonTime,
            destinations: Math.floor(Math.random() * 15),
            status: afternoonTime < 180 ? 'green' : afternoonTime <= 360 ? 'yellow' : 'red'
          }
        })
      }

      // Find best slot
      let bestSlot = null
      for (const day of slots) {
        if (day.morning.status === 'green') {
          bestSlot = { date: day.date, slot: day.morning.slot, reason: 'Optimal available slot' }
          break
        }
        if (day.afternoon.status === 'green') {
          bestSlot = { date: day.date, slot: day.afternoon.slot, reason: 'Optimal available slot' }
          break
        }
      }
      if (!bestSlot) {
        bestSlot = { date: slots[0].date, slot: slots[0].morning.slot, reason: 'No green slots, selecting earliest available' }
      }

      setDemoResults({
        type: 'slots',
        title: 'Time Slot Suggestion Demo',
        slots,
        suggestion: bestSlot
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Time slot demo failed')
    } finally {
      setIsLoading(false)
    }
  }

  const formatTime = (minutes: number) => {
    const h = Math.floor(minutes / 60)
    const m = minutes % 60
    return `${h}h ${m}m`
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Feature Demo">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  🎯 Feature Demo Center
                </h1>
                <p className="text-gray-600">
                  Test and validate all newly implemented features
                </p>
              </div>
            </div>
          </div>

          {/* Demo Selection */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            <button
              onClick={() => setActiveDemo('eta')}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'eta'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">⏰</div>
              <div className="font-semibold text-gray-900">ETA Calculation</div>
              <div className="text-xs text-gray-600 mt-1">Auto calculate arrival times</div>
            </button>

            <button
              onClick={() => setActiveDemo('capacity')}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'capacity'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">⚖️</div>
              <div className="font-semibold text-gray-900">Capacity Validation</div>
              <div className="text-xs text-gray-600 mt-1">Check truck capacity</div>
            </button>

            <button
              onClick={() => setActiveDemo('delivery')}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'delivery'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">📥</div>
              <div className="font-semibold text-gray-900">Delivery Types</div>
              <div className="text-xs text-gray-600 mt-1">Delivery + pickup mixed</div>
            </button>

            <button
              onClick={() => setActiveDemo('notifications')}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'notifications'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">📱</div>
              <div className="font-semibold text-gray-900">Notifications</div>
              <div className="text-xs text-gray-600 mt-1">Three notification workflows</div>
            </button>

            <button
              onClick={() => setActiveDemo('slots')}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'slots'
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">📅</div>
              <div className="font-semibold text-gray-900">Time Slots</div>
              <div className="text-xs text-gray-600 mt-1">Color-coded system</div>
            </button>
          </div>

          {/* Run Button */}
          <div className="mb-6">
            <button
              onClick={() => {
                if (activeDemo === 'eta') demoETACalculation()
                else if (activeDemo === 'capacity') demoCapacityValidation()
                else if (activeDemo === 'delivery') demoDeliveryTypes()
                else if (activeDemo === 'notifications') demoNotifications()
                else if (activeDemo === 'slots') demoSlotSuggestion()
              }}
              disabled={isLoading}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-blue-300 font-semibold text-lg shadow-lg"
            >
              {isLoading ? '⏳ Running...' : '▶️ Run Demo'}
            </button>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-600">
              <strong>Error:</strong> {error}
            </div>
          )}

          {/* Results Display */}
          {demoResults && (
            <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {demoResults.title}
              </h2>

              {/* ETA Results */}
              {demoResults.type === 'eta' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Departure Time</div>
                      <div className="text-lg font-bold text-blue-600">
                        {new Date(demoResults.summary.departureTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Total Duration</div>
                      <div className="text-lg font-bold text-green-600">
                        {demoResults.summary.totalDuration}
                      </div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Trips</div>
                      <div className="text-lg font-bold text-purple-600">
                        {demoResults.summary.totalTrips}
                      </div>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Destinations</div>
                      <div className="text-lg font-bold text-orange-600">
                        {demoResults.summary.totalDestinations}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {demoResults.destinations.map((dest: {address: string, estimatedArrivalTime: string, cumulativeTravelTime: number, cumulativeServiceTime: number}, index: number) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded">
                        <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-900">
                            {dest.address}
                          </div>
                          <div className="text-sm text-blue-600">
                            ETA: {new Date(dest.estimatedArrivalTime).toLocaleTimeString('en-US')}
                          </div>
                          <div className="text-xs text-gray-600">
                            Travel: {formatTime(dest.cumulativeTravelTime)} | 
                            Service: {formatTime(dest.cumulativeServiceTime)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Capacity Results */}
              {demoResults.type === 'capacity' && (
                <div className="space-y-6">
                  <div className={`p-4 rounded-lg border-2 ${
                    demoResults.summary.isValid 
                      ? 'bg-green-50 border-green-300' 
                      : 'bg-red-50 border-red-300'
                  }`}>
                    <div className="text-2xl mb-2">
                      {demoResults.summary.isValid ? '✅' : '❌'}
                    </div>
                    <div className="font-bold text-lg">
                      {demoResults.summary.isValid ? 'Capacity Validation Passed' : 'Capacity Exceeded!'}
                    </div>
                    <div className="text-sm mt-1">
                      Truck Capacity: {demoResults.summary.truckCapacity} pallets
                    </div>
                    <div className="text-sm mt-1">
                      Utilization: {demoResults.summary.utilization}
                    </div>
                    {!demoResults.summary.isValid && (
                      <div className="mt-2 text-sm text-red-600">
                        Found {demoResults.summary.totalViolations} violations
                      </div>
                    )}
                  </div>

                  {demoResults.analysis.violations.length > 0 && (
                    <div className="border border-red-200 rounded-lg p-4">
                      <h3 className="font-semibold text-red-900 mb-3">Capacity Violations</h3>
                      {demoResults.analysis.violations.map((violation: {destination: string, load: number, capacity: number}, index: number) => (
                        <div key={index} className="bg-red-50 p-3 rounded mb-2">
                          <div className="font-medium text-red-800">{violation.destination}</div>
                          <div className="text-sm text-red-600">
                            Load: {violation.load} pallets (Capacity: {violation.capacity} pallets)
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Delivery Types Results */}
              {demoResults.type === 'delivery' && (
                <div className="space-y-4">
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <h3 className="font-semibold text-blue-900 mb-2">Legend</h3>
                    <p className="text-sm text-blue-700">
                      📦 Blue = Delivery (reduces load) | 📥 Orange = Pickup (increases load)
                    </p>
                  </div>

                  {demoResults.destinations.map((dest: {address: string, type: string, load: number, icon: string, color: string, description: string}, index: number) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border-2 ${
                        dest.color === 'blue'
                          ? 'bg-blue-50 border-blue-300'
                          : 'bg-orange-50 border-orange-300'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="text-3xl">{dest.icon}</div>
                        <div className="flex-1">
                          <div className="font-semibold text-gray-900">{dest.address}</div>
                          <div className="text-sm text-gray-600 mt-1">{dest.description}</div>
                          <div className={`text-xs mt-1 font-medium ${
                            dest.color === 'blue' ? 'text-blue-600' : 'text-orange-600'
                          }`}>
                            Type: {dest.type}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Notifications Results */}
              {demoResults.type === 'notifications' && (
                <div className="space-y-4">
                  {demoResults.workflows.map((workflow: {name: string, description: string, status: string, details: any}, index: number) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="flex-shrink-0 w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{workflow.name}</h3>
                          <p className="text-sm text-gray-600 mt-1">{workflow.description}</p>
                        </div>
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          {workflow.status}
                        </span>
                      </div>
                      <div className="bg-gray-50 p-3 rounded">
                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <span className="text-gray-600">Recipients:</span>
                            <span className="ml-2 font-semibold">{workflow.details.recipients}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">Channels:</span>
                            <span className="ml-2 font-semibold">{workflow.details.channels.join(', ')}</span>
                          </div>
                        </div>
                        <div className="mt-2 text-sm">
                          <span className="text-gray-600">Message:</span>
                          <div className="mt-1 p-2 bg-white rounded border border-gray-200">
                            {workflow.details.message}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Slots Results */}
              {demoResults.type === 'slots' && (
                <div className="space-y-6">
                  {/* Best Suggestion */}
                  <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">✨</span>
                      <h3 className="font-bold text-green-900">Recommended Slot</h3>
                    </div>
                    <div className="text-lg font-semibold text-green-700">
                      {demoResults.suggestion.date} {demoResults.suggestion.slot}
                    </div>
                    <div className="text-sm text-green-600 mt-1">
                      {demoResults.suggestion.reason}
                    </div>
                  </div>

                  {/* Legend */}
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-400 rounded"></div>
                      <span>🟢 Green: &lt; 3h</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-yellow-400 rounded"></div>
                      <span>🟡 Yellow: 3-6h</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-400 rounded"></div>
                      <span>🔴 Red: &gt; 6h</span>
                    </div>
                  </div>

                  {/* Slots Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {demoResults.slots.map((day: {date: string, morning: any, afternoon: any}, index: number) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <h4 className="font-semibold text-gray-900 mb-3">
                          {new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', weekday: 'short' })}
                        </h4>
                        
                        {/* Morning Slot */}
                        <div className={`p-3 rounded mb-2 ${
                          day.morning.status === 'green' ? 'bg-green-100 border border-green-300' :
                          day.morning.status === 'yellow' ? 'bg-yellow-100 border border-yellow-300' :
                          'bg-red-100 border border-red-300'
                        }`}>
                          <div className="font-semibold text-sm mb-1">{day.morning.slot}</div>
                          <div className="text-xs">⏱️ {formatTime(day.morning.drivingTime)}</div>
                          <div className="text-xs">📦 {day.morning.destinations} stops</div>
                        </div>

                        {/* Afternoon Slot */}
                        <div className={`p-3 rounded ${
                          day.afternoon.status === 'green' ? 'bg-green-100 border border-green-300' :
                          day.afternoon.status === 'yellow' ? 'bg-yellow-100 border border-yellow-300' :
                          'bg-red-100 border border-red-300'
                        }`}>
                          <div className="font-semibold text-sm mb-1">{day.afternoon.slot}</div>
                          <div className="text-xs">⏱️ {formatTime(day.afternoon.drivingTime)}</div>
                          <div className="text-xs">📦 {day.afternoon.destinations} stops</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quick Access Links */}
          <div className="mt-8 bg-gray-50 border border-gray-200 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Quick Access</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Link
                href="/journeys"
                className="p-3 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
              >
                <div className="text-2xl mb-1">🚛</div>
                <div className="text-sm font-medium text-gray-900">Journeys</div>
              </Link>
              <Link
                href="/live-tracking"
                className="p-3 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
              >
                <div className="text-2xl mb-1">🗺️</div>
                <div className="text-sm font-medium text-gray-900">Live Tracking</div>
              </Link>
              <Link
                href="/slot-planner"
                className="p-3 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
              >
                <div className="text-2xl mb-1">📅</div>
                <div className="text-sm font-medium text-gray-900">Slot Planner</div>
              </Link>
              <Link
                href="/routes"
                className="p-3 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow text-center"
              >
                <div className="text-2xl mb-1">📦</div>
                <div className="text-sm font-medium text-gray-900">Route Management</div>
              </Link>
            </div>
          </div>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}