'use client'

import { useState } from 'react'
import { createClient } from '@/lib/supabase'
import Papa from 'papaparse'

interface BatchOperationsDialogProps {
  isOpen: boolean
  onClose: () => void
  onSuccess?: () => void
  journeyId?: string
  userId: string
  mode: 'import' | 'edit' | 'delete'
  selectedDestinations?: string[] // destination IDs for edit/delete
}

interface CSVDestination {
  address: string
  postal_code?: string
  load_pallets?: number
  estimated_arrival_time?: string
  requires_tailgate?: boolean
  notes?: string
}

interface EditableFields {
  load_pallets?: number
  estimated_arrival_time?: string
  requires_tailgate?: boolean
  notes?: string
}

export default function BatchOperationsDialog({
  isOpen,
  onClose,
  onSuccess,
  journeyId,
  userId,
  mode,
  selectedDestinations = []
}: BatchOperationsDialogProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [parsedData, setParsedData] = useState<CSVDestination[]>([])
  const [editFields, setEditFields] = useState<EditableFields>({})

  if (!isOpen) return null

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setError(null)

    // Parse CSV
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data as CSVDestination[]
        setParsedData(data)
      },
      error: (error) => {
        setError(`CSV parsing error: ${error.message}`)
      }
    })
  }

  const handleImport = async () => {
    if (!journeyId || parsedData.length === 0) {
      setError('Please upload a valid CSV file with destinations')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Get current journey and max sequence
      const { error: journeyError } = await supabase
        .from('irp_journeys')
        .select('id, status')
        .eq('id', journeyId)
        .eq('user_id', userId)
        .single()

      if (journeyError) throw journeyError

      const { data: existingDests, error: destError } = await supabase
        .from('irp_destinations')
        .select('sequence_number')
        .eq('journey_id', journeyId)
        .order('sequence_number', { ascending: false })
        .limit(1)

      if (destError) throw destError

      const maxSequence = existingDests?.[0]?.sequence_number || 0

      // Prepare destinations for batch insert
      const destinations = parsedData.map((dest, index) => ({
        journey_id: journeyId,
        user_id: userId,
        address: dest.address,
        postal_code: dest.postal_code || '',
        load_pallets: dest.load_pallets || 0,
        estimated_arrival_time: dest.estimated_arrival_time || 'flexible',
        requires_tailgate: dest.requires_tailgate || false,
        notes: dest.notes || '',
        sequence_number: maxSequence + index + 1,
        status: 'pending'
      }))

      // Batch insert
      const { error: insertError } = await supabase
        .from('irp_destinations')
        .insert(destinations)

      if (insertError) throw insertError

      onSuccess?.()
      onClose()
    } catch (err) {
      console.error('Import error:', err)
      setError(err instanceof Error ? err.message : 'Failed to import destinations')
    } finally {
      setIsLoading(false)
    }
  }

  const handleBatchEdit = async () => {
    if (selectedDestinations.length === 0) {
      setError('No destinations selected')
      return
    }

    if (Object.keys(editFields).length === 0) {
      setError('Please specify at least one field to update')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Update all selected destinations
      const { error: updateError } = await supabase
        .from('irp_destinations')
        .update(editFields)
        .in('id', selectedDestinations)
        .eq('user_id', userId)

      if (updateError) throw updateError

      onSuccess?.()
      onClose()
    } catch (err) {
      console.error('Batch edit error:', err)
      setError(err instanceof Error ? err.message : 'Failed to update destinations')
    } finally {
      setIsLoading(false)
    }
  }

  const handleBatchDelete = async () => {
    if (selectedDestinations.length === 0) {
      setError('No destinations selected')
      return
    }

    if (!confirm(`Are you sure you want to delete ${selectedDestinations.length} destination(s)? This action cannot be undone.`)) {
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Delete all selected destinations
      const { error: deleteError } = await supabase
        .from('irp_destinations')
        .delete()
        .in('id', selectedDestinations)
        .eq('user_id', userId)

      if (deleteError) throw deleteError

      onSuccess?.()
      onClose()
    } catch (err) {
      console.error('Batch delete error:', err)
      setError(err instanceof Error ? err.message : 'Failed to delete destinations')
    } finally {
      setIsLoading(false)
    }
  }

  const renderImportMode = () => (
    <>
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Upload CSV File
        </label>
        <input
          type="file"
          accept=".csv"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none"
        />
        <p className="mt-2 text-xs text-gray-500">
          CSV format: address, postal_code, load_pallets, estimated_arrival_time, requires_tailgate, notes
        </p>
      </div>

      {parsedData.length > 0 && (
        <div className="mb-4">
          <p className="text-sm font-medium text-gray-700 mb-2">
            Preview ({parsedData.length} destinations)
          </p>
          <div className="max-h-48 overflow-y-auto border border-gray-200 rounded-lg">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Address</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Load</th>
                  <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Time</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {parsedData.slice(0, 5).map((dest, idx) => (
                  <tr key={idx}>
                    <td className="px-3 py-2 text-sm text-gray-900">{dest.address}</td>
                    <td className="px-3 py-2 text-sm text-gray-900">{dest.load_pallets || 0}</td>
                    <td className="px-3 py-2 text-sm text-gray-900">{dest.estimated_arrival_time || 'Flexible'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {parsedData.length > 5 && (
              <p className="text-xs text-gray-500 p-2 bg-gray-50">
                ... and {parsedData.length - 5} more
              </p>
            )}
          </div>
        </div>
      )}
    </>
  )

  const renderEditMode = () => (
    <div className="space-y-4">
      <p className="text-sm text-gray-600 mb-4">
        Updating {selectedDestinations.length} destination(s)
      </p>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Load (Pallets)
        </label>
        <input
          type="number"
          step="0.1"
          min="0"
          placeholder="Leave empty to keep current values"
          value={editFields.load_pallets || ''}
          onChange={(e) => setEditFields({ ...editFields, load_pallets: parseFloat(e.target.value) || undefined })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Delivery Time
        </label>
        <input
          type="text"
          placeholder="e.g., 09:00-12:00 or Leave empty"
          value={editFields.estimated_arrival_time || ''}
          onChange={(e) => setEditFields({ ...editFields, estimated_arrival_time: e.target.value || undefined })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={editFields.requires_tailgate || false}
            onChange={(e) => setEditFields({ ...editFields, requires_tailgate: e.target.checked })}
            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          />
          <span className="text-sm text-gray-700">Requires Tailgate</span>
        </label>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Notes
        </label>
        <textarea
          placeholder="Leave empty to keep current values"
          value={editFields.notes || ''}
          onChange={(e) => setEditFields({ ...editFields, notes: e.target.value || undefined })}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>
    </div>
  )

  const renderDeleteMode = () => (
    <div className="space-y-4">
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <svg className="w-5 h-5 text-red-600 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <div>
            <h3 className="text-sm font-medium text-red-800">Confirm Deletion</h3>
            <p className="text-sm text-red-700 mt-1">
              You are about to permanently delete {selectedDestinations.length} destination(s). This action cannot be undone.
            </p>
          </div>
        </div>
      </div>

      <p className="text-sm text-gray-600">
        Click &quot;Delete&quot; to confirm, or &quot;Cancel&quot; to go back.
      </p>
    </div>
  )

  const handleSubmit = () => {
    if (mode === 'import') handleImport()
    else if (mode === 'edit') handleBatchEdit()
    else if (mode === 'delete') handleBatchDelete()
  }

  const getTitle = () => {
    if (mode === 'import') return 'Import Destinations from CSV'
    if (mode === 'edit') return 'Batch Edit Destinations'
    return 'Batch Delete Destinations'
  }

  const getSubmitLabel = () => {
    if (mode === 'import') return 'Import'
    if (mode === 'edit') return 'Update'
    return 'Delete'
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">{getTitle()}</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
              <svg className="w-5 h-5 text-red-600 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {mode === 'import' && renderImportMode()}
          {mode === 'edit' && renderEditMode()}
          {mode === 'delete' && renderDeleteMode()}

          <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-200">
            <button
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={isLoading || (mode === 'import' && parsedData.length === 0)}
              className={`px-4 py-2 text-sm font-medium text-white rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 ${
                mode === 'delete'
                  ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500'
                  : 'bg-blue-600 hover:bg-blue-700 focus:ring-blue-500'
              }`}
            >
              {isLoading ? 'Processing...' : getSubmitLabel()}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
