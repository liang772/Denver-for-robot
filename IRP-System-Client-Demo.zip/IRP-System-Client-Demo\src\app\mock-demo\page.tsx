﻿'use client'

/**
 * 完全模拟的功能演示页面 - 不需要数据库
 * 使用假数据展示所有新功能
 */

import { useState } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'

export default function MockDemoPage() {
  const [activeDemo, setActiveDemo] = useState<string>('eta')
  const [showResults, setShowResults] = useState(false)

  const demoETA = () => {
    setShowResults(true)
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Mock Demo">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              🎯 Feature Demo Center (Mock Data)
            </h1>
            <p className="text-gray-600">
              Showcase all new features with mock data - No database required
            </p>
          </div>

          {/* Demo Selection */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
            <button
              onClick={() => { setActiveDemo('eta'); setShowResults(false); }}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'eta' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">⏰</div>
              <div className="font-semibold text-gray-900">ETA Calculation</div>
              <div className="text-xs text-gray-600 mt-1">Auto calculate arrival times</div>
            </button>

            <button
              onClick={() => { setActiveDemo('capacity'); setShowResults(false); }}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'capacity' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">⚖️</div>
              <div className="font-semibold text-gray-900">Capacity Validation</div>
              <div className="text-xs text-gray-600 mt-1">Check truck capacity</div>
            </button>

            <button
              onClick={() => { setActiveDemo('refund'); setShowResults(false); }}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'refund' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">📥</div>
              <div className="font-semibold text-gray-900">Refund Support</div>
              <div className="text-xs text-gray-600 mt-1">Delivery + Refund mix</div>
            </button>

            <button
              onClick={() => { setActiveDemo('notifications'); setShowResults(false); }}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'notifications' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">📱</div>
              <div className="font-semibold text-gray-900">Notification System</div>
              <div className="text-xs text-gray-600 mt-1">Three notification workflows</div>
            </button>

            <button
              onClick={() => { setActiveDemo('slots'); setShowResults(false); }}
              className={`p-4 rounded-lg border-2 text-left transition-all ${
                activeDemo === 'slots' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">📅</div>
              <div className="font-semibold text-gray-900">Slot Suggestion</div>
              <div className="text-xs text-gray-600 mt-1">Color-coded system</div>
            </button>
          </div>

          {/* Run Button */}
          <div className="mb-6">
            <button
              onClick={() => setShowResults(true)}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold text-lg shadow-lg"
            >
              ▶️ View Demo
            </button>
          </div>

          {/* Results Display */}
          {showResults && (
            <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-6">
              {/* ETA Demo */}
              {activeDemo === 'eta' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">⏰ ETA Calculation Demo</h2>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Departure Time</div>
                      <div className="text-lg font-bold text-blue-600">08:00</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Total Duration</div>
                      <div className="text-lg font-bold text-green-600">4h 25m</div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Trips</div>
                      <div className="text-lg font-bold text-purple-600">2</div>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-600 mb-1">Destinations</div>
                      <div className="text-lg font-bold text-orange-600">7</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900 mb-3">Trip 1 - 2h 15m</h3>
                      <div className="space-y-2">
                        {[
                          { seq: 1, eta: '08:45', location: '国贸商城', travel: '25min', service: '20min' },
                          { seq: 2, eta: '09:30', location: '中关村广场', travel: '30min', service: '15min' },
                          { seq: 3, eta: '10:05', location: '王府井百货', travel: '20min', service: '15min' },
                        ].map((dest) => (
                          <div key={dest.seq} className="flex items-center gap-3 p-3 bg-gray-50 rounded">
                            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                              {dest.seq}
                            </div>
                            <div className="flex-1">
                              <div className="text-sm font-medium text-gray-900">
                                ETA: {dest.eta} - {dest.location}
                              </div>
                              <div className="text-xs text-gray-600">
                                Travel: {dest.travel} | Service: {dest.service}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900 mb-3">Trip 2 - 2h 10m</h3>
                      <div className="space-y-2">
                        {[
                          { seq: 1, eta: '10:50', location: '丰台万达', travel: '35min', service: '25min' },
                          { seq: 2, eta: '11:40', location: '石景山万达', travel: '25min', service: '18min' },
                          { seq: 3, eta: '12:13', location: '五棵松', travel: '15min', service: '15min' },
                        ].map((dest) => (
                          <div key={dest.seq} className="flex items-center gap-3 p-3 bg-gray-50 rounded">
                            <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                              {dest.seq}
                            </div>
                            <div className="flex-1">
                              <div className="text-sm font-medium text-gray-900">
                                ETA: {dest.eta} - {dest.location}
                              </div>
                              <div className="text-xs text-gray-600">
                                Travel: {dest.travel} | Service: {dest.service}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Capacity Demo */}
              {activeDemo === 'capacity' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">⚖️ Capacity Validation Demo</h2>
                  
                  <div className="p-4 rounded-lg border-2 bg-green-50 border-green-300 mb-6">
                    <div className="text-2xl mb-2">✅</div>
                    <div className="font-bold text-lg">Capacity Validation Passed</div>
                    <div className="text-sm mt-1">Truck Capacity: 30 pallets</div>
                  </div>

                  <div className="space-y-4">
                    {[
                      { trip: 1, initial: 19, final: 0, max: 19, util: '63.3%', status: '✅ Valid' },
                      { trip: 2, initial: 22, final: 0, max: 22, util: '73.3%', status: '✅ Valid' },
                    ].map((trip, idx) => (
                      <div key={idx} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-gray-900">Trip {trip.trip}</h3>
                          <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-700">
                            {trip.status}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          <div>
                            <div className="text-xs text-gray-600">Initial Load</div>
                            <div className="text-sm font-semibold">{trip.initial} pallets</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-600">Final Load</div>
                            <div className="text-sm font-semibold">{trip.final} pallets</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-600">Peak Load</div>
                            <div className="text-sm font-semibold">{trip.max} pallets</div>
                          </div>
                          <div>
                            <div className="text-xs text-gray-600">Utilization</div>
                            <div className="text-sm font-semibold">{trip.util}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Refund Demo */}
              {activeDemo === 'refund' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">📥 Refund Support Demo</h2>
                  
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <h3 className="font-semibold text-blue-900 mb-2">Description</h3>
                    <p className="text-sm text-blue-700">
                      📦 蓝色 = Delivery (reduces load) | 📥 橙色 = Refund (increases load)
                    </p>
                  </div>

                  <div className="space-y-4">
                    {[
                      { type: 'delivery', icon: '📦', color: 'blue', addr: '国贸商城', load: 8, desc: 'Delivery 8 pallets (reduces load)' },
                      { type: 'delivery', icon: '📦', color: 'blue', addr: '中关村广场', load: 6, desc: 'Delivery 6 pallets (reduces load)' },
                      { type: 'refund', icon: '📥', color: 'orange', addr: '王府井百货', load: -3, desc: 'Refund 3 pallets (increases load)' },
                      { type: 'delivery', icon: '📦', color: 'blue', addr: '金融街', load: 5, desc: 'Delivery 5 pallets (reduces load)' },
                    ].map((dest, idx) => (
                      <div
                        key={idx}
                        className={`p-4 rounded-lg border-2 ${
                          dest.color === 'blue' ? 'bg-blue-50 border-blue-300' : 'bg-orange-50 border-orange-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-3xl">{dest.icon}</div>
                          <div className="flex-1">
                            <div className="font-semibold text-gray-900">{dest.addr}</div>
                            <div className="text-sm text-gray-600 mt-1">{dest.desc}</div>
                            <div className={`text-xs mt-1 font-medium ${
                              dest.color === 'blue' ? 'text-blue-600' : 'text-orange-600'
                            }`}>
                              Type: {dest.type}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Notifications Demo */}
              {activeDemo === 'notifications' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">📱 Notification System Demo</h2>
                  
                  <div className="space-y-4">
                    {[
                      {
                        name: 'D-1 预通知',
                        desc: '每晚19:00发送次日Delivery时间窗口',
                        recipients: 3,
                        channels: ['WhatsApp', 'SMS'],
                        message: '您的Delivery已安排在明天 10:00-14:00 之间'
                      },
                      {
                        name: '在途中通知',
                        desc: 'Send when driver starts journey',
                        recipients: 3,
                        channels: ['WhatsApp', 'SMS'],
                        message: '司机张师傅正在前往，预计30分钟内到达'
                      },
                      {
                        name: '下一Trip通知',
                        desc: 'Notify next batch of customers when trip completes',
                        recipients: 2,
                        channels: ['WhatsApp', 'SMS'],
                        message: '好消息！您的Delivery即将开始，请准备接收'
                      }
                    ].map((workflow, idx) => (
                      <div key={idx} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start gap-3 mb-3">
                          <div className="flex-shrink-0 w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                            {idx + 1}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900">{workflow.name}</h3>
                            <p className="text-sm text-gray-600 mt-1">{workflow.desc}</p>
                          </div>
                          <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                            simulated
                          </span>
                        </div>
                        <div className="bg-gray-50 p-3 rounded">
                          <div className="grid grid-cols-2 gap-3 text-sm mb-2">
                            <div>
                              <span className="text-gray-600">Recipients:</span>
                              <span className="ml-2 font-semibold">{workflow.recipients}</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Channels:</span>
                              <span className="ml-2 font-semibold">{workflow.channels.join(', ')}</span>
                            </div>
                          </div>
                          <div className="text-sm">
                            <span className="text-gray-600">Message:</span>
                            <div className="mt-1 p-2 bg-white rounded border border-gray-200">
                              {workflow.message}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Slots Demo */}
              {activeDemo === 'slots' && (
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">📅 Slot Suggestion Demo</h2>
                  
                  <div className="bg-green-50 border-2 border-green-300 rounded-lg p-4 mb-6">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">✨</span>
                      <h3 className="font-bold text-green-900">Recommended Slot</h3>
                    </div>
                    <div className="text-lg font-semibold text-green-700">
                      2025/12/11 10:00-14:00
                    </div>
                    <div className="text-sm text-green-600 mt-1">Best available slot</div>
                  </div>

                  <div className="flex items-center gap-6 text-sm mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-400 rounded"></div>
                      <span>🟢 Green: &lt; 3h</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-yellow-400 rounded"></div>
                      <span>🟡 Yellow: 3-6h</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-400 rounded"></div>
                      <span>🔴 Red: &gt; 6h</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[
                      { date: '12/10 周二', morning: { time: '2h 45m', stops: 5, color: 'green' }, afternoon: { time: '4h 20m', stops: 8, color: 'yellow' } },
                      { date: '12/11 周三', morning: { time: '1h 30m', stops: 3, color: 'green' }, afternoon: { time: '2h 15m', stops: 4, color: 'green' } },
                      { date: '12/12 周四', morning: { time: '6h 45m', stops: 12, color: 'red' }, afternoon: { time: '5h 30m', stops: 10, color: 'yellow' } },
                    ].map((day, idx) => (
                      <div key={idx} className="border border-gray-200 rounded-lg p-4">
                        <h4 className="font-semibold text-gray-900 mb-3">{day.date}</h4>
                        
                        <div className={`p-3 rounded mb-2 ${
                          day.morning.color === 'green' ? 'bg-green-100 border border-green-300' :
                          day.morning.color === 'yellow' ? 'bg-yellow-100 border border-yellow-300' :
                          'bg-red-100 border border-red-300'
                        }`}>
                          <div className="font-semibold text-sm mb-1">10:00-14:00</div>
                          <div className="text-xs">⏱️ {day.morning.time}</div>
                          <div className="text-xs">📦 {day.morning.stops} stops</div>
                        </div>

                        <div className={`p-3 rounded ${
                          day.afternoon.color === 'green' ? 'bg-green-100 border border-green-300' :
                          day.afternoon.color === 'yellow' ? 'bg-yellow-100 border border-yellow-300' :
                          'bg-red-100 border border-red-300'
                        }`}>
                          <div className="font-semibold text-sm mb-1">14:00-18:00</div>
                          <div className="text-xs">⏱️ {day.afternoon.time}</div>
                          <div className="text-xs">📦 {day.afternoon.stops} stops</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Info Box */}
          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-semibold text-blue-900 mb-2">📌 About This Demo</h3>
            <p className="text-sm text-blue-700 mb-3">
              This is a<strong>completely mock demo page</strong>，using fake data to showcase all new features。
            </p>
            <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
              <li>No database connection required</li>
              <li>No real customer data involved</li>
              <li>Visually see all feature UIs and interactions</li>
              <li>Suitable for demos and prototyping</li>
            </ul>
          </div>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
