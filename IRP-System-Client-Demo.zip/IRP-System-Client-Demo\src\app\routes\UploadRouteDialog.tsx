'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { useDropzone } from 'react-dropzone'
import { useAuth } from '@/contexts/AuthContext'

interface UploadRouteDialogProps {
  isOpen: boolean
  onClose: () => void
}



// API configuration
const API_CONFIG = {
  UPLOAD_ENDPOINT: process.env.NEXT_PUBLIC_UPLOAD_API_ENDPOINT || 'https://workflow.solve-x.ai/webhook/create-route',
  API_KEY: process.env.NEXT_PUBLIC_UPLOAD_API_KEY || 'L-m5cJZ~v#NR(pT'
}

// Upload file to external API with extended timeout for long-running operations
const uploadFileToAPI = async (file: File, userId: string, date: string): Promise<{ route_id: string }> => {
  const formData = new FormData()
  formData.append('data', file)
  formData.append('user_id', userId)
  formData.append('date', date)
  
  // Extended timeout for long-running API operations (5 minutes)
  const TIMEOUT_MS = 300000 // 5 minutes
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS)
  
  try {
    console.log('Starting file upload to API...')
    const response = await fetch(API_CONFIG.UPLOAD_ENDPOINT, {
      method: 'POST',
      headers: {
        'api-key': API_CONFIG.API_KEY
      },
      body: formData,
      signal: controller.signal
    })
    
    clearTimeout(timeoutId)
    console.log('API response received:', response.status)
    
    if (!response.ok) {
      throw new Error(`Upload failed: ${response.status} ${response.statusText}`)
    }
    
    const result = await response.json()
    console.log('API response data:', result)
    
    // Validate the response contains route_id
    if (!result.route_id) {
      throw new Error('Invalid response: missing route_id')
    }
    
    return result
  } catch (error) {
    clearTimeout(timeoutId)
    console.error('Upload error:', error)
    
    if (error instanceof Error && error.name === 'AbortError') {
      throw new Error(`Upload timed out after ${TIMEOUT_MS / 1000 / 60} minutes. Please try again.`)
    }
    throw error
  }
}

export default function UploadRouteDialog({ isOpen, onClose }: UploadRouteDialogProps) {
  const router = useRouter()
  const { user } = useAuth()
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [selectedDate, setSelectedDate] = useState<string>('')
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [uploadStartTime, setUploadStartTime] = useState<Date | null>(null)
  const [uploadSuccess, setUploadSuccess] = useState(false)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setUploadedFile(acceptedFiles[0])
      setUploadError(null) // Clear any previous errors
    }
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
      'text/csv': ['.csv']
    },
    multiple: false,
    disabled: isUploading
  })

    const handleUpload = async () => {
    if (!uploadedFile || !user || !selectedDate) return

    setIsUploading(true)
    setUploadProgress(0)
    setUploadError(null)
    setUploadStartTime(new Date())

    // Start progress animation that expects completion within approximately 3 seconds
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 85) return prev // Cap at 85% until API responds
        // Progress animation: reaches ~85% in ~3 seconds, then waits for API response
        return prev + (85 - prev) * 0.08
      })
    }, 300) // Update every 300ms for smoother experience

    try {
      // Wait for API response with route_id
      const result = await uploadFileToAPI(uploadedFile, user.id, selectedDate)
      
      // API responded successfully with route_id
      setUploadProgress(100)
      setUploadSuccess(true)
      
      console.log('Upload successful, route_id:', result.route_id)
      
      // Clear progress interval
      clearInterval(progressInterval)
      
      // Wait a moment to show success message, then redirect
      setTimeout(() => {
        // Close modal
        onClose()
        
        // Reset upload state
        setIsUploading(false)
        setUploadProgress(0)
        setUploadedFile(null)
        setSelectedDate('')
        setUploadStartTime(null)
        setUploadSuccess(false)
        
        // Redirect directly to route details page
        router.push(`/routes/${result.route_id}`)
      }, 1500) // Show success for 1.5 seconds

    } catch (error) {
      console.error('Upload failed:', error)
      clearInterval(progressInterval) // Clear progress interval on error
      setUploadError(error instanceof Error ? error.message : 'Failed to process file')
      setIsUploading(false)
      setUploadProgress(0)
      setUploadStartTime(null)
    }
  }

  const handleClose = () => {
    if (!isUploading) {
      setUploadedFile(null)
      setSelectedDate('')
      onClose()
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-xl font-semibold text-gray-900">Upload Route</h2>
          <button
            onClick={handleClose}
            disabled={isUploading}
            className="text-gray-400 hover:text-gray-600 transition-colors disabled:opacity-50"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* File Drop Area */}
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isUploading 
                ? 'border-gray-300 bg-gray-50 cursor-not-allowed'
                : isDragActive
                ? 'border-blue-500 bg-blue-50 cursor-pointer'
                : uploadedFile
                ? 'border-green-500 bg-green-50 cursor-pointer'
                : 'border-gray-300 hover:border-gray-400 cursor-pointer'
            }`}
          >
            <input {...getInputProps()} />
            
            {uploadedFile ? (
              <div className="space-y-3">
                <svg className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                  <p className="text-sm font-medium text-green-800">{uploadedFile.name}</p>
                  <p className="text-xs text-green-600">
                    {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    setUploadedFile(null)
                  }}
                  className="text-sm text-green-600 hover:text-green-800 underline"
                >
                  Remove file
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {isDragActive ? 'Drop the file here' : 'Drag & drop a file here'}
                  </p>
                  <p className="text-xs text-gray-500">or click to browse</p>
                </div>
                <p className="text-xs text-gray-400">
                  Supports Excel (.xlsx, .xls) and CSV files
                </p>
              </div>
            )}
          </div>

          {/* Date Selection */}
          <div className="mt-6">
            <label htmlFor="route-date" className="block text-sm font-medium text-gray-700 mb-2">
              Route Date *
            </label>
            <input
              type="date"
              id="route-date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              disabled={isUploading}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-black placeholder-black"
              required
            />
            {!selectedDate && (
              <p className="mt-1 text-sm text-red-600">Please select a date for this route</p>
            )}
          </div>

          {/* Upload Progress */}
          {isUploading && (
            <div className="mt-6">
              <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                <span>
                  {uploadProgress < 20 ? 'Uploading file...' :
                   uploadProgress < 85 ? 'Processing file (this may take a few seconds)...' :
                   uploadProgress < 100 ? 'Finalizing route...' :
                   'Upload successful! Redirecting to route details...'}
                </span>
                <div className="flex items-center gap-3">
                  <span>{uploadProgress.toFixed(2)}%</span>
                  {uploadStartTime && (
                    <span className="text-xs text-gray-500">
                      Elapsed: {Math.floor((Date.now() - uploadStartTime.getTime()) / 1000)}s
                    </span>
                  )}
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Success Display */}
          {uploadSuccess && (
            <div className="mt-6 bg-green-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-sm text-green-800">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="font-medium">Success!</span> File uploaded successfully. Redirecting to routes list...
              </div>
            </div>
          )}

          {/* Error Display */}
          {uploadError && (
            <div className="mt-6 bg-red-50 rounded-lg p-4">
              <div className="flex items-center gap-2 text-sm text-red-800">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                </svg>
                <span className="font-medium">Error:</span> {uploadError}
              </div>
            </div>
          )}

          {/* Supporting Information */}
          <div className="mt-6 bg-blue-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-blue-900 mb-2">
              How route processing works:
            </h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Upload your Excel/CSV file with location data points</li>
              <li>• File is sent to our processing service for intelligent analysis</li>
              <li>• Processing service creates the route and all destinations automatically</li>
              <li>• Processing typically takes a few seconds for most routes</li>
              <li>• You&apos;ll be redirected directly to the route details page once complete</li>
              <li>• The route will be fully accessible with all destinations and trip information</li>
            </ul>
          </div>

          {/* File Format Requirements */}
          <div className="mt-4 bg-gray-50 rounded-lg p-4">
            <h3 className="text-sm font-medium text-gray-900 mb-2">
              File format requirements:
            </h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• <strong>Supported formats:</strong> Excel (.xlsx, .xls) and CSV files</li>
              <li>• <strong>Required data:</strong> Address/location information</li>
              <li>• <strong>Optional data:</strong> Load quantities, delivery requirements, time windows</li>
              <li>• <strong>Processing:</strong> Our AI service will intelligently extract and structure your data</li>
              <li>• <strong>Maximum file size:</strong> 10 MB</li>
              <li>• <strong>Processing timeout:</strong> 5 minutes maximum (typically completes in a few seconds)</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-6 border-t bg-gray-50">
          <button
            onClick={handleClose}
            disabled={isUploading}
            className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={handleUpload}
            disabled={!uploadedFile || !selectedDate || isUploading}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {isUploading ? (
              <>
                <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Uploading...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                Upload & Process
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
