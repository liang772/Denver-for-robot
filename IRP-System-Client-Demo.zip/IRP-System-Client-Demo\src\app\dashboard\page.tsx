'use client'

import { useState, useEffect } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import Image from 'next/image'
import { useAuth } from '@/contexts/AuthContext'
import { mockTrucks, mockJourneys, mockTrips, mockDestinations } from '@/lib/mock-data'
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from 'recharts'

interface UserProfile {
  id: string
  email: string
  full_name: string | null
  phone_number: string | null
  whatsapp: string | null
  is_enabled: boolean
  avatar_url: string | null
  bio: string | null
  user_created_at: string
}

// Dashboard stats type (used by dashboardStats constant)
type DashboardStats = {
  totalRoutes: number
  activeRoutes: number
  completedRoutes: number
  totalDeliveries: number
  totalLoadDelivered: number
  totalTrucks: number
  activeTrucks: number
  fleetUtilization: number
  averageDeliveryTime: number
  onTimeDeliveryRate: number
}

// Generate statistics directly from mock data
const dashboardStats: DashboardStats = {
  totalRoutes: mockJourneys.length,
  activeRoutes: mockJourneys.filter(j => j.status === 'active' || j.status === 'in_progress').length,
  completedRoutes: mockJourneys.filter(j => j.status === 'completed').length,
  totalDeliveries: mockDestinations.length,
  totalLoadDelivered: mockDestinations.reduce((sum, d) => sum + (d.load_pallets > 0 ? d.load_pallets : 0), 0),
  totalTrucks: mockTrucks.length,
  activeTrucks: mockTrucks.filter(t => t.is_active).length,
  fleetUtilization: Math.round((mockTrucks.filter(t => t.is_active).length / mockTrucks.length) * 100),
  averageDeliveryTime: 45,
  onTimeDeliveryRate: 98
}

interface MonthlyData {
  month: string
  deliveries: number
  load: number
  routes: number
}

interface RoutePerformanceData {
  routeId: string
  routeName: string
  efficiency: number
  deliveryTime: number
  loadUtilization: number
  onTimeRate: number
}

interface TruckUtilizationData {
  truckId: string
  truckName: string
  utilization: number
  tripsCompleted: number
  totalDistance: number
  avgDeliveryTime: number
}

interface DeliveryTrendsData {
  date: string
  deliveries: number
  load: number
  efficiency: number
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  
  // 使用 mock 数据生成图表数据
  const monthlyData: MonthlyData[] = [
    { month: 'Oct 2024', deliveries: 45, load: 120, routes: 8 },
    { month: 'Nov 2024', deliveries: 52, load: 135, routes: 9 },
    { month: 'Dec 2024', deliveries: 38, load: 98, routes: 7 }
  ]

  const recentActivity = mockJourneys.slice(0, 5).map(journey => ({
    id: journey.id,
    name: journey.name,
    date: journey.date,
    status: journey.status,
    total_destinations: mockTrips.filter(t => t.journey_id === journey.id)
      .reduce((sum, trip) => sum + mockDestinations.filter(d => d.trip_id === trip.id).length, 0),
    total_load: mockDestinations.reduce((sum, d) => sum + (d.load_pallets > 0 ? d.load_pallets : 0), 0)
  }))

  const fleetData = mockTrucks.map(truck => ({
    id: truck.id,
    display_name: truck.display_name,
    capacity_pallets: truck.capacity_pallets,
    available_count: truck.is_active ? 1 : 0,
    vehicle_type: truck.vehicle_type,
    is_internal: truck.is_internal
  }))

  const routePerformance: RoutePerformanceData[] = mockJourneys.slice(0, 5).map((journey) => ({
    routeId: journey.id,
    routeName: journey.name,
    efficiency: 85 + Math.random() * 15,
    deliveryTime: 30 + Math.random() * 30,
    loadUtilization: 70 + Math.random() * 25,
    onTimeRate: 90 + Math.random() * 10
  }))

  const truckUtilization: TruckUtilizationData[] = mockTrucks.slice(0, 5).map((truck) => ({
    truckId: truck.id,
    truckName: truck.display_name,
    utilization: 60 + Math.random() * 35,
    tripsCompleted: Math.floor(Math.random() * 20) + 5,
    totalDistance: Math.floor(Math.random() * 1000) + 200,
    avgDeliveryTime: 25 + Math.random() * 20
  }))

  const deliveryTrends: DeliveryTrendsData[] = Array.from({ length: 7 }, (_, i) => {
    const date = new Date()
    date.setDate(date.getDate() - (6 - i))
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      deliveries: Math.floor(Math.random() * 15) + 5,
      load: Math.floor(Math.random() * 40) + 10,
      efficiency: 80 + Math.random() * 20
    }
  })

  const fleetEfficiency = [
    { name: 'High Efficiency', value: 65, color: '#10B981' },
    { name: 'Medium Efficiency', value: 25, color: '#F59E0B' },
    { name: 'Low Efficiency', value: 10, color: '#EF4444' }
  ]

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)
    
    return () => clearTimeout(timer)
  }, [])

  const profile: UserProfile = {
    id: user?.id || 'demo-user',
    email: user?.email || 'demo@example.com',
    full_name: 'Demo User',
    phone_number: null,
    whatsapp: null,
    is_enabled: true,
    avatar_url: null,
    bio: null,
    user_created_at: new Date().toISOString()
  }


  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    )
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Dashboard">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Logistics Dashboard</h1>
              <p className="text-gray-600">Welcome back, {profile?.full_name || 'User'}</p>
            </div>
            <div className="flex items-center space-x-3">
              {profile?.avatar_url ? (
                <Image 
                  src={profile.avatar_url} 
                  alt="Profile" 
                  width={40}
                  height={40}
                  className="w-10 h-10 rounded-full"
                />
              ) : (
                <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-indigo-600">
                    {profile?.full_name?.charAt(0) || profile?.email?.charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-blue-100 rounded-md flex items-center justify-center">
                    <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Total Routes</p>
                  <p className="text-2xl font-semibold text-gray-900">{dashboardStats.totalRoutes}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-green-100 rounded-md flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Total Deliveries</p>
                  <p className="text-2xl font-semibold text-gray-900">{dashboardStats.totalDeliveries}</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-purple-100 rounded-md flex items-center justify-center">
                    <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Load Delivered</p>
                  <p className="text-2xl font-semibold text-gray-900">{dashboardStats.totalLoadDelivered.toFixed(1)} pallets</p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-orange-100 rounded-md flex items-center justify-center">
                    <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">On-Time Rate</p>
                  <p className="text-2xl font-semibold text-gray-900">{dashboardStats.onTimeDeliveryRate.toFixed(1)}%</p>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Charts and Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Delivery Trends Chart */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Trends (Last 7 Days)</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={deliveryTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="deliveries" stackId="1" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.6} />
                    <Area type="monotone" dataKey="load" stackId="2" stroke="#10B981" fill="#10B981" fillOpacity={0.6} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Fleet Efficiency Pie Chart */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Fleet Efficiency Distribution</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={fleetEfficiency}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      // eslint-disable-next-line @typescript-eslint/no-explicit-any
                      label={(props: any) => `${props.name} ${(props.percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {fleetEfficiency.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Route Performance Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Route Performance Chart */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Route Performance</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={routePerformance.slice(0, 5)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="routeName" angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="efficiency" fill="#3B82F6" name="Efficiency %" />
                    <Bar dataKey="onTimeRate" fill="#10B981" name="On-Time Rate %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Truck Utilization Chart */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Truck Utilization</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={truckUtilization.slice(0, 5)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="truckName" angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="utilization" stroke="#F59E0B" strokeWidth={2} name="Utilization %" />
                    <Line type="monotone" dataKey="tripsCompleted" stroke="#EF4444" strokeWidth={2} name="Trips Completed" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Monthly Performance Overview */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Performance Overview</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="deliveries" stroke="#3B82F6" strokeWidth={2} name="Deliveries" />
                  <Line yAxisId="right" type="monotone" dataKey="load" stroke="#10B981" strokeWidth={2} name="Load (pallets)" />
                  <Line yAxisId="left" type="monotone" dataKey="routes" stroke="#F59E0B" strokeWidth={2} name="Routes" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Key Performance Indicators */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Performance Indicators</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{dashboardStats.fleetUtilization.toFixed(1)}%</div>
                <div className="text-sm text-gray-600">Fleet Utilization</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{dashboardStats.onTimeDeliveryRate.toFixed(1)}%</div>
                <div className="text-sm text-gray-600">On-Time Delivery</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">{Math.round(dashboardStats.averageDeliveryTime)} min</div>
                <div className="text-sm text-gray-600">Avg Delivery Time</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{dashboardStats.totalLoadDelivered.toFixed(1)}</div>
                <div className="text-sm text-gray-600">Total Load (pallets)</div>
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
            <div className="space-y-3">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-b-0">
                  <div className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${
                      activity.status === 'completed' ? 'bg-green-500' :
                      activity.status === 'active' ? 'bg-blue-500' :
                      'bg-gray-400'
                    }`}></div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{activity.name}</p>
                      <p className="text-xs text-gray-500">
                        {activity.total_destinations} deliveries • {activity.total_load} pallets
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">{new Date(activity.date).toLocaleDateString()}</p>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      activity.status === 'completed' ? 'bg-green-100 text-green-800' :
                      activity.status === 'active' ? 'bg-blue-100 text-blue-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {activity.status}
                    </span>
                  </div>
                </div>
              ))}
              {recentActivity.length === 0 && (
                <p className="text-gray-500 text-center py-8">No recent activity</p>
              )}
            </div>
          </div>

          {/* Fleet Breakdown */}
          {fleetData.length > 0 && (
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Fleet Breakdown</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {fleetData.map((truck) => (
                  <div key={truck.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-gray-900">{truck.display_name}</h4>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        truck.is_internal ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {truck.is_internal ? 'Company' : 'Contractor'}
                      </span>
                    </div>
                    <div className="space-y-1 text-xs text-gray-600">
                      <div className="flex justify-between">
                        <span>Capacity:</span>
                        <span>{truck.capacity_pallets} pallets</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Available:</span>
                        <span>{truck.available_count}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Type:</span>
                        <span className="capitalize">{truck.vehicle_type}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
