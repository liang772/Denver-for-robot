/**
 * Scheduler API Route
 * Manual trigger endpoint for scheduled tasks
 */

import { handleManualTrigger } from '@/lib/scheduler'

export async function POST(request: Request) {
  try {
    return await handleManualTrigger(request)
  } catch (error) {
    console.error('Error in scheduler API:', error)
    return Response.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

export async function GET() {
  return Response.json({
    message: 'Scheduler API',
    endpoints: {
      'POST /api/scheduler': 'Manually trigger scheduled tasks',
    },
    availableTasks: [
      {
        name: 'd1-notifications',
        description: 'Send D-1 pre-delivery notifications',
        example: {
          task: 'd1-notifications',
          date: '2025-12-11'
        }
      }
    ]
  })
}
