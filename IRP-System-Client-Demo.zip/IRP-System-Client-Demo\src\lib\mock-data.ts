/**
 * Mock Data - For demonstration purposes, no database involved
 */

export const mockTrucks = [
  {
    id: 'mock-truck-1',
    display_name: 'BJ-A12345 Dongfeng Truck',
    vehicle_type: 'standard',
    capacity_pallets: 30,
    is_internal: true,
    is_active: true,
    available_count: 1,
    created_at: new Date().toISOString()
  },
  {
    id: 'mock-truck-2',
    display_name: 'BJ-B67890 Jiefang J6',
    vehicle_type: 'tailgate',
    capacity_pallets: 25,
    is_internal: true,
    is_active: true,
    available_count: 1,
    created_at: new Date().toISOString()
  }
]

export const mockDrivers = [
  {
    id: 'mock-driver-1',
    name: 'Driver Zhang',
    phone: '13800138001',
    license_number: 'D1234567',
    status: 'available',
    created_at: new Date().toISOString()
  },
  {
    id: 'mock-driver-2',
    name: 'Driver Li',
    phone: '13900139002',
    license_number: 'D2345678',
    status: 'available',
    created_at: new Date().toISOString()
  }
]

const today = new Date().toISOString().split('T')[0]
const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0]

export const mockJourneys = [
  {
    id: 'mock-journey-1',
    name: `Daily Delivery Route - ${today}`,
    date: today,
    truck_id: 'mock-truck-1',
    driver_id: 'mock-driver-1',
    planned_departure_time: '08:00',
    status: 'active',
    created_at: new Date().toISOString(),
    // Related data
    truck: mockTrucks[0],
    driver: mockDrivers[0],
    total_trips: 2,
    completed_trips: 0,
    total_destinations: 5,
    completed_destinations: 0
  },
  {
    id: 'mock-journey-2',
    name: `Daily Delivery Route 2 - ${today}`,
    date: today,
    truck_id: 'mock-truck-2',
    driver_id: 'mock-driver-2',
    planned_departure_time: '09:00',
    status: 'in_progress',
    created_at: new Date().toISOString(),
    truck: mockTrucks[1],
    driver: mockDrivers[1],
    total_trips: 1,
    completed_trips: 0,
    total_destinations: 2,
    completed_destinations: 0
  },
  {
    id: 'mock-journey-3',
    name: `Tomorrow Delivery Route - ${tomorrow}`,
    date: tomorrow,
    truck_id: 'mock-truck-1',
    driver_id: null,
    planned_departure_time: '08:00',
    status: 'pending',
    created_at: new Date().toISOString(),
    truck: mockTrucks[0],
    driver: null,
    total_trips: 1,
    completed_trips: 0,
    total_destinations: 2,
    completed_destinations: 0
  }
]

export const mockTrips = [
  {
    id: 'mock-trip-1',
    journey_id: 'mock-journey-1',
    name: 'Morning Delivery',
    journey_sequence: 1,
    planned_start_time: '08:00',
    planned_end_time: '12:00',
    status: 'pending',
    created_at: new Date().toISOString()
  },
  {
    id: 'mock-trip-2',
    journey_id: 'mock-journey-1',
    name: 'Afternoon Delivery',
    journey_sequence: 2,
    planned_start_time: '14:00',
    planned_end_time: '18:00',
    status: 'pending',
    created_at: new Date().toISOString()
  },
  {
    id: 'mock-trip-3',
    journey_id: 'mock-journey-2',
    name: 'Full Day Delivery',
    journey_sequence: 1,
    planned_start_time: '09:00',
    planned_end_time: '17:00',
    status: 'pending',
    created_at: new Date().toISOString()
  },
  {
    id: 'mock-trip-4',
    journey_id: 'mock-journey-3',
    name: 'Tomorrow Delivery',
    journey_sequence: 1,
    planned_start_time: '08:00',
    planned_end_time: '16:00',
    status: 'pending',
    created_at: new Date().toISOString()
  }
]

export const mockDestinations = [
  // Trip 1 - Morning Delivery
  {
    id: 'mock-dest-1',
    trip_id: 'mock-trip-1',
    sequence: 0,
    address: 'Guomao Shopping Center, Chaoyang District, Beijing',
    latitude: 39.9087,
    longitude: 116.4585,
    load_pallets: 8,
    time_to_location: 25,
    offloading_time: 20,
    delivery_type: 'delivery',
    customer_name: 'Guomao Shopping Center Procurement',
    customer_phone: '010-65051234',
    status: 'pending'
  },
  {
    id: 'mock-dest-2',
    trip_id: 'mock-trip-1',
    sequence: 1,
    address: 'Zhongguancun Plaza, Haidian District, Beijing',
    latitude: 39.9806,
    longitude: 116.3142,
    load_pallets: 6,
    time_to_location: 30,
    offloading_time: 15,
    delivery_type: 'delivery',
    customer_name: 'Zhongguancun Technology',
    customer_phone: '010-82136789',
    status: 'pending'
  },
  {
    id: 'mock-dest-3',
    trip_id: 'mock-trip-1',
    sequence: 2,
    address: 'Wangfujing Department Store, Dongcheng District, Beijing',
    latitude: 39.9155,
    longitude: 116.4093,
    load_pallets: -3,
    time_to_location: 20,
    offloading_time: 15,
    delivery_type: 'refund_pickup',
    customer_name: 'Wangfujing Department Store Returns',
    customer_phone: '010-65281234',
    status: 'pending'
  },
  // Trip 2 - Afternoon Delivery
  {
    id: 'mock-dest-4',
    trip_id: 'mock-trip-2',
    sequence: 0,
    address: 'Financial Street Shopping Center, Xicheng District, Beijing',
    latitude: 39.9153,
    longitude: 116.3644,
    load_pallets: 5,
    time_to_location: 18,
    offloading_time: 12,
    delivery_type: 'delivery',
    customer_name: 'Financial Street Mall',
    customer_phone: '010-66210000',
    status: 'pending'
  },
  {
    id: 'mock-dest-5',
    trip_id: 'mock-trip-2',
    sequence: 1,
    address: 'Fengtai Wanda Plaza, Fengtai District, Beijing',
    latitude: 39.8547,
    longitude: 116.2869,
    load_pallets: 10,
    time_to_location: 35,
    offloading_time: 25,
    delivery_type: 'delivery',
    customer_name: 'Fengtai Wanda',
    customer_phone: '010-83739999',
    status: 'pending'
  },
  // Trip 3 - Full Day Delivery
  {
    id: 'mock-dest-6',
    trip_id: 'mock-trip-3',
    sequence: 0,
    address: 'Shijingshan Wanda Plaza, Shijingshan District, Beijing',
    latitude: 39.9067,
    longitude: 116.2223,
    load_pallets: -5,
    time_to_location: 25,
    offloading_time: 18,
    delivery_type: 'refund_pickup',
    customer_name: 'Shijingshan Wanda',
    customer_phone: '010-88706666',
    status: 'pending'
  },
  {
    id: 'mock-dest-7',
    trip_id: 'mock-trip-3',
    sequence: 1,
    address: 'Wukesong Shopping Center, Haidian District, Beijing',
    latitude: 39.9065,
    longitude: 116.2812,
    load_pallets: 7,
    time_to_location: 15,
    offloading_time: 15,
    delivery_type: 'delivery',
    customer_name: 'Wukesong Mall',
    customer_phone: '010-88726666',
    status: 'pending'
  },
  // Trip 4 - Tomorrow Delivery
  {
    id: 'mock-dest-8',
    trip_id: 'mock-trip-4',
    sequence: 0,
    address: 'SOHO Modern City, Dawanglu, Chaoyang District, Beijing',
    latitude: 39.9088,
    longitude: 116.4722,
    load_pallets: 12,
    time_to_location: 30,
    offloading_time: 20,
    delivery_type: 'delivery',
    customer_name: 'SOHO China',
    customer_phone: '010-85869999',
    status: 'pending'
  },
  {
    id: 'mock-dest-9',
    trip_id: 'mock-trip-4',
    sequence: 1,
    address: 'Sanlitun Taikoo Li, Chaoyang District, Beijing',
    latitude: 39.9349,
    longitude: 116.4553,
    load_pallets: 8,
    time_to_location: 20,
    offloading_time: 18,
    delivery_type: 'delivery',
    customer_name: 'Taikoo Li Mall',
    customer_phone: '010-64176688',
    status: 'pending'
  }
]

export const mockTruckLocations = [
  {
    id: 'mock-loc-1',
    truck_id: 'mock-truck-1',
    latitude: 39.9042,
    longitude: 116.4074,
    timestamp: new Date(Date.now() - 2 * 60000).toISOString(), // 2 minutes ago
    speed: 35.5,
    heading: 90
  },
  {
    id: 'mock-loc-2',
    truck_id: 'mock-truck-2',
    latitude: 39.9163,
    longitude: 116.3972,
    timestamp: new Date(Date.now() - 5 * 60000).toISOString(), // 5 minutes ago
    speed: 28.3,
    heading: 180
  }
]

export const mockDestinationTypes = [
  {
    id: 'mock-type-1',
    name: 'Large Shopping Mall',
    description: 'Requires freight elevator, longer unloading time',
    extra_offloading_time: 10,
    color_code: '#3B82F6',
    icon: '🏢',
    created_at: new Date().toISOString()
  },
  {
    id: 'mock-type-2',
    name: 'Convenience Store',
    description: 'Fast delivery, short unloading time',
    extra_offloading_time: 0,
    color_code: '#10B981',
    icon: '🏪',
    created_at: new Date().toISOString()
  }
]

export const mockRouteTemplates = [
  {
    id: 'mock-template-1',
    name: 'Beijing City Regular Delivery Route',
    description: 'Covers major business districts in Chaoyang, Haidian, Dongcheng, and Xicheng',
    is_active: true,
    created_at: new Date().toISOString(),
    stops: [
      {
        id: 'mock-stop-1',
        template_id: 'mock-template-1',
        sequence: 0,
        address: 'Guomao Shopping Center',
        latitude: 39.9087,
        longitude: 116.4585,
        estimated_duration: 20
      },
      {
        id: 'mock-stop-2',
        template_id: 'mock-template-1',
        sequence: 1,
        address: 'Zhongguancun Plaza',
        latitude: 39.9806,
        longitude: 116.3142,
        estimated_duration: 15
      },
      {
        id: 'mock-stop-3',
        template_id: 'mock-template-1',
        sequence: 2,
        address: 'Wangfujing Department Store',
        latitude: 39.9155,
        longitude: 116.4093,
        estimated_duration: 15
      }
    ]
  }
]

// Helper function: Get today's journeys
export function getTodayJourneys() {
  return mockJourneys.filter(j => j.date === today)
}

// Helper function: Get trips for a specific journey
export function getJourneyTrips(journeyId: string) {
  return mockTrips.filter(t => t.journey_id === journeyId)
}

// Helper function: Get destinations for a specific trip
export function getTripDestinations(tripId: string) {
  return mockDestinations.filter(d => d.trip_id === tripId)
}

// Helper function: Get current truck location
export function getTruckLocation(truckId: string) {
  return mockTruckLocations.find(l => l.truck_id === truckId)
}
