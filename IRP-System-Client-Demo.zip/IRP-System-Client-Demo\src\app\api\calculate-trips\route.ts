import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { EnhancedTruckData, CalculateTripsResponse } from '@/types/route'

// Type definitions for API request/response
interface TruckRequest {
  truck_id: string
  count: number
  capacity_pallets: number
  vehicle_type: 'standard' | 'tailgate' | 'refrigerated' | 'flatbed'
}

interface TruckDetails {
  id: string
  is_internal: boolean
  contractor_name?: string | null
  contractor_rate?: number | null
}

interface DestinationTypeMapping {
  truck_id: string
}

interface DestinationType {
  id: string
  name: string
  description?: string
  extra_offloading_time: number
  color_code: string
  icon: string
  irp_destination_type_trucks?: DestinationTypeMapping[]
}

interface SupabaseError {
  message: string
  details?: string
  hint?: string
  code?: string
}

// Initialize Supabase client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const routeId = searchParams.get('route_id')
    
    if (!routeId) {
      return NextResponse.json(
        { error: 'Route ID is required' },
        { status: 400 }
      )
    }
    
    // Parse truck data from request body
    const body = await request.json()
    const trucks: TruckRequest[] = body.trucks || []
    const truckerWorkingHours: number = body.trucker_working_hours || 12.0
    
    console.log('Received truck data:', trucks)
    console.log('Received trucker working hours:', truckerWorkingHours)
    
    // Validate truck data
    if (!trucks || trucks.length === 0) {
      return NextResponse.json(
        { error: 'At least one truck must be selected' },
        { status: 400 }
      )
    }

    // Get route information to determine user_id
    const { data: route, error: routeError } = await supabase
      .from('irp_routes')
      .select('user_id')
      .eq('id', routeId)
      .single()

    if (routeError || !route) {
      return NextResponse.json(
        { error: 'Route not found' },
        { status: 404 }
      )
    }

    // Get truck details for the selected trucks
    const truckIds = trucks.map((truck: TruckRequest) => truck.truck_id)
    const { data: truckDetails, error: truckError } = await supabase
      .from('irp_trucks')
      .select(`
        id,
        is_internal,
        contractor_name,
        contractor_rate
      `)
      .in('id', truckIds)
      .eq('user_id', route.user_id)
      .eq('is_active', true)

    if (truckError) {
      console.error('Error fetching truck details:', truckError)
      return NextResponse.json(
        { error: 'Failed to fetch truck details' },
        { status: 500 }
      )
    }

    // Get destination types for the user
    const { data: destinationTypes, error: destTypesError } = await supabase
      .from('irp_destination_types')
      .select(`
        id,
        name,
        description,
        extra_offloading_time,
        color_code,
        icon,
        irp_destination_type_trucks (
          truck_id
        )
      `)
      .eq('user_id', route.user_id)
      .eq('is_active', true) as { data: DestinationType[] | null, error: SupabaseError | null }

    if (destTypesError) {
      console.error('Error fetching destination types:', destTypesError)
      return NextResponse.json(
        { error: 'Failed to fetch destination types' },
        { status: 500 }
      )
    }

    // Create a mapping of truck_id to allowed destination types
    const truckDestinationTypeMap = new Map<string, DestinationType[]>()
    
    destinationTypes?.forEach(destType => {
      destType.irp_destination_type_trucks?.forEach((truckMapping: DestinationTypeMapping) => {
        const truckId = truckMapping.truck_id
        if (!truckDestinationTypeMap.has(truckId)) {
          truckDestinationTypeMap.set(truckId, [])
        }
        truckDestinationTypeMap.get(truckId)?.push({
          id: destType.id,
          name: destType.name,
          description: destType.description,
          extra_offloading_time: destType.extra_offloading_time,
          color_code: destType.color_code,
          icon: destType.icon
        })
      })
    })

    // Create a map of truck details for quick lookup
    const truckDetailsMap = new Map<string, TruckDetails>()
    truckDetails?.forEach(truck => {
      truckDetailsMap.set(truck.id, truck)
    })

    // Enhance truck data with destination type information and internal/external status
    const enhancedTrucks: EnhancedTruckData[] = trucks.map((truck: TruckRequest) => {
      const allowedDestinationTypes = truckDestinationTypeMap.get(truck.truck_id) || []
      const truckDetail = truckDetailsMap.get(truck.truck_id)
      
      return {
        ...truck,
        is_internal: truckDetail?.is_internal ?? true, // Default to internal if not found
        contractor_name: truckDetail?.contractor_name || null,
        contractor_rate: truckDetail?.contractor_rate || null,
        allowed_destination_types: allowedDestinationTypes
      }
    })
    
    console.log(`Sending to external API: ${enhancedTrucks.length} trucks with destination type specifications and internal/external status`)
    console.log('Enhanced truck data:', enhancedTrucks)
    
    // Call the external API from the server side
    const externalResponse = await fetch(`https://workflow.solve-x.ai/webhook/calculate-trips?route_id=${routeId}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        trucks: enhancedTrucks,
        trucker_working_hours: truckerWorkingHours
      }) // Send enhanced truck data with destination types and working hours
    })
    
    if (!externalResponse.ok) {
      return NextResponse.json(
        { error: `External API call failed: ${externalResponse.status} ${externalResponse.statusText}` },
        { status: externalResponse.status }
      )
    }
    
    // Return success response
    const apiResponse: CalculateTripsResponse = {
      success: true,
      message: `Trip calculation API called successfully with destination type information, internal/external truck status, and ${truckerWorkingHours} working hours`,
      routeId,
      truckDetails: enhancedTrucks,
      destinationTypesIncluded: destinationTypes?.length || 0,
      totalTruckDestinationTypeMappings: Array.from(truckDestinationTypeMap.values()).reduce((sum, types) => sum + types.length, 0)
    }
    
    return NextResponse.json(apiResponse, { status: 200 })
    
  } catch (error) {
    console.error('Error in calculate-trips API:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
