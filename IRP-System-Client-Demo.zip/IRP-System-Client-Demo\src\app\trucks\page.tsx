'use client'

import { useState } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'
import { mockTrucks } from '@/lib/mock-data'

interface TruckListItem {
  id: string
  displayName: string
  isInternal: boolean
  capacityPallets: number
  availableCount: number
  vehicleType: 'standard' | 'tailgate' | 'refrigerated' | 'flatbed'
  contractorName?: string
  contractorRate?: number
  isActive: boolean
  createdAt: string
}

interface Truck {
  id: string
  display_name: string
  is_internal: boolean
  capacity_pallets: number
  available_count: number
  vehicle_type: string
  fuel_efficiency?: number
  operating_cost_per_km?: number
  driver_required: boolean
  contractor_name?: string
  contractor_contact?: string
  contractor_rate?: number
  notes?: string
}

export default function TrucksPage() {
  const { user } = useAuth()
  const [trucks, setTrucks] = useState<TruckListItem[]>(
    mockTrucks.map(truck => ({
      id: truck.id,
      displayName: truck.display_name,
      isInternal: truck.is_internal,
      capacityPallets: truck.capacity_pallets,
      availableCount: truck.available_count,
      vehicleType: truck.vehicle_type as 'standard' | 'tailgate' | 'refrigerated' | 'flatbed',
      contractorName: undefined,
      contractorRate: undefined,
      isActive: truck.is_active,
      createdAt: truck.created_at
    }))
  )
  const [isLoading] = useState(false)
  const [error] = useState<string | null>(null)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedTruck, setSelectedTruck] = useState<Truck | null>(null)

  const handleCreateTruck = (truckData: {
    display_name: string
    is_internal: boolean
    capacity_pallets: number
    available_count: number
    vehicle_type: string
    fuel_efficiency?: number
    operating_cost_per_km?: number
    driver_required: boolean
    contractor_name?: string
    contractor_contact?: string
    contractor_rate?: number
    notes?: string
  }) => {
    // Simulate creating truck
    console.log('Creating truck (mock):', truckData)
    
    const newTruck: TruckListItem = {
      id: `mock-truck-${Date.now()}`,
      displayName: truckData.display_name,
      isInternal: truckData.is_internal,
      capacityPallets: truckData.capacity_pallets,
      availableCount: truckData.available_count,
      vehicleType: truckData.vehicle_type as 'standard' | 'tailgate' | 'refrigerated' | 'flatbed',
      contractorName: truckData.contractor_name,
      contractorRate: truckData.contractor_rate,
      isActive: true,
      createdAt: new Date().toISOString()
    }
    
    setTrucks(prev => [...prev, newTruck])
    setIsCreateModalOpen(false)
    alert('Truck created successfully! (Demo mode)')
  }

  const handleEditTruck = (truckId: string, updates: {
    display_name: string
    is_internal: boolean
    capacity_pallets: number
    available_count: number
    vehicle_type: string
    fuel_efficiency?: number
    operating_cost_per_km?: number
    driver_required: boolean
    contractor_name?: string
    contractor_contact?: string
    contractor_rate?: number
    notes?: string
  }) => {
    // Simulate updating truck
    console.log('Updating truck (mock):', truckId, updates)
    
    setTrucks(prev => prev.map(truck => 
      truck.id === truckId 
        ? {
            ...truck,
            displayName: updates.display_name,
            isInternal: updates.is_internal,
            capacityPallets: updates.capacity_pallets,
            availableCount: updates.available_count,
            vehicleType: updates.vehicle_type as 'standard' | 'tailgate' | 'refrigerated' | 'flatbed',
            contractorName: updates.contractor_name,
            contractorRate: updates.contractor_rate
          }
        : truck
    ))
    
    setIsEditModalOpen(false)
    setSelectedTruck(null)
    alert('Truck updated successfully! (Demo mode)')
  }

  const handleDeleteTruck = (truckId: string) => {
    if (!confirm('Are you sure you want to delete this truck?')) return
    
    // Simulate deleting truck
    console.log('Deleting truck (mock):', truckId)
    setTrucks(prev => prev.filter(truck => truck.id !== truckId))
    alert('Truck deleted successfully! (Demo mode)')
  }

  const getTruckTypeColor = (type: string) => {
    switch (type) {
      case 'standard': return 'bg-blue-100 text-blue-800'
      case 'tailgate': return 'bg-green-100 text-green-800'
      case 'refrigerated': return 'bg-purple-100 text-purple-800'
      case 'flatbed': return 'bg-orange-100 text-orange-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getTruckTypeIcon = (type: string) => {
    switch (type) {
      case 'standard': return '🚛'
      case 'tailgate': return '🚚'
      case 'refrigerated': return '🧊'
      case 'flatbed': return '📦'
      default: return '🚛'
    }
  }

  return (
    <ProtectedRoute>
      <Layout currentPage="Trucks">
        <div className="p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Truck Management</h1>
              <p className="text-gray-600">Manage your fleet of company and contractor trucks</p>
            </div>
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md flex items-center space-x-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              <span>Add Truck</span>
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-md">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              </div>
            </div>
          )}

          {/* Loading State */}
          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <>
              {/* Trucks Grid */}
              {trucks.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-6xl mb-4">🚛</div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No trucks found</h3>
                  <p className="text-gray-600 mb-4">Get started by adding your first truck to the fleet.</p>
                  <button
                    onClick={() => setIsCreateModalOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md"
                  >
                    Add Your First Truck
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {trucks.map((truck) => (
                    <div key={truck.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                      {/* Truck Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="text-2xl">{getTruckTypeIcon(truck.vehicleType)}</div>
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">{truck.displayName}</h3>
                            <div className="flex items-center space-x-2">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getTruckTypeColor(truck.vehicleType)}`}>
                                {truck.vehicleType}
                              </span>
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                truck.isInternal ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                              }`}>
                                {truck.isInternal ? 'Company' : 'Contractor'}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-1">
                          <button
                            onClick={() => {
                              // Simulate getting truck details
                              const mockTruckDetails: Truck = {
                                id: truck.id,
                                display_name: truck.displayName,
                                is_internal: truck.isInternal,
                                capacity_pallets: truck.capacityPallets,
                                available_count: truck.availableCount,
                                vehicle_type: truck.vehicleType,
                                driver_required: true,
                                contractor_name: truck.contractorName,
                                contractor_rate: truck.contractorRate,
                                notes: ''
                              }
                              setSelectedTruck(mockTruckDetails)
                              setIsEditModalOpen(true)
                            }}
                            className="p-1 text-gray-400 hover:text-gray-600"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                          </button>
                          <button
                            onClick={() => handleDeleteTruck(truck.id)}
                            className="p-1 text-gray-400 hover:text-red-600"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </div>

                      {/* Truck Details */}
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-600">Capacity:</span>
                          <span className="text-sm font-medium text-gray-900">{truck.capacityPallets} pallets</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sm text-gray-600">Available:</span>
                          <span className="text-sm font-medium text-gray-900">{truck.availableCount} trucks</span>
                        </div>
                        {!truck.isInternal && truck.contractorName && (
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Contractor:</span>
                            <span className="text-sm font-medium text-gray-900">{truck.contractorName}</span>
                          </div>
                        )}
                        {!truck.isInternal && truck.contractorRate && (
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Rate:</span>
                            <span className="text-sm font-medium text-gray-900">${truck.contractorRate}/day</span>
                          </div>
                        )}
                      </div>

                      {/* Status */}
                      <div className="mt-4 pt-4 border-t border-gray-200">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600">Status:</span>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            truck.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {truck.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {/* Create Truck Modal */}
          {isCreateModalOpen && (
            <CreateTruckModal
              isOpen={isCreateModalOpen}
              onClose={() => setIsCreateModalOpen(false)}
              onSubmit={handleCreateTruck}
            />
          )}

          {/* Edit Truck Modal */}
          {isEditModalOpen && selectedTruck && (
            <EditTruckModal
              isOpen={isEditModalOpen}
              onClose={() => {
                setIsEditModalOpen(false)
                setSelectedTruck(null)
              }}
              truck={selectedTruck}
              onSubmit={(updates) => handleEditTruck(selectedTruck.id, updates)}
            />
          )}
        </div>
      </Layout>
    </ProtectedRoute>
  )
}

// Create Truck Modal Component
function CreateTruckModal({ isOpen, onClose, onSubmit }: {
  isOpen: boolean
  onClose: () => void
  onSubmit: (data: {
    display_name: string
    is_internal: boolean
    capacity_pallets: number
    available_count: number
    vehicle_type: string
    fuel_efficiency?: number
    operating_cost_per_km?: number
    driver_required: boolean
    contractor_name?: string
    contractor_contact?: string
    contractor_rate?: number
    notes?: string
  }) => void
}) {
  const [formData, setFormData] = useState({
    display_name: '',
    is_internal: true,
    capacity_pallets: '',
    available_count: '',
    vehicle_type: 'standard',
    fuel_efficiency: '',
    operating_cost_per_km: '',
    driver_required: true,
    contractor_name: '',
    contractor_contact: '',
    contractor_rate: '',
    notes: ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      capacity_pallets: parseFloat(formData.capacity_pallets),
      available_count: parseInt(formData.available_count),
      fuel_efficiency: formData.fuel_efficiency ? parseFloat(formData.fuel_efficiency) : undefined,
      operating_cost_per_km: formData.operating_cost_per_km ? parseFloat(formData.operating_cost_per_km) : undefined,
      contractor_rate: formData.contractor_rate ? parseFloat(formData.contractor_rate) : undefined,
      contractor_name: formData.is_internal ? undefined : formData.contractor_name,
      contractor_contact: formData.is_internal ? undefined : formData.contractor_contact
    })
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Add New Truck</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
            <input
              type="text"
              value={formData.display_name}
              onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Truck Type</label>
            <select
              value={formData.is_internal ? 'internal' : 'contractor'}
              onChange={(e) => setFormData({ ...formData, is_internal: e.target.value === 'internal' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
            >
              <option value="internal">Company Truck</option>
              <option value="contractor">Contractor Truck</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Capacity (pallets)</label>
              <input
                type="number"
                step="0.1"
                value={formData.capacity_pallets}
                onChange={(e) => setFormData({ ...formData, capacity_pallets: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Available Count</label>
              <input
                type="number"
                value={formData.available_count}
                onChange={(e) => setFormData({ ...formData, available_count: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Type</label>
            <select
              value={formData.vehicle_type}
              onChange={(e) => setFormData({ ...formData, vehicle_type: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
            >
              <option value="standard">Standard</option>
              <option value="tailgate">Tailgate</option>
              <option value="refrigerated">Refrigerated</option>
              <option value="flatbed">Flatbed</option>
            </select>
          </div>

          {!formData.is_internal && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor Name</label>
                <input
                  type="text"
                  value={formData.contractor_name}
                  onChange={(e) => setFormData({ ...formData, contractor_name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor Contact</label>
                <input
                  type="text"
                  value={formData.contractor_contact}
                  onChange={(e) => setFormData({ ...formData, contractor_contact: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor Rate ($/day)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.contractor_rate}
                  onChange={(e) => setFormData({ ...formData, contractor_rate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Create Truck
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// Edit Truck Modal Component
function EditTruckModal({ isOpen, onClose, truck, onSubmit }: {
  isOpen: boolean
  onClose: () => void
  truck: Truck
  onSubmit: (data: {
    display_name: string
    is_internal: boolean
    capacity_pallets: number
    available_count: number
    vehicle_type: string
    fuel_efficiency?: number
    operating_cost_per_km?: number
    driver_required: boolean
    contractor_name?: string
    contractor_contact?: string
    contractor_rate?: number
    notes?: string
  }) => void
}) {
  const [formData, setFormData] = useState({
    display_name: truck.display_name || '',
    is_internal: truck.is_internal ?? true,
    capacity_pallets: truck.capacity_pallets?.toString() || '',
    available_count: truck.available_count?.toString() || '',
    vehicle_type: truck.vehicle_type || 'standard',
    fuel_efficiency: truck.fuel_efficiency?.toString() || '',
    operating_cost_per_km: truck.operating_cost_per_km?.toString() || '',
    driver_required: truck.driver_required ?? true,
    contractor_name: truck.contractor_name || '',
    contractor_contact: truck.contractor_contact || '',
    contractor_rate: truck.contractor_rate?.toString() || '',
    notes: truck.notes || ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      capacity_pallets: parseFloat(formData.capacity_pallets),
      available_count: parseInt(formData.available_count),
      fuel_efficiency: formData.fuel_efficiency ? parseFloat(formData.fuel_efficiency) : undefined,
      operating_cost_per_km: formData.operating_cost_per_km ? parseFloat(formData.operating_cost_per_km) : undefined,
      contractor_rate: formData.contractor_rate ? parseFloat(formData.contractor_rate) : undefined,
      contractor_name: formData.is_internal ? undefined : formData.contractor_name,
      contractor_contact: formData.is_internal ? undefined : formData.contractor_contact
    })
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Edit Truck</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Display Name</label>
            <input
              type="text"
              value={formData.display_name}
              onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Truck Type</label>
            <select
              value={formData.is_internal ? 'internal' : 'contractor'}
              onChange={(e) => setFormData({ ...formData, is_internal: e.target.value === 'internal' })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
            >
              <option value="internal">Company Truck</option>
              <option value="contractor">Contractor Truck</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Capacity (pallets)</label>
              <input
                type="number"
                step="0.1"
                value={formData.capacity_pallets}
                onChange={(e) => setFormData({ ...formData, capacity_pallets: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Available Count</label>
              <input
                type="number"
                value={formData.available_count}
                onChange={(e) => setFormData({ ...formData, available_count: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Type</label>
            <select
              value={formData.vehicle_type}
              onChange={(e) => setFormData({ ...formData, vehicle_type: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
            >
              <option value="standard">Standard</option>
              <option value="tailgate">Tailgate</option>
              <option value="refrigerated">Refrigerated</option>
              <option value="flatbed">Flatbed</option>
            </select>
          </div>

          {!formData.is_internal && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor Name</label>
                <input
                  type="text"
                  value={formData.contractor_name}
                  onChange={(e) => setFormData({ ...formData, contractor_name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor Contact</label>
                <input
                  type="text"
                  value={formData.contractor_contact}
                  onChange={(e) => setFormData({ ...formData, contractor_contact: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contractor Rate ($/day)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.contractor_rate}
                  onChange={(e) => setFormData({ ...formData, contractor_rate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-900"
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Update Truck
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}