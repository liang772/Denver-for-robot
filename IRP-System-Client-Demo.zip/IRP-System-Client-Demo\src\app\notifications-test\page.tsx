'use client'

/**
 * Notification Testing & Configuration Page
 * Phase 4: Test notification workflows
 */

import { useState } from 'react'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'

export default function NotificationTestPage() {
  const [testType, setTestType] = useState<'d1-pre-delivery' | 'on-the-way' | 'next-trip'>('d1-pre-delivery')
  const [journeyId, setJourneyId] = useState('')
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [isTesting, setIsTesting] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [configStatus, setConfigStatus] = useState<any>(null)

  const checkConfiguration = async () => {
    try {
      const response = await fetch('/api/notifications')
      const data = await response.json()
      setConfigStatus(data)
    } catch (error) {
      console.error('Error checking configuration:', error)
    }
  }

  const handleTest = async () => {
    setIsTesting(true)
    setResult(null)

    try {
      const body: any = { type: testType }
      
      if (testType === 'd1-pre-delivery') {
        body.date = date
      } else {
        body.journeyId = journeyId
      }

      const response = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })

      const data = await response.json()
      setResult(data)
    } catch (error) {
      setResult({ error: 'Failed to send test notification', details: error instanceof Error ? error.message : 'Unknown error' })
    } finally {
      setIsTesting(false)
    }
  }

  return (
    <ProtectedRoute>
      <Layout>
        <div className="max-w-4xl mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Notification System</h1>

          {/* Configuration Status */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Configuration Status</h2>
              <button
                onClick={checkConfiguration}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Check Status
              </button>
            </div>

            {configStatus && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className={`w-3 h-3 rounded-full ${configStatus.twilioConfigured ? 'bg-green-500' : 'bg-red-500'}`}></span>
                  <span className="font-medium">
                    Twilio: {configStatus.twilioConfigured ? 'Configured ✓' : 'Not Configured ✗'}
                  </span>
                </div>
                <p className="text-sm text-gray-600 ml-5">{configStatus.message}</p>
                
                {!configStatus.twilioConfigured && (
                  <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h3 className="font-semibold text-yellow-800 mb-2">📝 Setup Instructions:</h3>
                    <ol className="list-decimal list-inside space-y-1 text-sm text-yellow-900">
                      <li>Create a Twilio account at <a href="https://www.twilio.com" target="_blank" className="text-blue-600 underline">twilio.com</a></li>
                      <li>Get your Account SID and Auth Token from the Twilio Console</li>
                      <li>Purchase a phone number with SMS/WhatsApp capabilities</li>
                      <li>Add these to your <code className="bg-yellow-100 px-1 rounded">.env.local</code> file:</li>
                    </ol>
                    <pre className="mt-2 p-3 bg-gray-800 text-gray-100 rounded text-xs overflow-x-auto">
{`TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
TWILIO_PHONE_NUMBER=+1234567890`}
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Test Notification */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Test Notification</h2>

            <div className="space-y-4">
              {/* Notification Type */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notification Type
                </label>
                <select
                  value={testType}
                  onChange={(e) => setTestType(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="d1-pre-delivery">D-1 Pre-Delivery (Evening Before)</option>
                  <option value="on-the-way">On The Way (Journey Start)</option>
                  <option value="next-trip">Next Trip (Trip Complete)</option>
                </select>
                <p className="mt-1 text-sm text-gray-500">
                  {testType === 'd1-pre-delivery' && 'Sends delivery time window to customers one day before delivery'}
                  {testType === 'on-the-way' && 'Notifies customers when driver starts the journey'}
                  {testType === 'next-trip' && 'Notifies next batch of customers when current trip completes'}
                </p>
              </div>

              {/* Date Input (for D-1) */}
              {testType === 'd1-pre-delivery' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Delivery Date
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              )}

              {/* Journey ID Input (for journey-based notifications) */}
              {(testType === 'on-the-way' || testType === 'next-trip') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Journey ID
                  </label>
                  <input
                    type="text"
                    value={journeyId}
                    onChange={(e) => setJourneyId(e.target.value)}
                    placeholder="Enter journey UUID"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    You can find journey IDs in the Journeys page
                  </p>
                </div>
              )}

              {/* Send Button */}
              <button
                onClick={handleTest}
                disabled={isTesting || (testType !== 'd1-pre-delivery' && !journeyId)}
                className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                {isTesting ? '📤 Sending...' : '📨 Send Test Notification'}
              </button>
            </div>

            {/* Result Display */}
            {result && (
              <div className={`mt-6 p-4 rounded-lg ${result.success ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                <h3 className={`font-semibold mb-2 ${result.success ? 'text-green-800' : 'text-red-800'}`}>
                  {result.success ? '✅ Success' : '❌ Error'}
                </h3>
                <pre className="text-sm overflow-x-auto">
                  {JSON.stringify(result, null, 2)}
                </pre>
              </div>
            )}
          </div>

          {/* Workflow Documentation */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-semibold text-blue-900 mb-3">📋 Notification Workflows</h3>
            <div className="space-y-3 text-sm text-blue-900">
              <div>
                <strong>1. D-1 Pre-Delivery (19:00 Daily)</strong>
                <p className="ml-4">• Runs automatically every evening at 7 PM</p>
                <p className="ml-4">• Sends delivery time window to next day's customers</p>
                <p className="ml-4">• Maps ETA to time slots: 10-14, 14-18, 18-20</p>
              </div>
              <div>
                <strong>2. On The Way</strong>
                <p className="ml-4">• Triggered when driver presses "Start Journey"</p>
                <p className="ml-4">• Notifies all customers in that journey</p>
                <p className="ml-4">• Includes updated ETA</p>
              </div>
              <div>
                <strong>3. Next Trip</strong>
                <p className="ml-4">• Triggered when driver completes a trip</p>
                <p className="ml-4">• Notifies customers in the next trip</p>
                <p className="ml-4">• Updates them that their delivery is next</p>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
