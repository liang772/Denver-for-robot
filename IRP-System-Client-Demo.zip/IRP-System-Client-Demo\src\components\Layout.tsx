'use client'

import { useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface LayoutProps {
  children: React.ReactNode
  currentPage?: string
}

export default function Layout({ children, currentPage = 'Dashboard' }: LayoutProps) {
  const { user, signOut } = useAuth()
  const router = useRouter()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleSignOut = async () => {
    await signOut()
    router.push('/login')
  }

  if (!user) {
    return null
  }

  return (
    <div className="h-screen flex overflow-hidden bg-gray-100">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'block' : 'hidden'} md:block md:w-64 md:flex-shrink-0`}>
        <div className="flex flex-col h-full bg-gray-800">
          {/* Logo */}
          <div className="flex items-center justify-center h-16 bg-gray-900">
            <h1 className="text-xl font-bold text-white">IRP</h1>
          </div>
          
          {/* Navigation */}
          <nav className="flex-1 px-2 py-4 space-y-1">
            <Link
              href="/dashboard"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Dashboard'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              📊 Dashboard
            </Link>
            <Link
              href="/journeys"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Journeys'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              🚛 Journeys
            </Link>
            <Link
              href="/templates"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Templates'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              📋 Templates
            </Link>
            <Link
              href="/routes"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Routes'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              📦 Routes
            </Link>
            <Link
              href="/live-tracking"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Live Tracking'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              🗺️ Live Tracking
            </Link>
            <Link
              href="/slot-planner"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Slot Planner'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              📅 Slot Planner
            </Link>
            <Link
              href="/notifications-test"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Notifications'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              📱 Notifications
            </Link>
            <Link
              href="/telegram"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Telegram'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              💬 Telegram Bot
            </Link>
            <Link
              href="/trucks"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Trucks'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              🚚 Trucks
            </Link>
            <Link
              href="/destination-types"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Destination Types'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              📍 Destination Types
            </Link>
            <Link
              href="/settings"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Settings'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              ⚙️ Settings
            </Link>
            <Link
              href="/demo"
              className={`group flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                currentPage === 'Feature Demo'
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              🎯 Feature Demo
            </Link>
          </nav>
          
          {/* User info and logout */}
          <div className="flex-shrink-0 flex bg-gray-700 p-4">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 rounded-full bg-gray-400 flex items-center justify-center">
                  <span className="text-sm font-medium text-gray-700">
                    {user.email?.charAt(0).toUpperCase()}
                  </span>
                </div>
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-white">{user.email}</p>
                <button
                  onClick={handleSignOut}
                  className="text-xs text-gray-300 hover:text-white"
                >
                  Sign out
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        {/* Top bar */}
        <div className="md:hidden">
          <div className="flex items-center justify-between h-16 bg-gray-800 px-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-300 hover:text-white"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <h1 className="text-xl font-bold text-white">IRP</h1>
            <div className="w-6"></div>
          </div>
        </div>

        {/* Page header */}
        <div className="bg-white shadow-sm border-b border-gray-200">
          <div className="px-4 py-4 sm:px-6 lg:px-8">
            <h1 className="text-2xl font-bold text-gray-900">{currentPage}</h1>
          </div>
        </div>

        {/* Main content area */}
        <main className="flex-1 relative overflow-y-auto focus:outline-none">
          {children}
        </main>
      </div>
    </div>
  )
}
