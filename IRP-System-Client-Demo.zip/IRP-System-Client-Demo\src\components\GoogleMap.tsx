'use client'

import { useEffect, useRef } from 'react'

interface GoogleMapProps {
  drivers: Array<{
    driver_id: string
    driver_name: string
    truck_name: string
    latitude: number
    longitude: number
    journey_name: string
    journey_status: string
    current_trip: number
    total_trips: number
    last_updated: string
  }>
}

interface GoogleMaps {
  maps: {
    Map: new (element: HTMLElement, options: any) => any
    Marker: new (options: any) => any
    InfoWindow: new (options: any) => any
    LatLngBounds: new () => any
    Size: new (width: number, height: number) => any
    Point: new (x: number, y: number) => any
    MapTypeId: { ROADMAP: string }
    ControlPosition: any
    MapTypeControlStyle: any
    event: { addListener: (instance: any, eventName: string, handler: () => void) => any; removeListener: (listener: any) => void }
  }
}

declare global {
  interface Window {
    google: GoogleMaps
    initGoogleMap: () => void
  }
}

export default function GoogleMap({ drivers }: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<any>(null)
  const markersRef = useRef<unknown[]>([])

  useEffect(() => {
    // Load Google Maps API
    const loadGoogleMaps = () => {
      if (window.google) {
        initializeMap()
        return
      }

      // Check if script is already loading
      if (document.querySelector('script[src*="maps.googleapis.com"]')) {
        window.initGoogleMap = initializeMap
        return
      }

      // Create script element
      const script = document.createElement('script')
      script.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || 'YOUR_API_KEY'}&callback=initGoogleMap&language=en&region=US`
      script.async = true
      script.defer = true
      
      window.initGoogleMap = initializeMap
      document.head.appendChild(script)
    }

    const initializeMap = () => {
      if (!mapRef.current || !window.google) return

      // Initialize map centered on Beijing with English interface
      const map = new window.google.maps.Map(mapRef.current, {
        zoom: 11,
        center: { lat: 39.9042, lng: 116.4074 },
        mapTypeId: window.google.maps.MapTypeId.ROADMAP,
        mapTypeControl: true,
        mapTypeControlOptions: {
          style: window.google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
          position: window.google.maps.ControlPosition.TOP_CENTER,
        },
        zoomControl: true,
        zoomControlOptions: {
          position: window.google.maps.ControlPosition.RIGHT_CENTER,
        },
        scaleControl: true,
        streetViewControl: true,
        streetViewControlOptions: {
          position: window.google.maps.ControlPosition.RIGHT_TOP,
        },
        fullscreenControl: true,
        styles: [
          {
            featureType: 'poi.business',
            elementType: 'labels',
            stylers: [{ visibility: 'off' }]
          },
          {
            featureType: 'transit',
            elementType: 'labels.icon',
            stylers: [{ visibility: 'off' }]
          }
        ]
      })

      mapInstanceRef.current = map
      updateMarkers()
    }

    const updateMarkers = () => {
      if (!mapInstanceRef.current || !window.google) return

      // Clear existing markers
      markersRef.current.forEach(marker => marker.setMap(null))
      markersRef.current = []

      // Add driver markers
      drivers.forEach((driver) => {
        const marker = new window.google.maps.Marker({
          position: { lat: driver.latitude, lng: driver.longitude },
          map: mapInstanceRef.current,
          title: driver.driver_name,
          icon: {
            url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
              <svg width="40" height="40" xmlns="http://www.w3.org/2000/svg">
                <circle cx="20" cy="20" r="18" fill="${driver.journey_status === 'active' ? '#10B981' : '#F59E0B'}" stroke="white" stroke-width="3"/>
                <text x="20" y="26" text-anchor="middle" fill="white" font-size="16">🚛</text>
              </svg>
            `)}`,
            scaledSize: new window.google.maps.Size(40, 40),
            anchor: new window.google.maps.Point(20, 20)
          }
        })

        const infoWindow = new window.google.maps.InfoWindow({
          content: `
            <div style="min-width: 200px; padding: 8px;">
              <h3 style="font-weight: bold; margin-bottom: 8px; font-size: 16px;">
                🚛 ${driver.driver_name}
              </h3>
              <div style="font-size: 13px; line-height: 1.6;">
                <div style="margin-bottom: 4px;">
                  <strong>Truck:</strong> ${driver.truck_name}
                </div>
                <div style="margin-bottom: 4px;">
                  <strong>Journey:</strong> ${driver.journey_name}
                </div>
                <div style="margin-bottom: 4px;">
                  <strong>Status:</strong> 
                  <span style="
                    padding: 2px 8px;
                    border-radius: 12px;
                    background-color: ${driver.journey_status === 'active' ? '#D1FAE5' : '#FEF3C7'};
                    color: ${driver.journey_status === 'active' ? '#065F46' : '#92400E'};
                    font-weight: 600;
                    font-size: 11px;
                  ">
                    ${driver.journey_status === 'active' ? '🟢 Active' : '🟡 In Progress'}
                  </span>
                </div>
                <div style="margin-bottom: 4px;">
                  <strong>Progress:</strong> Trip ${driver.current_trip} of ${driver.total_trips}
                </div>
                <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #E5E7EB; color: #6B7280; font-size: 11px;">
                  Last updated: ${formatLastUpdated(driver.last_updated)}
                </div>
              </div>
            </div>
          `
        })

        marker.addListener('click', () => {
          infoWindow.open(mapInstanceRef.current, marker)
        })

        markersRef.current.push(marker)
      })

      // Fit map to show all drivers
      if (drivers.length > 0) {
        const bounds = new window.google.maps.LatLngBounds()
        drivers.forEach(driver => {
          bounds.extend({ lat: driver.latitude, lng: driver.longitude })
        })
        mapInstanceRef.current.fitBounds(bounds)
        
        // Ensure minimum zoom level
        const listener = window.google.maps.event.addListener(mapInstanceRef.current, 'idle', () => {
          if (mapInstanceRef.current.getZoom() > 15) {
            mapInstanceRef.current.setZoom(15)
          }
          window.google.maps.event.removeListener(listener)
        })
      }
    }

    const formatLastUpdated = (timestamp: string) => {
      const date = new Date(timestamp)
      const now = new Date()
      const diffMs = now.getTime() - date.getTime()
      const diffMins = Math.floor(diffMs / 60000)

      if (diffMins < 1) return 'Just now'
      if (diffMins < 60) return `${diffMins}m ago`
      const diffHours = Math.floor(diffMins / 60)
      return `${diffHours}h ago`
    }

    loadGoogleMaps()

    return () => {
      // Cleanup markers
      markersRef.current.forEach(marker => marker.setMap(null))
      markersRef.current = []
    }
  }, [drivers])

  return (
    <div className="w-full h-full">
      <div 
        ref={mapRef} 
        className="w-full h-full rounded-lg"
        style={{ minHeight: '400px' }}
      />
      {!process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY && (
        <div className="absolute inset-0 bg-yellow-50 border border-yellow-200 rounded-lg flex items-center justify-center">
          <div className="text-center p-4">
            <div className="text-yellow-600 mb-2">⚠️ Google Maps API Key Required</div>
            <div className="text-sm text-yellow-700">
              Add NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to your .env.local file
            </div>
          </div>
        </div>
      )}
    </div>
  )
}