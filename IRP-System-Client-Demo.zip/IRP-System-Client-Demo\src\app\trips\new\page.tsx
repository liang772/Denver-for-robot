'use client'

/**
 * Manual Trip Creation Page
 * Phase 2.1: Manual trip creation UI as alternative to Excel upload
 */

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Layout from '@/components/Layout'
import ProtectedRoute from '@/components/ProtectedRoute'
import { useAuth } from '@/contexts/AuthContext'
import { createClient } from '@/lib/supabase'

interface Truck {
  id: string
  display_name: string
  capacity_pallets: number
  vehicle_type: string
  is_internal: boolean
}

interface Journey {
  id: string
  name: string
  date: string
}

interface Destination {
  id: string
  address: string
  load_pallets: number
  delivery_type: 'delivery' | 'refund_pickup' | 'pickup'
  requires_tailgate: boolean
  customer_name: string
  customer_phone: string
  notes: string
}

export default function CreateTripPage() {
  const router = useRouter()
  const { user } = useAuth()

  const [tripName, setTripName] = useState('')
  const [selectedJourneyId, setSelectedJourneyId] = useState('')
  const [selectedTruckId, setSelectedTruckId] = useState('')
  const [loadingTime, setLoadingTime] = useState('30')
  const [returnTime, setReturnTime] = useState('20')
  
  const [destinations, setDestinations] = useState<Destination[]>([])
  const [journeys, setJourneys] = useState<Journey[]>([])
  const [trucks, setTrucks] = useState<Truck[]>([])
  
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingData, setIsLoadingData] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      fetchInitialData()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  const fetchInitialData = async () => {
    try {
      setIsLoadingData(true)
      const supabase = createClient()

      // Fetch journeys
      const { data: journeysData, error: journeysError } = await supabase
        .from('irp_journeys')
        .select('id, name, date')
        .eq('user_id', user!.id)
        .order('date', { ascending: false })
        .limit(20)

      if (journeysError) throw journeysError
      setJourneys(journeysData || [])

      // Fetch trucks
      const { data: trucksData, error: trucksError } = await supabase
        .from('irp_trucks')
        .select('*')
        .eq('user_id', user!.id)
        .order('display_name', { ascending: true })

      if (trucksError) throw trucksError
      setTrucks(trucksData || [])
    } catch (err) {
      console.error('Error loading data:', err)
      setError('Failed to load journeys and trucks')
    } finally {
      setIsLoadingData(false)
    }
  }

  const addDestination = () => {
    setDestinations([
      ...destinations,
      {
        id: `temp-${Date.now()}`,
        address: '',
        load_pallets: 0,
        delivery_type: 'delivery',
        requires_tailgate: false,
        customer_name: '',
        customer_phone: '',
        notes: '',
      },
    ])
  }

  const updateDestination = (index: number, field: keyof Destination, value: string | number | boolean) => {
    const updated = [...destinations]
    updated[index] = { ...updated[index], [field]: value }
    setDestinations(updated)
  }

  const removeDestination = (index: number) => {
    setDestinations(destinations.filter((_, i) => i !== index))
  }

  const validateForm = (): string | null => {
    if (!tripName.trim()) {
      return 'Trip name is required'
    }

    if (!selectedTruckId) {
      return 'Please select a truck'
    }

    if (destinations.length === 0) {
      return 'Please add at least one destination'
    }

    for (let i = 0; i < destinations.length; i++) {
      const dest = destinations[i]
      if (!dest.address.trim()) {
        return `Destination ${i + 1}: Address is required`
      }
      if (dest.load_pallets <= 0) {
        return `Destination ${i + 1}: Load must be greater than 0`
      }
    }

    // Check total capacity
    const selectedTruck = trucks.find((t) => t.id === selectedTruckId)
    if (selectedTruck) {
      let currentLoad = 0
      for (const dest of destinations) {
        if (dest.delivery_type === 'delivery' || dest.delivery_type === 'pickup') {
          currentLoad += dest.load_pallets
        } else if (dest.delivery_type === 'refund_pickup') {
          currentLoad -= dest.load_pallets
        }
        
        if (currentLoad > selectedTruck.capacity_pallets) {
          return `Total load exceeds truck capacity (${selectedTruck.capacity_pallets} pallets)`
        }
        
        if (currentLoad < 0) {
          return 'Load cannot be negative (check refund pickup quantities)'
        }
      }
    }

    return null
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const validationError = validateForm()
    if (validationError) {
      setError(validationError)
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Calculate total load
      const totalLoad = destinations.reduce((sum, dest) => {
        if (dest.delivery_type === 'delivery' || dest.delivery_type === 'pickup') {
          return sum + dest.load_pallets
        } else if (dest.delivery_type === 'refund_pickup') {
          return sum - dest.load_pallets
        }
        return sum
      }, 0)

      // Create trip
      const tripData: Record<string, unknown> = {
        user_id: user!.id,
        truck_id: selectedTruckId,
        loading_time: parseInt(loadingTime),
        return_to_warehouse_time: parseInt(returnTime),
        total_load: totalLoad,
        requires_tailgate: destinations.some((d) => d.requires_tailgate),
        status: 'pending',
      }

      // Add journey if selected
      if (selectedJourneyId) {
        tripData.journey_id = selectedJourneyId
        
        // Get journey sequence number
        const { data: existingTrips } = await supabase
          .from('irp_trips')
          .select('journey_sequence')
          .eq('journey_id', selectedJourneyId)
          .order('journey_sequence', { ascending: false })
          .limit(1)

        tripData.journey_sequence = existingTrips && existingTrips.length > 0 
          ? existingTrips[0].journey_sequence + 1 
          : 1
      }

      const { data: trip, error: tripError } = await supabase
        .from('irp_trips')
        .insert(tripData)
        .select()
        .single()

      if (tripError) throw tripError

      // Create destinations
      for (let i = 0; i < destinations.length; i++) {
        const dest = destinations[i]
        await supabase
          .from('irp_trip_destinations')
          .insert({
            trip_id: trip.id,
            sequence: i,
            address: dest.address,
            load_pallets: dest.load_pallets,
            delivery_type: dest.delivery_type,
            requires_tailgate: dest.requires_tailgate,
            load_info: dest.customer_name || '',
            notes: dest.notes || null,
            offloading_time: 15, // Default 15 minutes
          })
      }

      // Success - redirect to journey detail if journey selected, else to routes
      if (selectedJourneyId) {
        router.push(`/journeys/${selectedJourneyId}`)
      } else {
        router.push(`/routes`)
      }
    } catch (err) {
      console.error('Error creating trip:', err)
      setError(err instanceof Error ? err.message : 'Failed to create trip')
      setIsLoading(false)
    }
  }

  if (isLoadingData) {
    return (
      <ProtectedRoute>
        <Layout>
          <div className="flex justify-center items-center min-h-screen">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        </Layout>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute>
      <Layout>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-6">
            <button
              onClick={() => router.back()}
              className="text-sm text-blue-600 hover:text-blue-700 mb-2 flex items-center gap-1"
            >
              ← Back
            </button>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Trip Manually</h1>
            <p className="text-sm text-gray-600">
              Create a trip by manually entering destination details
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Trip Details Card */}
            <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Trip Details</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Trip Name */}
                <div className="md:col-span-2">
                  <label htmlFor="tripName" className="block text-sm font-medium text-gray-700 mb-1">
                    Trip Name *
                  </label>
                  <input
                    type="text"
                    id="tripName"
                    value={tripName}
                    onChange={(e) => setTripName(e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                    placeholder="e.g., Morning Delivery Route"
                    required
                  />
                </div>

                {/* Journey Selection */}
                <div>
                  <label htmlFor="journey" className="block text-sm font-medium text-gray-700 mb-1">
                    Assign to Journey (Optional)
                  </label>
                  <select
                    id="journey"
                    value={selectedJourneyId}
                    onChange={(e) => setSelectedJourneyId(e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                  >
                    <option value="">No Journey (Standalone Trip)</option>
                    {journeys.map((j) => (
                      <option key={j.id} value={j.id}>
                        {j.name} ({j.date})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Truck Selection */}
                <div>
                  <label htmlFor="truck" className="block text-sm font-medium text-gray-700 mb-1">
                    Truck *
                  </label>
                  <select
                    id="truck"
                    value={selectedTruckId}
                    onChange={(e) => setSelectedTruckId(e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                    required
                  >
                    <option value="">Select a truck</option>
                    {trucks.map((t) => (
                      <option key={t.id} value={t.id}>
                        🚛 {t.display_name} ({t.capacity_pallets} pallets, {t.vehicle_type})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Loading Time */}
                <div>
                  <label htmlFor="loadingTime" className="block text-sm font-medium text-gray-700 mb-1">
                    Loading Time (minutes) *
                  </label>
                  <input
                    type="number"
                    id="loadingTime"
                    value={loadingTime}
                    onChange={(e) => setLoadingTime(e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                    min="0"
                    step="5"
                    required
                  />
                </div>

                {/* Return Time */}
                <div>
                  <label htmlFor="returnTime" className="block text-sm font-medium text-gray-700 mb-1">
                    Return to Warehouse Time (minutes) *
                  </label>
                  <input
                    type="number"
                    id="returnTime"
                    value={returnTime}
                    onChange={(e) => setReturnTime(e.target.value)}
                    disabled={isLoading}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                    min="0"
                    step="5"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Destinations Card */}
            <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">
                  Destinations ({destinations.length})
                </h2>
                <button
                  type="button"
                  onClick={addDestination}
                  disabled={isLoading}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  Add Destination
                </button>
              </div>

              {destinations.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <svg className="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <p className="text-lg">No destinations yet</p>
                  <p className="text-sm">Click &quot;Add Destination&quot; to get started</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {destinations.map((dest, index) => (
                    <div key={dest.id} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-semibold text-gray-900">Destination {index + 1}</span>
                        <button
                          type="button"
                          onClick={() => removeDestination(index)}
                          disabled={isLoading}
                          className="text-red-600 hover:text-red-700 text-sm font-medium disabled:opacity-50"
                        >
                          Remove
                        </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {/* Address */}
                        <div className="md:col-span-2">
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Address *
                          </label>
                          <textarea
                            value={dest.address}
                            onChange={(e) => updateDestination(index, 'address', e.target.value)}
                            disabled={isLoading}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                            rows={2}
                            placeholder="Enter full address"
                            required
                          />
                        </div>

                        {/* Customer Name */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Customer Name
                          </label>
                          <input
                            type="text"
                            value={dest.customer_name}
                            onChange={(e) => updateDestination(index, 'customer_name', e.target.value)}
                            disabled={isLoading}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                            placeholder="Optional"
                          />
                        </div>

                        {/* Customer Phone */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Customer Phone
                          </label>
                          <input
                            type="tel"
                            value={dest.customer_phone}
                            onChange={(e) => updateDestination(index, 'customer_phone', e.target.value)}
                            disabled={isLoading}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                            placeholder="Optional"
                          />
                        </div>

                        {/* Load Pallets */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Load (Pallets) *
                          </label>
                          <input
                            type="number"
                            value={dest.load_pallets}
                            onChange={(e) => updateDestination(index, 'load_pallets', parseFloat(e.target.value))}
                            disabled={isLoading}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                            min="0.1"
                            step="0.1"
                            placeholder="e.g., 5.5"
                            required
                          />
                        </div>

                        {/* Delivery Type */}
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Type *
                          </label>
                          <select
                            value={dest.delivery_type}
                            onChange={(e) => updateDestination(index, 'delivery_type', e.target.value)}
                            disabled={isLoading}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                            required
                          >
                            <option value="delivery">📦 Delivery</option>
                            <option value="refund_pickup">📥 Refund Pickup</option>
                            <option value="pickup">🔄 Pickup</option>
                          </select>
                        </div>

                        {/* Tailgate Checkbox */}
                        <div className="md:col-span-2 flex items-center">
                          <input
                            type="checkbox"
                            id={`tailgate-${index}`}
                            checked={dest.requires_tailgate}
                            onChange={(e) => updateDestination(index, 'requires_tailgate', e.target.checked)}
                            disabled={isLoading}
                            className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                          />
                          <label htmlFor={`tailgate-${index}`} className="ml-2 text-sm text-gray-700">
                            Requires Tailgate Lift
                          </label>
                        </div>

                        {/* Notes */}
                        <div className="md:col-span-2">
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Notes
                          </label>
                          <textarea
                            value={dest.notes}
                            onChange={(e) => updateDestination(index, 'notes', e.target.value)}
                            disabled={isLoading}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-100"
                            rows={2}
                            placeholder="Any special instructions"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Error Display */}
            {error && (
              <div className="bg-red-50 rounded-lg p-4">
                <div className="flex items-center gap-2 text-sm text-red-800">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                  <span className="font-medium">{error}</span>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => router.back()}
                disabled={isLoading}
                className="px-6 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading || destinations.length === 0}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center gap-2"
              >
                {isLoading ? (
                  <>
                    <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    Creating Trip...
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    Create Trip
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </Layout>
    </ProtectedRoute>
  )
}
