# Quick Start Guide

Deploy the Delivery Journey Tracking Telegram Bot in 5 minutes.

---

## Prerequisites

- ✅ Node.js 16+ installed
- ✅ npm or yarn installed
- ✅ Telegram account

---

## Step 1: Create Telegram Bot

1. Search for **@BotFather** in Telegram
2. Send `/newbot` command
3. Enter bot name (e.g., Delivery Tracking Assistant)
4. Enter username (must end with bot, e.g., delivery_tracking_bot)
5. **Save** the Token returned by BotFather (like: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

---

## Step 2: Download and Install Project

```bash
# Clone project (or extract downloaded code)
cd delivery-tracking-bot

# Install dependencies
npm install
```

---

## Step 3: Configure Environment Variables

```bash
# Copy configuration file
cp .env.example .env
```

Edit `.env` file and add your Bot Token:

```env
TELEGRAM_BOT_TOKEN=your_bot_token_here
NODE_ENV=development
```

Keep other configurations as default.

---

## Step 4: Initialize Database

```bash
# Create database tables
npm run init-db

# Populate test data
node src/database/seed.js
```

You should see:
```
Database initialized successfully
Mock data seeded successfully
```

---

## Step 5: Start Server

```bash
# Development mode (auto-restart)
npm run dev

# Or production mode
npm start
```

Success message:
```
Server running on port 3000
Environment: development
Telegram bot initialized
```

---

## Step 6: Test Bot

1. Find your bot in Telegram
2. Send `/start` command
3. You should see welcome message and function menu

**Test Flow:**
```
1. Click "📋 My Journeys Today" → View journey list
2. Click "🚀 Start Journey" → Share location
3. Click "📍 Reached Destination" → Mark as reached
4. Click "✅ Complete Destination" → Complete delivery
```

---

## Step 7: Test API (Optional)

### Windows (PowerShell):
```powershell
.\test-api.ps1
```

### Linux/Mac:
```bash
chmod +x test-api.sh
./test-api.sh
```

Or use curl:
```bash
# Test health check
curl http://localhost:3000/

# Get driver journeys
curl http://localhost:3000/api/drivers/1/journeys
```

---

## Frequently Asked Questions

### Q1: Bot not responding?

**Checklist:**
- [ ] Is server running?
- [ ] Is Bot Token correct?
- [ ] Did you send `/start` command?

**Check logs:**
```bash
# Server logs will show received messages
```

### Q2: Database error?

**Solution:**
```bash
# Delete old database and reinitialize
rm data.db
npm run init-db
node src/database/seed.js
```

### Q3: Port already in use?

**Modify port:**
Edit `.env` file:
```env
PORT=3001
```

---

## Next Steps

### 📚 Learn More

- [README.md](README.md) - Complete documentation
- [API.md](API.md) - API reference
- [DEPLOYMENT.md](DEPLOYMENT.md) - Deployment guide
- [ARCHITECTURE.md](ARCHITECTURE.md) - Architecture description
- [WORKFLOW.md](WORKFLOW.md) - Flow diagrams

### 🚀 Deploy to Production

See [DEPLOYMENT.md](DEPLOYMENT.md) for deployment to:
- Render (Recommended)
- Vercel
- Heroku

### 🔧 Custom Development

**Modify bot messages:**
Edit `src/bot/handlers.js`

**Add new API endpoints:**
Edit `src/api/routes.js`

**Modify database structure:**
Edit `src/database/init.js`

---

## Project Structure

```
delivery-tracking-bot/
├── src/
│   ├── bot/              # Telegram bot
│   │   ├── index.js      # Bot initialization
│   │   └── handlers.js   # Message handling
│   ├── api/              # REST API
│   │   └── routes.js     # API routes
│   ├── database/         # Database
│   │   ├── db.js         # Database connection
│   │   ├── init.js       # Initialization script
│   │   └── seed.js       # Test data
│   ├── config/           # Configuration
│   │   └── index.js      # Config management
│   └── index.js          # Application entry
├── .env                  # Environment variables (create this)
├── .env.example          # Environment variables example
├── package.json          # Dependencies configuration
└── README.md             # Project documentation
```

---

## Test Data Description

The system includes the following test data:

**Driver Information:**
- Telegram ID: `123456789` (needs to be changed to your actual Telegram ID)
- Name: Driver Zhang

**Today's Journeys:**
- Journey 1: 3 delivery destinations
  - Beijing Chaoyang Distribution Center
  - Mr. Wang's Home
  - Ms. Li's Company
- Journey 2: 2 delivery destinations
  - Shanghai Pudong Warehouse
  - Mr. Chen's Office

### Modify Test Data

Edit `src/database/seed.js` and change `telegram_id` to your Telegram ID:

```javascript
// Get your Telegram ID:
// 1. Search @userinfobot in Telegram
// 2. Send any message
// 3. Bot will return your ID

const driver = db.prepare(`
  INSERT OR IGNORE INTO drivers (telegram_id, name, phone)
  VALUES (?, ?, ?)
`).run('your_telegram_id', 'Driver Zhang', '+86 138 0000 0000');
```

Then re-run:
```bash
rm data.db
npm run init-db
node src/database/seed.js
```

---

## Command Cheat Sheet

```bash
# Install dependencies
npm install

# Initialize database
npm run init-db

# Populate test data
node src/database/seed.js

# Start development server
npm run dev

# Start production server
npm start

# Test API
.\test-api.ps1          # Windows
./test-api.sh           # Linux/Mac

# Reset database
rm data.db && npm run init-db && node src/database/seed.js
```

---

## Get Help

Having issues?

1. Check [README.md](README.md) complete documentation
2. Check server log output
3. Confirm environment variables are configured correctly
4. Verify Bot Token is valid

---

## Success Indicators

✅ Server starts without errors  
✅ Bot responds to `/start` command  
✅ Can view today's journeys  
✅ Can start journey and share location  
✅ Can update delivery status  
✅ All API tests pass  

**Congratulations! You have successfully deployed the delivery tracking bot!** 🎉

---

## Next Actions

- [ ] Modify test data to real data
- [ ] Customize bot message text
- [ ] Deploy to production environment
- [ ] Integrate with real backend API
- [ ] Add more features

Let's get started! 🚀
