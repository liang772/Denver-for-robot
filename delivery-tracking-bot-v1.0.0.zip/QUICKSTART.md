# 快速开始指南

5 分钟快速部署配送行程追踪 Telegram 机器人。

---

## 前置要求

- ✅ Node.js 16+ 已安装
- ✅ npm 或 yarn 已安装
- ✅ 有 Telegram 账号

---

## 步骤 1: 创建 Telegram Bot

1. 在 Telegram 中搜索 **@BotFather**
2. 发送 `/newbot` 命令
3. 按提示输入机器人名称（例如：配送追踪助手）
4. 输入用户名（必须以 bot 结尾，例如：delivery_tracking_bot）
5. **保存** BotFather 返回的 Token（类似：`1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`）

---

## 步骤 2: 下载并安装项目

```bash
# 克隆项目（或解压下载的代码）
cd delivery-tracking-bot

# 安装依赖
npm install
```

---

## 步骤 3: 配置环境变量

```bash
# 复制配置文件
cp .env.example .env
```

编辑 `.env` 文件，填入你的 Bot Token：

```env
TELEGRAM_BOT_TOKEN=你的Bot Token
NODE_ENV=development
```

其他配置保持默认即可。

---

## 步骤 4: 初始化数据库

```bash
# 创建数据库表
npm run init-db

# 填充测试数据
node src/database/seed.js
```

你应该看到：
```
Database initialized successfully
Mock data seeded successfully
```

---

## 步骤 5: 启动服务器

```bash
# 开发模式（自动重启）
npm run dev

# 或生产模式
npm start
```

看到以下输出表示成功：
```
Server running on port 3000
Environment: development
Telegram bot initialized
```

---

## 步骤 6: 测试机器人

1. 在 Telegram 中找到你的机器人
2. 发送 `/start` 命令
3. 你应该看到欢迎消息和功能菜单

**测试流程：**
```
1. 点击 "📋 今日我的行程" → 查看行程列表
2. 点击 "🚀 启动行程" → 分享位置
3. 点击 "📍 到达目的地" → 标记到达
4. 点击 "✅ 完成目的地配送" → 完成配送
```

---

## 步骤 7: 测试 API（可选）

### Windows (PowerShell):
```powershell
.\test-api.ps1
```

### Linux/Mac:
```bash
chmod +x test-api.sh
./test-api.sh
```

或使用 curl：
```bash
# 测试健康检查
curl http://localhost:3000/

# 获取司机行程
curl http://localhost:3000/api/drivers/1/journeys
```

---

## 常见问题

### Q1: 机器人无响应？

**检查清单：**
- [ ] 服务器是否正在运行？
- [ ] Bot Token 是否正确？
- [ ] 是否发送了 `/start` 命令？

**查看日志：**
```bash
# 服务器日志会显示收到的消息
```

### Q2: 数据库错误？

**解决方案：**
```bash
# 删除旧数据库并重新初始化
rm data.db
npm run init-db
node src/database/seed.js
```

### Q3: 端口被占用？

**修改端口：**
编辑 `.env` 文件：
```env
PORT=3001
```

---

## 下一步

### 📚 深入了解

- [README.md](README.md) - 完整文档
- [API.md](API.md) - API 参考
- [DEPLOYMENT.md](DEPLOYMENT.md) - 部署指南
- [ARCHITECTURE.md](ARCHITECTURE.md) - 架构说明
- [WORKFLOW.md](WORKFLOW.md) - 流程图

### 🚀 部署到生产环境

查看 [DEPLOYMENT.md](DEPLOYMENT.md) 了解如何部署到：
- Render（推荐）
- Vercel
- Heroku

### 🔧 自定义开发

**修改机器人消息：**
编辑 `src/bot/handlers.js`

**添加新 API 端点：**
编辑 `src/api/routes.js`

**修改数据库结构：**
编辑 `src/database/init.js`

---

## 项目结构

```
delivery-tracking-bot/
├── src/
│   ├── bot/              # Telegram 机器人
│   │   ├── index.js      # Bot 初始化
│   │   └── handlers.js   # 消息处理
│   ├── api/              # REST API
│   │   └── routes.js     # API 路由
│   ├── database/         # 数据库
│   │   ├── db.js         # 数据库连接
│   │   ├── init.js       # 初始化脚本
│   │   └── seed.js       # 测试数据
│   ├── config/           # 配置
│   │   └── index.js      # 配置管理
│   └── index.js          # 应用入口
├── .env                  # 环境变量（需创建）
├── .env.example          # 环境变量示例
├── package.json          # 依赖配置
└── README.md             # 项目文档
```

---

## 测试数据说明

系统预置了以下测试数据：

**司机信息：**
- Telegram ID: `123456789`（需要修改为你的实际 Telegram ID）
- 姓名：张师傅

**今日行程：**
- 行程 1：3 个配送站点
  - 北京市朝阳区配送中心
  - 王先生家
  - 李女士公司
- 行程 2：2 个配送站点
  - 上海市浦东新区仓库
  - 陈先生办公室

### 修改测试数据

编辑 `src/database/seed.js`，将 `telegram_id` 改为你的 Telegram ID：

```javascript
// 获取你的 Telegram ID：
// 1. 在 Telegram 搜索 @userinfobot
// 2. 发送任意消息
// 3. 机器人会返回你的 ID

const driver = db.prepare(`
  INSERT OR IGNORE INTO drivers (telegram_id, name, phone)
  VALUES (?, ?, ?)
`).run('你的Telegram ID', '张师傅', '+86 138 0000 0000');
```

然后重新运行：
```bash
rm data.db
npm run init-db
node src/database/seed.js
```

---

## 命令速查表

```bash
# 安装依赖
npm install

# 初始化数据库
npm run init-db

# 填充测试数据
node src/database/seed.js

# 启动开发服务器
npm run dev

# 启动生产服务器
npm start

# 测试 API
.\test-api.ps1          # Windows
./test-api.sh           # Linux/Mac

# 重置数据库
rm data.db && npm run init-db && node src/database/seed.js
```

---

## 获取帮助

遇到问题？

1. 查看 [README.md](README.md) 完整文档
2. 检查服务器日志输出
3. 确认环境变量配置正确
4. 验证 Bot Token 有效

---

## 成功标志

✅ 服务器启动无错误  
✅ 机器人响应 `/start` 命令  
✅ 可以查看今日行程  
✅ 可以启动行程并分享位置  
✅ 可以更新配送状态  
✅ API 测试全部通过  

**恭喜！你已成功部署配送行程追踪机器人！** 🎉

---

## 下一步行动

- [ ] 修改测试数据为真实数据
- [ ] 自定义机器人消息文本
- [ ] 部署到生产环境
- [ ] 集成真实后端 API
- [ ] 添加更多功能

开始使用吧！ 🚀
