# 部署指南

本文档提供配送行程追踪 Telegram 机器人的详细部署说明。

---

## 前置要求

- Node.js 16+ 
- npm 或 yarn
- Telegram Bot Token（从 @BotFather 获取）
- 部署平台账号（Vercel / Render / Heroku 任选其一）

---

## 本地开发环境设置

### 1. 克隆项目

```bash
git clone <repository-url>
cd delivery-tracking-bot
```

### 2. 安装依赖

```bash
npm install
```

### 3. 创建 Telegram Bot

1. 在 Telegram 中找到 @BotFather
2. 发送 `/newbot` 命令
3. 按提示设置机器人名称和用户名
4. 保存获得的 Bot Token

### 4. 配置环境变量

复制示例配置文件：
```bash
cp .env.example .env
```

编辑 `.env` 文件：
```env
# Telegram Bot Token（必填）
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# Webhook URL（生产环境必填，开发环境可留空）
WEBHOOK_URL=

# API 配置
PORT=3000
API_BASE_URL=http://localhost:3000

# 网页应用 URL（用于生成深度链接）
WEB_APP_URL=https://your-webapp-domain.com

# 环境（development 或 production）
NODE_ENV=development
```

### 5. 初始化数据库

```bash
# 创建数据库表
npm run init-db

# 填充模拟数据
node src/database/seed.js
```

### 6. 启动开发服务器

```bash
npm run dev
```

服务器将在 `http://localhost:3000` 启动，机器人使用 polling 模式。

### 7. 测试机器人

在 Telegram 中找到你的机器人，发送 `/start` 命令测试。

---

## 生产环境部署

### 选项 1: Vercel 部署

Vercel 适合快速部署，但需要注意 SQLite 在 serverless 环境的限制。

#### 步骤：

1. **安装 Vercel CLI**
```bash
npm i -g vercel
```

2. **创建 `vercel.json` 配置**
```json
{
  "version": 2,
  "builds": [
    {
      "src": "src/index.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "src/index.js"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
```

3. **部署**
```bash
vercel
```

4. **配置环境变量**

在 Vercel Dashboard 中设置：
- `TELEGRAM_BOT_TOKEN`
- `WEBHOOK_URL`（使用 Vercel 提供的域名）
- `WEB_APP_URL`
- `NODE_ENV=production`

5. **设置 Webhook**

部署完成后，访问：
```
https://your-app.vercel.app/bot<YOUR_BOT_TOKEN>
```

**注意：** Vercel 的 serverless 环境不支持持久化 SQLite，建议使用外部数据库（如 PostgreSQL）或切换到其他平台。

---

### 选项 2: Render 部署（推荐）

Render 提供持久化存储，适合使用 SQLite。

#### 步骤：

1. **准备代码**

确保项目已推送到 GitHub/GitLab。

2. **创建 Web Service**

- 登录 [Render Dashboard](https://dashboard.render.com/)
- 点击 "New +" → "Web Service"
- 连接 GitHub 仓库
- 选择项目

3. **配置服务**

| 配置项 | 值 |
|--------|-----|
| Name | delivery-tracking-bot |
| Environment | Node |
| Build Command | `npm install` |
| Start Command | `npm start` |
| Plan | Free 或 Starter |

4. **添加环境变量**

在 "Environment" 标签页添加：
```
TELEGRAM_BOT_TOKEN=your_token_here
WEBHOOK_URL=https://your-app.onrender.com
PORT=3000
API_BASE_URL=https://your-app.onrender.com
WEB_APP_URL=https://your-webapp-domain.com
NODE_ENV=production
```

5. **部署**

点击 "Create Web Service"，Render 将自动构建和部署。

6. **初始化数据库**

部署完成后，在 Render Shell 中运行：
```bash
npm run init-db
node src/database/seed.js
```

7. **验证**

访问 `https://your-app.onrender.com` 应该看到：
```json
{
  "status": "ok",
  "message": "Delivery Tracking Bot API",
  "version": "1.0.0"
}
```

---

### 选项 3: Heroku 部署

#### 步骤：

1. **安装 Heroku CLI**
```bash
npm install -g heroku
```

2. **登录 Heroku**
```bash
heroku login
```

3. **创建应用**
```bash
heroku create delivery-tracking-bot
```

4. **添加 Procfile**

创建 `Procfile` 文件：
```
web: node src/index.js
```

5. **设置环境变量**
```bash
heroku config:set TELEGRAM_BOT_TOKEN=your_token_here
heroku config:set WEBHOOK_URL=https://your-app.herokuapp.com
heroku config:set WEB_APP_URL=https://your-webapp-domain.com
heroku config:set NODE_ENV=production
```

6. **部署**
```bash
git push heroku main
```

7. **初始化数据库**
```bash
heroku run npm run init-db
heroku run node src/database/seed.js
```

8. **查看日志**
```bash
heroku logs --tail
```

---

## Webhook 配置

生产环境必须使用 Webhook 模式（polling 模式不适合生产）。

### 自动设置（推荐）

代码中已自动配置 Webhook，部署后会自动生效。

### 手动设置

如需手动设置，使用以下 API：

```bash
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://your-domain.com/bot<YOUR_BOT_TOKEN>"}'
```

### 验证 Webhook

```bash
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo"
```

响应示例：
```json
{
  "ok": true,
  "result": {
    "url": "https://your-domain.com/bot123456789:ABC...",
    "has_custom_certificate": false,
    "pending_update_count": 0
  }
}
```

---

## 数据库管理

### SQLite（当前方案）

**优点：**
- 轻量级，无需额外服务
- 适合小规模应用

**缺点：**
- 不支持 serverless 环境（Vercel）
- 并发性能有限

### 迁移到 PostgreSQL（可选）

对于生产环境，建议使用 PostgreSQL：

1. **安装依赖**
```bash
npm install pg
```

2. **修改数据库连接**

替换 `src/database/db.js`：
```javascript
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

module.exports = pool;
```

3. **更新查询语法**

将 SQLite 语法改为 PostgreSQL 语法。

---

## 监控与日志

### 查看日志

**Render:**
```bash
# 在 Dashboard 的 "Logs" 标签页查看
```

**Heroku:**
```bash
heroku logs --tail
```

**本地:**
```bash
npm run dev
```

### 健康检查

访问根路径检查服务状态：
```bash
curl https://your-domain.com/
```

预期响应：
```json
{
  "status": "ok",
  "message": "Delivery Tracking Bot API",
  "version": "1.0.0"
}
```

---

## 故障排查

### 问题 1: 机器人无响应

**检查项：**
1. Webhook 是否正确设置
```bash
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

2. 服务器是否运行
```bash
curl https://your-domain.com/
```

3. 查看日志是否有错误

### 问题 2: 数据库错误

**解决方案：**
1. 确认数据库已初始化
```bash
npm run init-db
```

2. 检查文件权限（SQLite）
```bash
ls -la data.db
```

### 问题 3: 环境变量未生效

**解决方案：**
1. 确认 `.env` 文件存在（本地）
2. 确认平台环境变量已设置（生产）
3. 重启服务

---

## 安全建议

1. **保护 Bot Token**
   - 不要提交到 Git
   - 使用环境变量
   - 定期轮换

2. **HTTPS**
   - Webhook 必须使用 HTTPS
   - 使用可信 SSL 证书

3. **访问控制**
   - 验证 Telegram 用户 ID
   - 实现司机认证机制

4. **数据备份**
   - 定期备份 SQLite 数据库
   - 使用云存储保存备份

---

## 性能优化

1. **数据库索引**
```sql
CREATE INDEX idx_journeys_driver_date ON journeys(driver_id, date);
CREATE INDEX idx_trips_journey ON trips(journey_id);
```

2. **缓存**
   - 使用 Redis 缓存频繁查询
   - 缓存司机信息

3. **限流**
   - 实现 API 请求限流
   - 防止滥用

---

## 扩展部署

### Docker 部署

创建 `Dockerfile`：
```dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

RUN npm run init-db

EXPOSE 3000

CMD ["npm", "start"]
```

构建和运行：
```bash
docker build -t delivery-bot .
docker run -p 3000:3000 --env-file .env delivery-bot
```

### Kubernetes 部署

创建 `k8s-deployment.yaml`：
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: delivery-bot
spec:
  replicas: 2
  selector:
    matchLabels:
      app: delivery-bot
  template:
    metadata:
      labels:
        app: delivery-bot
    spec:
      containers:
      - name: delivery-bot
        image: your-registry/delivery-bot:latest
        ports:
        - containerPort: 3000
        env:
        - name: TELEGRAM_BOT_TOKEN
          valueFrom:
            secretKeyRef:
              name: bot-secrets
              key: token
```

---

## 维护清单

### 日常维护
- [ ] 检查日志错误
- [ ] 监控 API 响应时间
- [ ] 验证 Webhook 状态

### 每周维护
- [ ] 备份数据库
- [ ] 检查磁盘空间
- [ ] 更新依赖包

### 每月维护
- [ ] 审查安全日志
- [ ] 性能优化
- [ ] 更新文档

---

## 支持

如遇到部署问题，请检查：
1. 项目 README.md
2. API 文档（API.md）
3. GitHub Issues

---

## 附录

### 有用的命令

```bash
# 查看 Node 版本
node --version

# 清理 node_modules
rm -rf node_modules && npm install

# 重置数据库
rm data.db && npm run init-db && node src/database/seed.js

# 测试 API
curl http://localhost:3000/api/drivers/1/journeys
```

### 环境变量完整列表

| 变量名 | 必填 | 默认值 | 描述 |
|--------|------|--------|------|
| TELEGRAM_BOT_TOKEN | 是 | - | Telegram Bot Token |
| WEBHOOK_URL | 生产必填 | - | Webhook URL |
| PORT | 否 | 3000 | 服务器端口 |
| API_BASE_URL | 否 | http://localhost:3000 | API 基础 URL |
| WEB_APP_URL | 否 | - | 网页应用 URL |
| NODE_ENV | 否 | development | 运行环境 |

---

**部署完成后，记得测试所有功能！** 🚀
