# Deployment Guide

This document provides detailed deployment instructions for the Delivery Journey Tracking Telegram Bot.

---

## Prerequisites

- Node.js 16+ 
- npm or yarn
- Telegram Bot Token (from @BotFather)
- Deployment platform account (Vercel / Render / Heroku - choose one)

---

## Local Development Environment Setup

### 1. Clone Project

```bash
git clone <repository-url>
cd delivery-tracking-bot
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Create Telegram Bot

1. Find @BotFather in Telegram
2. Send `/newbot` command
3. Follow prompts to set bot name and username
4. Save the Bot Token you receive

### 4. Configure Environment Variables

Copy example configuration file:
```bash
cp .env.example .env
```

Edit `.env` file:
```env
# Telegram Bot Token (required)
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz

# Webhook URL (required for production, optional for development)
WEBHOOK_URL=

# API Configuration
PORT=3000
API_BASE_URL=http://localhost:3000

# Web App URL (for generating deep links)
WEB_APP_URL=https://your-webapp-domain.com

# Environment (development or production)
NODE_ENV=development
```

### 5. Initialize Database

```bash
# Create database tables
npm run init-db

# Populate mock data
node src/database/seed.js
```

### 6. Start Development Server

```bash
npm run dev
```

Server will start at `http://localhost:3000`, bot uses polling mode.

### 7. Test Bot

Find your bot in Telegram and send `/start` command to test.

---

## Production Deployment

### Option 1: Vercel Deployment

Vercel is suitable for quick deployment, but note SQLite limitations in serverless environments.

#### Steps:

1. **Install Vercel CLI**
```bash
npm i -g vercel
```

2. **Create `vercel.json` Configuration**
```json
{
  "version": 2,
  "builds": [
    {
      "src": "src/index.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "src/index.js"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
```

3. **Deploy**
```bash
vercel
```

4. **Configure Environment Variables**

Set in Vercel Dashboard:
- `TELEGRAM_BOT_TOKEN`
- `WEBHOOK_URL` (use Vercel provided domain)
- `WEB_APP_URL`
- `NODE_ENV=production`

5. **Set Webhook**

After deployment, visit:
```
https://your-app.vercel.app/bot<YOUR_BOT_TOKEN>
```

**Note:** Vercel's serverless environment doesn't support persistent SQLite. For production, recommend using external database (like PostgreSQL) or switch to another platform.

---

### Option 2: Render Deployment (Recommended)

Render provides persistent storage, suitable for SQLite.

#### Steps:

1. **Prepare Code**

Ensure project is pushed to GitHub/GitLab.

2. **Create Web Service**

- Login to [Render Dashboard](https://dashboard.render.com/)
- Click "New +" → "Web Service"
- Connect GitHub repository
- Select project

3. **Configure Service**

| Configuration | Value |
|---------------|-------|
| Name | delivery-tracking-bot |
| Environment | Node |
| Build Command | `npm install` |
| Start Command | `npm start` |
| Plan | Free or Starter |

4. **Add Environment Variables**

Add in "Environment" tab:
```
TELEGRAM_BOT_TOKEN=your_token_here
WEBHOOK_URL=https://your-app.onrender.com
PORT=3000
API_BASE_URL=https://your-app.onrender.com
WEB_APP_URL=https://your-webapp-domain.com
NODE_ENV=production
```

5. **Deploy**

Click "Create Web Service", Render will automatically build and deploy.

6. **Initialize Database**

After deployment, run in Render Shell:
```bash
npm run init-db
node src/database/seed.js
```

7. **Verify**

Visit `https://your-app.onrender.com` should see:
```json
{
  "status": "ok",
  "message": "Delivery Tracking Bot API",
  "version": "1.0.0"
}
```

---

### Option 3: Heroku Deployment

#### Steps:

1. **Install Heroku CLI**
```bash
npm install -g heroku
```

2. **Login to Heroku**
```bash
heroku login
```

3. **Create App**
```bash
heroku create delivery-tracking-bot
```

4. **Add Procfile**

Create `Procfile` file:
```
web: node src/index.js
```

5. **Set Environment Variables**
```bash
heroku config:set TELEGRAM_BOT_TOKEN=your_token_here
heroku config:set WEBHOOK_URL=https://your-app.herokuapp.com
heroku config:set WEB_APP_URL=https://your-webapp-domain.com
heroku config:set NODE_ENV=production
```

6. **Deploy**
```bash
git push heroku main
```

7. **Initialize Database**
```bash
heroku run npm run init-db
heroku run node src/database/seed.js
```

8. **View Logs**
```bash
heroku logs --tail
```

---

## Webhook Configuration

Production environment must use Webhook mode (polling mode not suitable for production).

### Automatic Setup (Recommended)

Webhook is automatically configured in code and will take effect after deployment.

### Manual Setup

If manual setup needed, use this API:

```bash
curl -X POST "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook" \
  -H "Content-Type: application/json" \
  -d '{"url": "https://your-domain.com/bot<YOUR_BOT_TOKEN>"}'
```

### Verify Webhook

```bash
curl "https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getWebhookInfo"
```

Response example:
```json
{
  "ok": true,
  "result": {
    "url": "https://your-domain.com/bot123456789:ABC...",
    "has_custom_certificate": false,
    "pending_update_count": 0
  }
}
```

---

## Database Management

### SQLite (Current Solution)

**Pros:**
- Lightweight, no additional services needed
- Suitable for small-scale applications

**Cons:**
- Not supported in serverless environments (Vercel)
- Limited concurrency performance

### Migrate to PostgreSQL (Optional)

For production environments, recommend using PostgreSQL:

1. **Install Dependencies**
```bash
npm install pg
```

2. **Modify Database Connection**

Replace `src/database/db.js`:
```javascript
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

module.exports = pool;
```

3. **Update Query Syntax**

Change SQLite syntax to PostgreSQL syntax.

---

## Monitoring and Logging

### View Logs

**Render:**
```bash
# View in Dashboard "Logs" tab
```

**Heroku:**
```bash
heroku logs --tail
```

**Local:**
```bash
npm run dev
```

### Health Check

Visit root path to check service status:
```bash
curl https://your-domain.com/
```

Expected response:
```json
{
  "status": "ok",
  "message": "Delivery Tracking Bot API",
  "version": "1.0.0"
}
```

---

## Troubleshooting

### Issue 1: Bot Not Responding

**Checklist:**
1. Is Webhook correctly set?
```bash
curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
```

2. Is server running?
```bash
curl https://your-domain.com/
```

3. Check logs for errors

### Issue 2: Database Error

**Solution:**
1. Confirm database is initialized
```bash
npm run init-db
```

2. Check file permissions (SQLite)
```bash
ls -la data.db
```

### Issue 3: Environment Variables Not Working

**Solution:**
1. Confirm `.env` file exists (local)
2. Confirm platform environment variables are set (production)
3. Restart service

---

## Security Recommendations

1. **Protect Bot Token**
   - Don't commit to Git
   - Use environment variables
   - Rotate regularly

2. **HTTPS**
   - Webhook must use HTTPS
   - Use trusted SSL certificate

3. **Access Control**
   - Verify Telegram user ID
   - Implement driver authentication

4. **Data Backup**
   - Regularly backup SQLite database
   - Use cloud storage for backups

---

## Performance Optimization

1. **Database Indexes**
```sql
CREATE INDEX idx_journeys_driver_date ON journeys(driver_id, date);
CREATE INDEX idx_trips_journey ON trips(journey_id);
```

2. **Caching**
   - Use Redis to cache frequent queries
   - Cache driver information

3. **Rate Limiting**
   - Implement API request rate limiting
   - Prevent abuse

---

## Scaling Deployment

### Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM node:16-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

RUN npm run init-db

EXPOSE 3000

CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t delivery-bot .
docker run -p 3000:3000 --env-file .env delivery-bot
```

### Kubernetes Deployment

Create `k8s-deployment.yaml`:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: delivery-bot
spec:
  replicas: 2
  selector:
    matchLabels:
      app: delivery-bot
  template:
    metadata:
      labels:
        app: delivery-bot
    spec:
      containers:
      - name: delivery-bot
        image: your-registry/delivery-bot:latest
        ports:
        - containerPort: 3000
        env:
        - name: TELEGRAM_BOT_TOKEN
          valueFrom:
            secretKeyRef:
              name: bot-secrets
              key: token
```

---

## Maintenance Checklist

### Daily Maintenance
- [ ] Check log errors
- [ ] Monitor API response time
- [ ] Verify Webhook status

### Weekly Maintenance
- [ ] Backup database
- [ ] Check disk space
- [ ] Update dependencies

### Monthly Maintenance
- [ ] Review security logs
- [ ] Performance optimization
- [ ] Update documentation

---

## Support

For deployment issues, please check:
1. Project README.md
2. API documentation (API.md)
3. GitHub Issues

---

## Appendix

### Useful Commands

```bash
# Check Node version
node --version

# Clean node_modules
rm -rf node_modules && npm install

# Reset database
rm data.db && npm run init-db && node src/database/seed.js

# Test API
curl http://localhost:3000/api/drivers/1/journeys
```

### Complete Environment Variables List

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| TELEGRAM_BOT_TOKEN | Yes | - | Telegram Bot Token |
| WEBHOOK_URL | Production Yes | - | Webhook URL |
| PORT | No | 3000 | Server port |
| API_BASE_URL | No | http://localhost:3000 | API base URL |
| WEB_APP_URL | No | - | Web app URL |
| NODE_ENV | No | development | Runtime environment |

---

**After deployment, remember to test all features!** 🚀
