# System Architecture Documentation

## System Overview

The Delivery Journey Tracking Telegram Bot is a lightweight delivery management system that provides real-time journey tracking and status update features for drivers.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                         Driver Side                          │
│                    (Telegram Client)                         │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ HTTPS
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   Telegram Bot API                          │
│              (api.telegram.org)                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ Webhook / Polling
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    Application Server                        │
│                  (Node.js + Express)                        │
│                                                             │
│  ┌──────────────────┐         ┌──────────────────┐        │
│  │   Bot Handler    │◄────────┤   API Routes     │        │
│  │  (Message Layer) │         │   (REST API)     │        │
│  └────────┬─────────┘         └────────┬─────────┘        │
│           │                             │                  │
│           │                             │                  │
│           ▼                             ▼                  │
│  ┌─────────────────────────────────────────────┐          │
│  │          Database Layer (SQLite)            │          │
│  │  - drivers                                  │          │
│  │  - journeys                                 │          │
│  │  - trips                                    │          │
│  │  - location_updates                         │          │
│  └─────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────┘
                         │
                         │ Deep Link
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   Web Application (Not Implemented)          │
│              Journey Details View Interface                  │
└─────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. Telegram Bot Handler

**Location:** `src/bot/`

**Responsibilities:**
- Receive and process Telegram messages
- Manage user interaction flow
- Call API layer to get/update data
- Format response messages

**Main Modules:**
- `index.js` - Bot initialization and routing
- `handlers.js` - Message handlers

**Interaction Flow:**
```
User Message → Bot Handler → Database Query → Format Response → Send Message
```

---

### 2. API Layer

**Location:** `src/api/`

**Responsibilities:**
- Provide RESTful API interfaces
- Handle data validation
- Execute business logic
- Return standardized responses

**Endpoint Categories:**
- Journey management (journeys)
- Delivery task management (trips)
- Location tracking (location-update)
- Driver information (drivers)

---

### 3. Database Layer

**Location:** `src/database/`

**Responsibilities:**
- Data persistence
- Data model definition
- Query optimization

**Database Choice:**
- **Current:** SQLite (lightweight, suitable for prototypes and small-scale deployment)
- **Recommended for Production:** PostgreSQL (supports concurrency, suitable for scaling)

---

### 4. Configuration

**Location:** `src/config/`

**Responsibilities:**
- Environment variable management
- Configuration centralization
- Different environment configuration switching

---

## Data Flow

### Scenario 1: View Today's Journeys

```
1. Driver clicks "My Journeys Today"
   ↓
2. Bot Handler receives message
   ↓
3. Query database for journey list
   SELECT * FROM journeys WHERE driver_id = ? AND date = ?
   ↓
4. Format journey information
   ↓
5. Send message to driver
```

### Scenario 2: Start Journey

```
1. Driver clicks "Start Journey"
   ↓
2. Bot requests real-time location
   ↓
3. Driver shares location
   ↓
4. Bot Handler receives location data
   ↓
5. Update journey status to 'active'
   UPDATE journeys SET status = 'active', started_at = ?
   ↓
6. Save location record
   INSERT INTO location_updates (journey_id, latitude, longitude, timestamp)
   ↓
7. Query next delivery destination
   SELECT * FROM trips WHERE journey_id = ? AND status = 'pending' ORDER BY sequence
   ↓
8. Send next destination information
```

### Scenario 3: Complete Delivery

```
1. Driver clicks "Complete Destination"
   ↓
2. Bot Handler queries current destination
   SELECT * FROM trips WHERE journey_id = ? AND status = 'reached'
   ↓
3. Update destination status to 'completed'
   UPDATE trips SET status = 'completed', completed_at = ?
   ↓
4. Query next destination
   SELECT * FROM trips WHERE journey_id = ? AND sequence > ? ORDER BY sequence
   ↓
5. Calculate and update ETA (mock)
   UPDATE trips SET eta = ?
   ↓
6. Send next destination information or completion prompt
```

---

## Database Design

### ER Diagram

```
┌─────────────┐
│   drivers   │
├─────────────┤
│ id (PK)     │
│ telegram_id │◄────┐
│ name        │     │
│ phone       │     │
└─────────────┘     │ 1:N
                    │
┌─────────────┐     │
│  journeys   │     │
├─────────────┤     │
│ id (PK)     │     │
│ driver_id   │─────┘
│ date        │
│ status      │◄────┐
│ started_at  │     │
│ completed_at│     │
└─────────────┘     │ 1:N
                    │
┌─────────────┐     │
│    trips    │     │
├─────────────┤     │
│ id (PK)     │     │
│ journey_id  │─────┘
│ sequence    │
│ destination │
│ status      │
│ eta         │
└─────────────┘

┌──────────────────┐
│ location_updates │
├──────────────────┤
│ id (PK)          │
│ journey_id (FK)  │─────┐
│ latitude         │     │
│ longitude        │     │ N:1
│ timestamp        │     │
└──────────────────┘     │
                         │
                    ┌────▼──────┐
                    │ journeys  │
                    └───────────┘
```

### Table Structure

#### drivers
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | INTEGER | PK, AUTO_INCREMENT | Driver ID |
| telegram_id | TEXT | UNIQUE, NOT NULL | Telegram User ID |
| name | TEXT | NOT NULL | Driver Name |
| phone | TEXT | | Contact Phone |

#### journeys
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | TEXT | PK | Journey ID (UUID) |
| driver_id | INTEGER | FK, NOT NULL | Driver ID |
| date | TEXT | NOT NULL | Date (YYYY-MM-DD) |
| status | TEXT | DEFAULT 'pending' | Status |
| started_at | TEXT | | Start Time |
| completed_at | TEXT | | Completion Time |

#### trips
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | TEXT | PK | Delivery Task ID (UUID) |
| journey_id | TEXT | FK, NOT NULL | Journey ID |
| sequence | INTEGER | NOT NULL | Sequence |
| destination_name | TEXT | NOT NULL | Destination Name |
| destination_address | TEXT | NOT NULL | Destination Address |
| destination_lat | REAL | | Latitude |
| destination_lng | REAL | | Longitude |
| status | TEXT | DEFAULT 'pending' | Status |
| reached_at | TEXT | | Reached Time |
| completed_at | TEXT | | Completion Time |
| eta | TEXT | | Estimated Arrival Time |

#### location_updates
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | INTEGER | PK, AUTO_INCREMENT | Record ID |
| journey_id | TEXT | FK, NOT NULL | Journey ID |
| latitude | REAL | NOT NULL | Latitude |
| longitude | REAL | NOT NULL | Longitude |
| timestamp | TEXT | NOT NULL | Timestamp |

---

## State Machines

### Journey State Transitions

```
┌─────────┐
│ pending │ (Not Started)
└────┬────┘
     │ start journey
     ▼
┌─────────┐
│ active  │ (In Progress)
└────┬────┘
     │ complete all trips
     ▼
┌───────────┐
│ completed │ (Completed)
└───────────┘
```

### Trip State Transitions

```
┌─────────┐
│ pending │ (Not Started)
└────┬────┘
     │ reach destination
     ▼
┌─────────┐
│ reached │ (Reached)
└────┬────┘
     │ complete delivery
     ▼
┌───────────┐
│ completed │ (Completed)
└───────────┘
```

---

## Deployment Architecture

### Development Environment

```
┌──────────────────┐
│  Local Machine   │
│                  │
│  Node.js Server  │
│  (Polling Mode)  │
│                  │
│  SQLite DB       │
└──────────────────┘
```

### Production Environment (Recommended)

```
┌─────────────────────────────────────────┐
│            Load Balancer                │
│         (Nginx / Cloud LB)              │
└────────────────┬────────────────────────┘
                 │
        ┌────────┴────────┐
        │                 │
┌───────▼──────┐  ┌───────▼──────┐
│  App Server  │  │  App Server  │
│   Instance 1 │  │   Instance 2 │
│              │  │              │
│  Node.js     │  │  Node.js     │
│  (Webhook)   │  │  (Webhook)   │
└───────┬──────┘  └───────┬──────┘
        │                 │
        └────────┬────────┘
                 │
        ┌────────▼────────┐
        │   PostgreSQL    │
        │   (Primary DB)  │
        └─────────────────┘
```

---

## Security Considerations

### 1. Authentication and Authorization

**Current Status:** Not implemented  
**Recommended Solution:**
- Verify Telegram user ID
- Implement driver-account binding mechanism
- API uses JWT Token authentication

### 2. Data Protection

- Encrypt sensitive information storage
- HTTPS transmission
- Regular data backups

### 3. Access Control

- Limit API access frequency
- Implement IP whitelist (optional)
- Log auditing

---

## Performance Optimization

### 1. Database Optimization

**Index Strategy:**
```sql
CREATE INDEX idx_journeys_driver_date ON journeys(driver_id, date);
CREATE INDEX idx_trips_journey_status ON trips(journey_id, status);
CREATE INDEX idx_location_journey ON location_updates(journey_id);
```

**Query Optimization:**
- Use prepared statements
- Avoid N+1 queries
- Reasonable use of JOIN

### 2. Caching Strategy

**Recommend using Redis:**
- Cache driver information (TTL: 1 hour)
- Cache active journeys (TTL: 5 minutes)
- Cache delivery trips list (TTL: 5 minutes)

### 3. Concurrency Handling

- Use connection pool
- Implement request queue
- Asynchronous processing of location updates

---

## Scalability

### Horizontal Scaling

**Support multi-instance deployment:**
1. Use Webhook mode (avoid Polling)
2. Shared database (PostgreSQL)
3. Use Redis to share session state

### Vertical Scaling

**Optimize single instance performance:**
1. Increase server resources
2. Optimize database queries
3. Use caching to reduce database pressure

---

## Monitoring and Logging

### Key Metrics

- API response time
- Database query time
- Message processing success rate
- Active user count
- Error rate

### Log Levels

```javascript
// Recommend using winston or pino
logger.error('Critical error');  // Critical errors
logger.warn('Warning message');  // Warnings
logger.info('Info message');     // Information
logger.debug('Debug message');   // Debug
```

### Recommended Monitoring Tools

- **APM:** New Relic, Datadog
- **Logging:** ELK Stack, Papertrail
- **Error Tracking:** Sentry
- **Performance Monitoring:** Prometheus + Grafana

---

## Technical Debt and Improvement Plan

### Short-term (1-2 weeks)

- [ ] Implement user authentication
- [ ] Add error handling middleware
- [ ] Improve logging system
- [ ] Add unit tests

### Mid-term (1-2 months)

- [ ] Migrate to PostgreSQL
- [ ] Implement Redis caching
- [ ] Add API rate limiting
- [ ] Implement real ETA calculation

### Long-term (3-6 months)

- [ ] Microservices architecture refactoring
- [ ] Implement message queue (RabbitMQ/Kafka)
- [ ] Multi-language support
- [ ] Admin dashboard development

---

## Dependencies

### Core Dependencies

```json
{
  "express": "^4.18.2",           // Web framework
  "node-telegram-bot-api": "^0.64.0",  // Telegram Bot SDK
  "better-sqlite3": "^9.2.2",     // SQLite driver
  "dotenv": "^16.3.1",            // Environment variable management
  "uuid": "^9.0.1"                // UUID generation
}
```

### Recommended Additions

```json
{
  "winston": "^3.11.0",           // Logging management
  "joi": "^17.11.0",              // Data validation
  "helmet": "^7.1.0",             // Security middleware
  "rate-limiter-flexible": "^3.0.0",  // Rate limiting
  "pg": "^8.11.3",                // PostgreSQL driver
  "redis": "^4.6.11"              // Redis client
}
```

---

## Summary

This system adopts a simple three-tier architecture design that is easy to understand and maintain. The current implementation meets prototype validation needs and can be gradually optimized and expanded based on business growth.

**Core Advantages:**
- Lightweight, quick deployment
- Modular design, easy to extend
- Clear API contracts, convenient for integration

**Improvement Directions:**
- Enhance security
- Improve performance and scalability
- Complete monitoring and logging
