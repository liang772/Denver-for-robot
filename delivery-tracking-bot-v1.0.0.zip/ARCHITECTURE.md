# 系统架构文档

## 系统概览

配送行程追踪 Telegram 机器人是一个轻量级的配送管理系统，为司机提供实时行程追踪和状态更新功能。

---

## 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                         司机端                               │
│                    (Telegram 客户端)                         │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ HTTPS
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   Telegram Bot API                          │
│              (api.telegram.org)                             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         │ Webhook / Polling
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    应用服务器                                │
│                  (Node.js + Express)                        │
│                                                             │
│  ┌──────────────────┐         ┌──────────────────┐        │
│  │   Bot Handler    │◄────────┤   API Routes     │        │
│  │  (消息处理层)     │         │   (REST API)     │        │
│  └────────┬─────────┘         └────────┬─────────┘        │
│           │                             │                  │
│           │                             │                  │
│           ▼                             ▼                  │
│  ┌─────────────────────────────────────────────┐          │
│  │          Database Layer (SQLite)            │          │
│  │  - drivers                                  │          │
│  │  - journeys                                 │          │
│  │  - trips                                    │          │
│  │  - location_updates                         │          │
│  └─────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────┘
                         │
                         │ Deep Link
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                   网页应用 (未实现)                          │
│              行程详情查看界面                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 核心组件

### 1. Telegram Bot Handler

**位置:** `src/bot/`

**职责:**
- 接收和处理 Telegram 消息
- 管理用户交互流程
- 调用 API 层获取/更新数据
- 格式化响应消息

**主要模块:**
- `index.js` - Bot 初始化和路由
- `handlers.js` - 消息处理器

**交互流程:**
```
用户消息 → Bot Handler → 数据库查询 → 格式化响应 → 发送消息
```

---

### 2. API Layer

**位置:** `src/api/`

**职责:**
- 提供 RESTful API 接口
- 处理数据验证
- 执行业务逻辑
- 返回标准化响应

**端点分类:**
- 行程管理（journeys）
- 配送任务管理（trips）
- 位置追踪（location-update）
- 司机信息（drivers）

---

### 3. Database Layer

**位置:** `src/database/`

**职责:**
- 数据持久化
- 数据模型定义
- 查询优化

**数据库选择:**
- **当前:** SQLite（轻量级，适合原型和小规模部署）
- **推荐生产:** PostgreSQL（支持并发，适合扩展）

---

### 4. Configuration

**位置:** `src/config/`

**职责:**
- 环境变量管理
- 配置集中化
- 不同环境配置切换

---

## 数据流

### 场景 1: 查看今日行程

```
1. 司机点击 "今日我的行程"
   ↓
2. Bot Handler 接收消息
   ↓
3. 查询数据库获取行程列表
   SELECT * FROM journeys WHERE driver_id = ? AND date = ?
   ↓
4. 格式化行程信息
   ↓
5. 发送消息给司机
```

### 场景 2: 启动行程

```
1. 司机点击 "启动行程"
   ↓
2. Bot 请求实时位置
   ↓
3. 司机分享位置
   ↓
4. Bot Handler 接收位置数据
   ↓
5. 更新行程状态为 'active'
   UPDATE journeys SET status = 'active', started_at = ?
   ↓
6. 保存位置记录
   INSERT INTO location_updates (journey_id, latitude, longitude, timestamp)
   ↓
7. 查询下一个配送站点
   SELECT * FROM trips WHERE journey_id = ? AND status = 'pending' ORDER BY sequence
   ↓
8. 发送下一站点信息
```

### 场景 3: 完成配送

```
1. 司机点击 "完成目的地配送"
   ↓
2. Bot Handler 查询当前站点
   SELECT * FROM trips WHERE journey_id = ? AND status = 'reached'
   ↓
3. 更新站点状态为 'completed'
   UPDATE trips SET status = 'completed', completed_at = ?
   ↓
4. 查询下一站点
   SELECT * FROM trips WHERE journey_id = ? AND sequence > ? ORDER BY sequence
   ↓
5. 计算并更新 ETA（模拟）
   UPDATE trips SET eta = ?
   ↓
6. 发送下一站点信息或完成提示
```

---

## 数据库设计

### ER 图

```
┌─────────────┐
│   drivers   │
├─────────────┤
│ id (PK)     │
│ telegram_id │◄────┐
│ name        │     │
│ phone       │     │
└─────────────┘     │
                    │ 1:N
                    │
┌─────────────┐     │
│  journeys   │     │
├─────────────┤     │
│ id (PK)     │     │
│ driver_id   │─────┘
│ date        │
│ status      │◄────┐
│ started_at  │     │
│ completed_at│     │
└─────────────┘     │ 1:N
                    │
┌─────────────┐     │
│    trips    │     │
├─────────────┤     │
│ id (PK)     │     │
│ journey_id  │─────┘
│ sequence    │
│ destination │
│ status      │
│ eta         │
└─────────────┘

┌──────────────────┐
│ location_updates │
├──────────────────┤
│ id (PK)          │
│ journey_id (FK)  │─────┐
│ latitude         │     │
│ longitude        │     │ N:1
│ timestamp        │     │
└──────────────────┘     │
                         │
                    ┌────▼──────┐
                    │ journeys  │
                    └───────────┘
```

### 表结构

#### drivers
| 字段 | 类型 | 约束 | 描述 |
|------|------|------|------|
| id | INTEGER | PK, AUTO_INCREMENT | 司机 ID |
| telegram_id | TEXT | UNIQUE, NOT NULL | Telegram 用户 ID |
| name | TEXT | NOT NULL | 司机姓名 |
| phone | TEXT | | 联系电话 |

#### journeys
| 字段 | 类型 | 约束 | 描述 |
|------|------|------|------|
| id | TEXT | PK | 行程 ID (UUID) |
| driver_id | INTEGER | FK, NOT NULL | 司机 ID |
| date | TEXT | NOT NULL | 日期 (YYYY-MM-DD) |
| status | TEXT | DEFAULT 'pending' | 状态 |
| started_at | TEXT | | 开始时间 |
| completed_at | TEXT | | 完成时间 |

#### trips
| 字段 | 类型 | 约束 | 描述 |
|------|------|------|------|
| id | TEXT | PK | 配送任务 ID (UUID) |
| journey_id | TEXT | FK, NOT NULL | 行程 ID |
| sequence | INTEGER | NOT NULL | 顺序 |
| destination_name | TEXT | NOT NULL | 目的地名称 |
| destination_address | TEXT | NOT NULL | 目的地地址 |
| destination_lat | REAL | | 纬度 |
| destination_lng | REAL | | 经度 |
| status | TEXT | DEFAULT 'pending' | 状态 |
| reached_at | TEXT | | 到达时间 |
| completed_at | TEXT | | 完成时间 |
| eta | TEXT | | 预计到达时间 |

#### location_updates
| 字段 | 类型 | 约束 | 描述 |
|------|------|------|------|
| id | INTEGER | PK, AUTO_INCREMENT | 记录 ID |
| journey_id | TEXT | FK, NOT NULL | 行程 ID |
| latitude | REAL | NOT NULL | 纬度 |
| longitude | REAL | NOT NULL | 经度 |
| timestamp | TEXT | NOT NULL | 时间戳 |

---

## 状态机

### Journey 状态转换

```
┌─────────┐
│ pending │ (待启动)
└────┬────┘
     │ start journey
     ▼
┌─────────┐
│ active  │ (进行中)
└────┬────┘
     │ complete all trips
     ▼
┌───────────┐
│ completed │ (已完成)
└───────────┘
```

### Trip 状态转换

```
┌─────────┐
│ pending │ (待执行)
└────┬────┘
     │ reach destination
     ▼
┌─────────┐
│ reached │ (已到达)
└────┬────┘
     │ complete delivery
     ▼
┌───────────┐
│ completed │ (已完成)
└───────────┘
```

---

## 部署架构

### 开发环境

```
┌──────────────────┐
│  本地开发机       │
│                  │
│  Node.js Server  │
│  (Polling Mode)  │
│                  │
│  SQLite DB       │
└──────────────────┘
```

### 生产环境（推荐）

```
┌─────────────────────────────────────────┐
│            Load Balancer                │
│         (Nginx / Cloud LB)              │
└────────────────┬────────────────────────┘
                 │
        ┌────────┴────────┐
        │                 │
┌───────▼──────┐  ┌───────▼──────┐
│  App Server  │  │  App Server  │
│   Instance 1 │  │   Instance 2 │
│              │  │              │
│  Node.js     │  │  Node.js     │
│  (Webhook)   │  │  (Webhook)   │
└───────┬──────┘  └───────┬──────┘
        │                 │
        └────────┬────────┘
                 │
        ┌────────▼────────┐
        │   PostgreSQL    │
        │   (Primary DB)  │
        └─────────────────┘
```

---

## 安全考虑

### 1. 认证与授权

**当前状态:** 未实现  
**推荐方案:**
- 验证 Telegram 用户 ID
- 实现司机-账号绑定机制
- API 使用 JWT Token 认证

### 2. 数据保护

- 敏感信息加密存储
- HTTPS 传输
- 定期数据备份

### 3. 访问控制

- 限制 API 访问频率
- 实现 IP 白名单（可选）
- 日志审计

---

## 性能优化

### 1. 数据库优化

**索引策略:**
```sql
CREATE INDEX idx_journeys_driver_date ON journeys(driver_id, date);
CREATE INDEX idx_trips_journey_status ON trips(journey_id, status);
CREATE INDEX idx_location_journey ON location_updates(journey_id);
```

**查询优化:**
- 使用预编译语句（prepared statements）
- 避免 N+1 查询
- 合理使用 JOIN

### 2. 缓存策略

**推荐使用 Redis:**
- 缓存司机信息（TTL: 1小时）
- 缓存活跃行程（TTL: 5分钟）
- 缓存配送任务列表（TTL: 5分钟）

### 3. 并发处理

- 使用连接池
- 实现请求队列
- 异步处理位置更新

---

## 扩展性

### 水平扩展

**支持多实例部署:**
1. 使用 Webhook 模式（避免 Polling）
2. 共享数据库（PostgreSQL）
3. 使用 Redis 共享会话状态

### 垂直扩展

**优化单实例性能:**
1. 增加服务器资源
2. 优化数据库查询
3. 使用缓存减少数据库压力

---

## 监控与日志

### 关键指标

- API 响应时间
- 数据库查询时间
- 消息处理成功率
- 活跃用户数
- 错误率

### 日志级别

```javascript
// 推荐使用 winston 或 pino
logger.error('Critical error');  // 严重错误
logger.warn('Warning message');  // 警告
logger.info('Info message');     // 信息
logger.debug('Debug message');   // 调试
```

### 监控工具推荐

- **APM:** New Relic, Datadog
- **日志:** ELK Stack, Papertrail
- **错误追踪:** Sentry
- **性能监控:** Prometheus + Grafana

---

## 技术债务与改进计划

### 短期（1-2周）

- [ ] 实现用户认证
- [ ] 添加错误处理中间件
- [ ] 完善日志系统
- [ ] 添加单元测试

### 中期（1-2月）

- [ ] 迁移到 PostgreSQL
- [ ] 实现 Redis 缓存
- [ ] 添加 API 限流
- [ ] 实现真实 ETA 计算

### 长期（3-6月）

- [ ] 微服务架构重构
- [ ] 实现消息队列（RabbitMQ/Kafka）
- [ ] 多语言支持
- [ ] 管理后台开发

---

## 依赖关系

### 核心依赖

```json
{
  "express": "^4.18.2",           // Web 框架
  "node-telegram-bot-api": "^0.64.0",  // Telegram Bot SDK
  "better-sqlite3": "^9.2.2",     // SQLite 驱动
  "dotenv": "^16.3.1",            // 环境变量管理
  "uuid": "^9.0.1"                // UUID 生成
}
```

### 推荐添加

```json
{
  "winston": "^3.11.0",           // 日志管理
  "joi": "^17.11.0",              // 数据验证
  "helmet": "^7.1.0",             // 安全中间件
  "rate-limiter-flexible": "^3.0.0",  // 限流
  "pg": "^8.11.3",                // PostgreSQL 驱动
  "redis": "^4.6.11"              // Redis 客户端
}
```

---

## 总结

本系统采用简洁的三层架构设计，易于理解和维护。当前实现满足原型验证需求，后续可根据业务增长逐步优化和扩展。

**核心优势:**
- 轻量级，快速部署
- 模块化设计，易于扩展
- 清晰的 API 契约，便于集成

**改进方向:**
- 增强安全性
- 提升性能和可扩展性
- 完善监控和日志
