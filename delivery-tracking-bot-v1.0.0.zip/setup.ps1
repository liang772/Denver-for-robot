# 项目快速设置脚本 (PowerShell)
# 自动完成项目初始化

Write-Host "================================" -ForegroundColor Cyan
Write-Host "配送行程追踪机器人 - 快速设置" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# 检查 Node.js
Write-Host "检查 Node.js..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "✓ Node.js 已安装: $nodeVersion" -ForegroundColor Green
}
catch {
    Write-Host "✗ 未找到 Node.js，请先安装 Node.js 16+" -ForegroundColor Red
    Write-Host "下载地址: https://nodejs.org/" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# 检查 npm
Write-Host "检查 npm..." -ForegroundColor Yellow
try {
    $npmVersion = npm --version
    Write-Host "✓ npm 已安装: $npmVersion" -ForegroundColor Green
}
catch {
    Write-Host "✗ 未找到 npm" -ForegroundColor Red
    exit 1
}
Write-Host ""

# 安装依赖
Write-Host "安装项目依赖..." -ForegroundColor Yellow
npm install
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ 依赖安装成功" -ForegroundColor Green
} else {
    Write-Host "✗ 依赖安装失败" -ForegroundColor Red
    exit 1
}
Write-Host ""

# 检查 .env 文件
Write-Host "检查环境变量配置..." -ForegroundColor Yellow
if (Test-Path ".env") {
    Write-Host "✓ .env 文件已存在" -ForegroundColor Green
} else {
    Write-Host "! .env 文件不存在，正在创建..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host "✓ 已创建 .env 文件" -ForegroundColor Green
    Write-Host ""
    Write-Host "⚠ 重要：请编辑 .env 文件，填入你的 Telegram Bot Token" -ForegroundColor Yellow
    Write-Host "   1. 在 Telegram 中找到 @BotFather" -ForegroundColor Cyan
    Write-Host "   2. 发送 /newbot 创建机器人" -ForegroundColor Cyan
    Write-Host "   3. 复制获得的 Token" -ForegroundColor Cyan
    Write-Host "   4. 编辑 .env 文件，填入 TELEGRAM_BOT_TOKEN" -ForegroundColor Cyan
    Write-Host ""
    
    # 询问是否现在配置
    $response = Read-Host "是否现在配置 Bot Token? (y/n)"
    if ($response -eq "y" -or $response -eq "Y") {
        $token = Read-Host "请输入你的 Telegram Bot Token"
        if ($token) {
            (Get-Content ".env") -replace 'TELEGRAM_BOT_TOKEN=.*', "TELEGRAM_BOT_TOKEN=$token" | Set-Content ".env"
            Write-Host "✓ Bot Token 已配置" -ForegroundColor Green
        }
    }
}
Write-Host ""

# 初始化数据库
Write-Host "初始化数据库..." -ForegroundColor Yellow
npm run init-db
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ 数据库初始化成功" -ForegroundColor Green
} else {
    Write-Host "✗ 数据库初始化失败" -ForegroundColor Red
    exit 1
}
Write-Host ""

# 填充测试数据
Write-Host "填充测试数据..." -ForegroundColor Yellow
node src/database/seed.js
if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ 测试数据填充成功" -ForegroundColor Green
} else {
    Write-Host "✗ 测试数据填充失败" -ForegroundColor Red
    exit 1
}
Write-Host ""

# 完成
Write-Host "================================" -ForegroundColor Cyan
Write-Host "✓ 设置完成！" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "下一步操作：" -ForegroundColor Yellow
Write-Host "1. 确保 .env 文件中的 Bot Token 已配置" -ForegroundColor Cyan
Write-Host "2. 运行 'npm run dev' 启动开发服务器" -ForegroundColor Cyan
Write-Host "3. 在 Telegram 中找到你的机器人并发送 /start" -ForegroundColor Cyan
Write-Host ""
Write-Host "查看文档：" -ForegroundColor Yellow
Write-Host "- QUICKSTART.md - 快速开始指南" -ForegroundColor Cyan
Write-Host "- README.md - 完整文档" -ForegroundColor Cyan
Write-Host "- API.md - API 参考" -ForegroundColor Cyan
Write-Host ""
Write-Host "准备好了吗？运行以下命令启动服务器：" -ForegroundColor Yellow
Write-Host "npm run dev" -ForegroundColor Green
Write-Host ""
