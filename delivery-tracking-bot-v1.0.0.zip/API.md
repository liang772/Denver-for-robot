# API 参考文档

## 概述

本文档描述配送行程追踪系统的 REST API 接口规范。当前版本使用模拟数据，后续可与真实后端系统集成。

**Base URL:** `http://localhost:3000/api`  
**Content-Type:** `application/json`  
**版本:** 1.0.0

---

## 认证

当前版本暂未实现认证机制。后续集成时建议使用：
- JWT Token
- API Key
- OAuth 2.0

---

## 端点详情

### 1. 获取司机今日行程

获取指定司机当天的所有行程列表。

**端点:** `GET /api/drivers/{driverId}/journeys`

**路径参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| driverId | integer | 是 | 司机 ID |

**请求示例:**
```http
GET /api/drivers/1/journeys
```

**响应示例 (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "driver_id": 1,
      "date": "2025-12-08",
      "status": "pending",
      "started_at": null,
      "completed_at": null,
      "total_trips": 3,
      "completed_trips": 0
    }
  ]
}
```

**字段说明:**
- `status`: 行程状态
  - `pending` - 待启动
  - `active` - 进行中
  - `completed` - 已完成
- `total_trips`: 总配送站点数
- `completed_trips`: 已完成站点数

---

### 2. 启动行程

启动指定行程并记录初始位置。

**端点:** `POST /api/journeys/{journeyId}/start`

**路径参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| journeyId | string | 是 | 行程 ID (UUID) |

**请求体:**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

**请求体参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| latitude | number | 否 | 纬度 |
| longitude | number | 否 | 经度 |

**响应示例 (200 OK):**
```json
{
  "success": true,
  "message": "行程已启动",
  "data": {
    "journeyId": "550e8400-e29b-41d4-a716-446655440000",
    "startedAt": "2025-12-08T09:00:00.000Z"
  }
}
```

---

### 3. 更新位置

持续更新司机的 GPS 位置信息。

**端点:** `POST /api/journeys/{journeyId}/location-update`

**路径参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| journeyId | string | 是 | 行程 ID (UUID) |

**请求体:**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

**请求体参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| latitude | number | 是 | 纬度 (-90 到 90) |
| longitude | number | 是 | 经度 (-180 到 180) |

**响应示例 (200 OK):**
```json
{
  "success": true,
  "message": "位置已更新",
  "data": {
    "latitude": 39.9042,
    "longitude": 116.4074,
    "timestamp": "2025-12-08T09:15:00.000Z"
  }
}
```

**错误响应 (400 Bad Request):**
```json
{
  "success": false,
  "error": "缺少位置信息"
}
```

---

### 4. 获取行程配送任务列表

获取指定行程的所有配送任务（trips）。

**端点:** `GET /api/journeys/{journeyId}/trips`

**路径参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| journeyId | string | 是 | 行程 ID (UUID) |

**请求示例:**
```http
GET /api/journeys/550e8400-e29b-41d4-a716-446655440000/trips
```

**响应示例 (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": "660e8400-e29b-41d4-a716-446655440001",
      "journey_id": "550e8400-e29b-41d4-a716-446655440000",
      "sequence": 1,
      "destination_name": "北京市朝阳区配送中心",
      "destination_address": "朝阳区建国路88号",
      "destination_lat": 39.9042,
      "destination_lng": 116.4074,
      "status": "pending",
      "reached_at": null,
      "completed_at": null,
      "eta": "09:30"
    },
    {
      "id": "660e8400-e29b-41d4-a716-446655440002",
      "journey_id": "550e8400-e29b-41d4-a716-446655440000",
      "sequence": 2,
      "destination_name": "王先生家",
      "destination_address": "朝阳区望京SOHO T3",
      "destination_lat": 39.9965,
      "destination_lng": 116.4704,
      "status": "pending",
      "reached_at": null,
      "completed_at": null,
      "eta": "10:15"
    }
  ]
}
```

**字段说明:**
- `sequence`: 配送顺序（从 1 开始）
- `status`: 配送任务状态
  - `pending` - 待执行
  - `reached` - 已到达
  - `completed` - 已完成
- `eta`: 预计到达时间（HH:MM 格式）

---

### 5. 标记到达目的地

将配送任务标记为"已到达"状态，并返回深度链接。

**端点:** `POST /api/trips/{tripId}/reached`

**路径参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| tripId | string | 是 | 配送任务 ID (UUID) |

**请求示例:**
```http
POST /api/trips/660e8400-e29b-41d4-a716-446655440001/reached
```

**响应示例 (200 OK):**
```json
{
  "success": true,
  "message": "已标记为到达",
  "data": {
    "tripId": "660e8400-e29b-41d4-a716-446655440001",
    "reachedAt": "2025-12-08T09:30:00.000Z",
    "deepLink": "https://your-webapp-domain.com/journey/550e8400-e29b-41d4-a716-446655440000/trip/660e8400-e29b-41d4-a716-446655440001"
  }
}
```

**字段说明:**
- `deepLink`: 用于在网页应用中打开行程详情的 URL

---

### 6. 完成配送任务

将配送任务标记为"已完成"，并返回下一站点的更新 ETA。

**端点:** `POST /api/trips/{tripId}/complete`

**路径参数:**
| 参数 | 类型 | 必填 | 描述 |
|------|------|------|------|
| tripId | string | 是 | 配送任务 ID (UUID) |

**请求示例:**
```http
POST /api/trips/660e8400-e29b-41d4-a716-446655440001/complete
```

**响应示例 (200 OK) - 有下一站点:**
```json
{
  "success": true,
  "message": "配送已完成",
  "data": {
    "tripId": "660e8400-e29b-41d4-a716-446655440001",
    "completedAt": "2025-12-08T09:45:00.000Z",
    "nextTrip": {
      "id": "660e8400-e29b-41d4-a716-446655440002",
      "destination": "王先生家",
      "updatedEta": "10:15"
    }
  }
}
```

**响应示例 (200 OK) - 无下一站点（最后一站）:**
```json
{
  "success": true,
  "message": "配送已完成",
  "data": {
    "tripId": "660e8400-e29b-41d4-a716-446655440003",
    "completedAt": "2025-12-08T11:30:00.000Z",
    "nextTrip": null
  }
}
```

**字段说明:**
- `nextTrip`: 下一个配送站点信息（如果存在）
- `updatedEta`: 更新后的预计到达时间（当前为模拟计算，实际应由后端根据路况计算）

---

## 状态码说明

| 状态码 | 描述 | 使用场景 |
|--------|------|----------|
| 200 | OK | 请求成功 |
| 400 | Bad Request | 请求参数错误或缺失 |
| 404 | Not Found | 资源不存在 |
| 500 | Internal Server Error | 服务器内部错误 |

---

## 错误响应格式

所有错误响应遵循统一格式：

```json
{
  "success": false,
  "error": "错误描述信息"
}
```

**示例:**
```json
{
  "success": false,
  "error": "缺少位置信息"
}
```

---

## 数据模型

### Driver (司机)
```typescript
{
  id: number;
  telegram_id: string;
  name: string;
  phone: string;
}
```

### Journey (行程)
```typescript
{
  id: string;  // UUID
  driver_id: number;
  date: string;  // ISO 8601 date (YYYY-MM-DD)
  status: 'pending' | 'active' | 'completed';
  started_at: string | null;  // ISO 8601 datetime
  completed_at: string | null;  // ISO 8601 datetime
}
```

### Trip (配送任务)
```typescript
{
  id: string;  // UUID
  journey_id: string;  // UUID
  sequence: number;
  destination_name: string;
  destination_address: string;
  destination_lat: number;
  destination_lng: number;
  status: 'pending' | 'reached' | 'completed';
  reached_at: string | null;  // ISO 8601 datetime
  completed_at: string | null;  // ISO 8601 datetime
  eta: string;  // HH:MM format
}
```

### LocationUpdate (位置更新)
```typescript
{
  id: number;
  journey_id: string;  // UUID
  latitude: number;
  longitude: number;
  timestamp: string;  // ISO 8601 datetime
}
```

---

## 集成指南

### 后端集成步骤

1. **替换数据源**
   - 将 `src/api/routes.js` 中的 SQLite 查询替换为后端 API 调用
   - 使用 axios 或 fetch 调用真实后端接口

2. **配置 API 基础 URL**
   ```env
   API_BASE_URL=https://your-backend-api.com
   ```

3. **实现认证**
   - 添加 JWT token 验证
   - 在请求头中传递认证信息

4. **实现真实 ETA 计算**
   - 集成地图服务（Google Maps API / 高德地图 API）
   - 根据实时路况计算预计到达时间

### 示例：集成后端 API

```javascript
// 修改前（使用 SQLite）
const journeys = db.prepare(`
  SELECT * FROM journeys WHERE driver_id = ?
`).all(driverId);

// 修改后（调用后端 API）
const response = await fetch(`${config.api.baseUrl}/drivers/${driverId}/journeys`, {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  }
});
const journeys = await response.json();
```

---

## 测试

### 使用 cURL 测试

```bash
# 获取司机行程
curl http://localhost:3000/api/drivers/1/journeys

# 启动行程
curl -X POST http://localhost:3000/api/journeys/{journeyId}/start \
  -H "Content-Type: application/json" \
  -d '{"latitude": 39.9042, "longitude": 116.4074}'

# 更新位置
curl -X POST http://localhost:3000/api/journeys/{journeyId}/location-update \
  -H "Content-Type: application/json" \
  -d '{"latitude": 39.9042, "longitude": 116.4074}'

# 获取配送任务列表
curl http://localhost:3000/api/journeys/{journeyId}/trips

# 标记到达
curl -X POST http://localhost:3000/api/trips/{tripId}/reached

# 完成配送
curl -X POST http://localhost:3000/api/trips/{tripId}/complete
```

### 使用 Postman

导入以下 Collection：

```json
{
  "info": {
    "name": "Delivery Tracking API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Get Driver Journeys",
      "request": {
        "method": "GET",
        "url": "{{baseUrl}}/api/drivers/1/journeys"
      }
    }
  ],
  "variable": [
    {
      "key": "baseUrl",
      "value": "http://localhost:3000"
    }
  ]
}
```

---

## 版本历史

### v1.0.0 (2025-12-08)
- 初始版本
- 实现 6 个核心 API 端点
- 使用模拟数据
- 支持基本的行程管理功能

---

## 联系方式

如有问题或建议，请联系开发团队。
