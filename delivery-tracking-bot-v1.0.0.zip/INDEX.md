# 📚 项目文档索引

欢迎使用配送行程追踪 Telegram 机器人！本文档帮助你快速找到所需信息。

---

## 🚀 快速开始

**第一次使用？从这里开始：**

1. **[QUICKSTART.md](QUICKSTART.md)** - 5分钟快速开始指南
   - 创建 Telegram Bot
   - 安装和配置
   - 启动服务器
   - 测试功能

2. **自动化设置脚本**
   - Windows: 运行 `.\setup.ps1`
   - Linux/Mac: 运行 `./setup.sh`

---

## 📖 核心文档

### 项目概览

- **[README.md](README.md)** - 项目主文档
  - 功能特性
  - 技术栈
  - 完整使用指南
  - API 文档概览
  - 部署说明

- **[PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)** - 项目交付总结
  - 交付清单
  - 验收标准
  - 项目统计
  - 技术亮点

### 技术文档

- **[API.md](API.md)** - API 参考文档
  - 6 个 REST API 端点详细说明
  - 请求/响应示例
  - 状态码说明
  - 数据模型
  - 集成指南

- **[ARCHITECTURE.md](ARCHITECTURE.md)** - 系统架构文档
  - 架构图
  - 核心组件
  - 数据流
  - 数据库设计
  - 状态机
  - 性能优化

- **[WORKFLOW.md](WORKFLOW.md)** - 流程图和操作说明
  - 完整流程图
  - 司机操作流程
  - 系统交互流程
  - 状态转换图
  - 时间线示例

### 部署文档

- **[DEPLOYMENT.md](DEPLOYMENT.md)** - 部署指南
  - 本地开发环境
  - Render 部署（推荐）
  - Vercel 部署
  - Heroku 部署
  - Docker 部署
  - Webhook 配置
  - 故障排查

---

## 🎯 按场景查找

### 我想快速上手

→ [QUICKSTART.md](QUICKSTART.md)

### 我想了解 API 接口

→ [API.md](API.md)

### 我想部署到生产环境

→ [DEPLOYMENT.md](DEPLOYMENT.md)

### 我想了解系统架构

→ [ARCHITECTURE.md](ARCHITECTURE.md)

### 我想查看操作流程

→ [WORKFLOW.md](WORKFLOW.md)

### 我想查看项目交付情况

→ [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)

---

## 🛠️ 开发资源

### 源代码结构

```
src/
├── bot/              # Telegram 机器人
│   ├── index.js      # Bot 初始化
│   └── handlers.js   # 消息处理器
├── api/              # REST API
│   └── routes.js     # API 路由
├── database/         # 数据库
│   ├── db.js         # 数据库连接
│   ├── init.js       # 初始化脚本
│   └── seed.js       # 测试数据
├── config/           # 配置
│   └── index.js      # 配置管理
└── index.js          # 应用入口
```

### 配置文件

- **package.json** - 依赖配置
- **.env.example** - 环境变量示例
- **.gitignore** - Git 忽略文件

### 测试工具

- **test-api.ps1** - Windows API 测试脚本
- **test-api.sh** - Linux/Mac API 测试脚本

### 设置脚本

- **setup.ps1** - Windows 自动设置脚本
- **setup.sh** - Linux/Mac 自动设置脚本

---

## 📋 常用命令

### 安装和设置

```bash
# 自动设置（推荐）
.\setup.ps1          # Windows
./setup.sh           # Linux/Mac

# 手动设置
npm install          # 安装依赖
cp .env.example .env # 创建配置文件
npm run init-db      # 初始化数据库
node src/database/seed.js  # 填充测试数据
```

### 运行和测试

```bash
# 启动服务器
npm run dev          # 开发模式（自动重启）
npm start            # 生产模式

# 测试 API
.\test-api.ps1       # Windows
./test-api.sh        # Linux/Mac
```

### 数据库管理

```bash
# 重置数据库
rm data.db
npm run init-db
node src/database/seed.js
```

---

## 🔍 API 端点速查

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/drivers/{driverId}/journeys` | GET | 获取司机今日行程 |
| `/api/journeys/{journeyId}/start` | POST | 启动行程 |
| `/api/journeys/{journeyId}/location-update` | POST | 更新位置 |
| `/api/journeys/{journeyId}/trips` | GET | 获取配送任务列表 |
| `/api/trips/{tripId}/reached` | POST | 标记到达 |
| `/api/trips/{tripId}/complete` | POST | 完成配送 |

详细说明请查看 [API.md](API.md)

---

## 🎓 学习路径

### 初学者路径

1. 阅读 [QUICKSTART.md](QUICKSTART.md) 快速上手
2. 运行 `setup.ps1` 或 `setup.sh` 自动设置
3. 启动服务器并测试机器人
4. 查看 [WORKFLOW.md](WORKFLOW.md) 了解操作流程
5. 阅读 [README.md](README.md) 了解完整功能

### 开发者路径

1. 阅读 [ARCHITECTURE.md](ARCHITECTURE.md) 了解系统架构
2. 查看 [API.md](API.md) 了解 API 设计
3. 阅读源代码（从 `src/index.js` 开始）
4. 运行测试脚本验证功能
5. 根据需求修改和扩展

### 运维路径

1. 阅读 [DEPLOYMENT.md](DEPLOYMENT.md) 了解部署方案
2. 选择合适的部署平台
3. 配置环境变量和 Webhook
4. 部署并验证功能
5. 设置监控和日志

---

## 💡 常见问题

### 机器人无响应？

1. 检查服务器是否运行
2. 验证 Bot Token 是否正确
3. 查看服务器日志
4. 确认 Webhook 配置（生产环境）

详细排查请查看 [DEPLOYMENT.md](DEPLOYMENT.md) 的故障排查章节。

### 如何修改测试数据？

编辑 `src/database/seed.js` 文件，修改司机信息和行程数据。

详细说明请查看 [QUICKSTART.md](QUICKSTART.md)。

### 如何集成真实后端？

1. 修改 `src/api/routes.js` 中的数据库查询
2. 替换为后端 API 调用
3. 更新 `.env` 中的 `API_BASE_URL`

详细说明请查看 [API.md](API.md) 的集成指南章节。

---

## 📞 获取帮助

### 文档资源

- 所有文档都在项目根目录
- 使用 Ctrl+F 搜索关键词
- 查看各文档的目录快速定位

### 问题排查

1. 查看相关文档的"常见问题"章节
2. 检查服务器日志输出
3. 运行测试脚本验证功能
4. 查看 [DEPLOYMENT.md](DEPLOYMENT.md) 故障排查

---

## 📊 项目统计

- **总代码行数：** ~1,500 行
- **文档行数：** ~3,000 行
- **源代码文件：** 9 个
- **文档文件：** 8 个
- **API 端点：** 6 个
- **数据库表：** 4 个

---

## 🎯 快速链接

### 必读文档

- [快速开始](QUICKSTART.md) - 5分钟上手
- [项目总结](PROJECT_SUMMARY.md) - 交付清单

### 技术文档

- [API 参考](API.md) - 接口文档
- [系统架构](ARCHITECTURE.md) - 架构设计
- [操作流程](WORKFLOW.md) - 流程图

### 部署文档

- [部署指南](DEPLOYMENT.md) - 多平台部署
- [完整文档](README.md) - 项目主文档

---

## 🚀 开始使用

**推荐步骤：**

1. 运行自动设置脚本
   ```bash
   .\setup.ps1    # Windows
   ./setup.sh     # Linux/Mac
   ```

2. 启动服务器
   ```bash
   npm run dev
   ```

3. 测试机器人
   - 在 Telegram 中发送 `/start`

4. 查看文档
   - 从 [QUICKSTART.md](QUICKSTART.md) 开始

---

**祝你使用愉快！** 🎉

如有问题，请查看相关文档或检查日志输出。
