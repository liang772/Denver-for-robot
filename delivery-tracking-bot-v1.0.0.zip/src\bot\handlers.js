const db = require('../database/db');
const config = require('../config');

// Store active journeys per user
const activeJourneys = new Map();

function handleStart(bot, msg) {
  const chatId = msg.chat.id;
  const welcomeMessage = `
👋 欢迎使用配送行程追踪机器人！

我可以帮助您：
• 查看今日行程
• 启动行程并追踪位置
• 更新配送状态

请选择操作：
  `;

  const keyboard = {
    keyboard: [
      [{ text: '📋 今日我的行程' }],
      [{ text: '🚀 启动行程' }],
      [{ text: '📍 到达目的地' }],
      [{ text: '✅ 完成目的地配送' }]
    ],
    resize_keyboard: true
  };

  bot.sendMessage(chatId, welcomeMessage, { reply_markup: keyboard });
}

function handleMyJourneys(bot, msg) {
  const chatId = msg.chat.id;
  const telegramId = msg.from.id.toString();
  
  // Get driver
  const driver = db.prepare('SELECT * FROM drivers WHERE telegram_id = ?').get(telegramId);
  
  if (!driver) {
    bot.sendMessage(chatId, '❌ 未找到您的司机信息，请联系管理员。');
    return;
  }

  const today = new Date().toISOString().split('T')[0];
  const journeys = db.prepare(`
    SELECT j.*, COUNT(t.id) as total_trips,
           SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed_trips
    FROM journeys j
    LEFT JOIN trips t ON j.id = t.journey_id
    WHERE j.driver_id = ? AND j.date = ?
    GROUP BY j.id
  `).all(driver.id, today);

  if (journeys.length === 0) {
    bot.sendMessage(chatId, '📭 今日暂无行程安排。');
    return;
  }

  let message = '📋 *今日行程列表*\n\n';
  journeys.forEach((journey, index) => {
    const statusEmoji = journey.status === 'active' ? '🟢' : journey.status === 'completed' ? '✅' : '⚪';
    message += `${statusEmoji} *行程 ${index + 1}*\n`;
    message += `状态: ${getStatusText(journey.status)}\n`;
    message += `配送站点: ${journey.completed_trips}/${journey.total_trips}\n`;
    if (journey.started_at) {
      message += `开始时间: ${new Date(journey.started_at).toLocaleTimeString('zh-CN')}\n`;
    }
    message += `\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

function handleStartJourney(bot, msg) {
  const chatId = msg.chat.id;
  const telegramId = msg.from.id.toString();
  
  const driver = db.prepare('SELECT * FROM drivers WHERE telegram_id = ?').get(telegramId);
  
  if (!driver) {
    bot.sendMessage(chatId, '❌ 未找到您的司机信息。');
    return;
  }

  const today = new Date().toISOString().split('T')[0];
  const journey = db.prepare(`
    SELECT * FROM journeys
    WHERE driver_id = ? AND date = ? AND status = 'pending'
    LIMIT 1
  `).get(driver.id, today);

  if (!journey) {
    bot.sendMessage(chatId, '❌ 没有待启动的行程。');
    return;
  }

  // Request live location
  bot.sendMessage(chatId, '🚀 请分享您的实时位置以启动行程：', {
    reply_markup: {
      keyboard: [
        [{ text: '📍 分享实时位置', request_location: true }]
      ],
      one_time_keyboard: true,
      resize_keyboard: true
    }
  });

  activeJourneys.set(chatId, journey.id);
}

function handleLocation(bot, msg) {
  const chatId = msg.chat.id;
  const { latitude, longitude } = msg.location;
  const journeyId = activeJourneys.get(chatId);

  if (!journeyId) {
    bot.sendMessage(chatId, '❌ 请先选择"启动行程"。');
    return;
  }

  // Update journey status
  const startedAt = new Date().toISOString();
  db.prepare(`
    UPDATE journeys 
    SET status = 'active', started_at = ?
    WHERE id = ?
  `).run(startedAt, journeyId);

  // Save location
  db.prepare(`
    INSERT INTO location_updates (journey_id, latitude, longitude, timestamp)
    VALUES (?, ?, ?, ?)
  `).run(journeyId, latitude, longitude, startedAt);

  // Get first trip
  const nextTrip = db.prepare(`
    SELECT * FROM trips
    WHERE journey_id = ? AND status = 'pending'
    ORDER BY sequence ASC
    LIMIT 1
  `).get(journeyId);

  let message = '✅ 行程已启动！\n\n';
  if (nextTrip) {
    message += `📍 *下一个配送站点*\n`;
    message += `目的地: ${nextTrip.destination_name}\n`;
    message += `地址: ${nextTrip.destination_address}\n`;
    message += `预计到达: ${nextTrip.eta}\n`;
  }

  bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

function handleReachedDestination(bot, msg) {
  const chatId = msg.chat.id;
  const journeyId = activeJourneys.get(chatId);

  if (!journeyId) {
    bot.sendMessage(chatId, '❌ 没有活跃的行程。');
    return;
  }

  const currentTrip = db.prepare(`
    SELECT * FROM trips
    WHERE journey_id = ? AND status = 'pending'
    ORDER BY sequence ASC
    LIMIT 1
  `).get(journeyId);

  if (!currentTrip) {
    bot.sendMessage(chatId, '❌ 没有待到达的配送站点。');
    return;
  }

  const reachedAt = new Date().toISOString();
  db.prepare(`
    UPDATE trips 
    SET status = 'reached', reached_at = ?
    WHERE id = ?
  `).run(reachedAt, currentTrip.id);

  const deepLink = `${config.webApp.url}/journey/${journeyId}/trip/${currentTrip.id}`;

  const message = `
✅ 已标记为到达！

📍 *${currentTrip.destination_name}*
${currentTrip.destination_address}

🔗 查看详情：
${deepLink}
  `;

  bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

function handleCompleteDestination(bot, msg) {
  const chatId = msg.chat.id;
  const journeyId = activeJourneys.get(chatId);

  if (!journeyId) {
    bot.sendMessage(chatId, '❌ 没有活跃的行程。');
    return;
  }

  const currentTrip = db.prepare(`
    SELECT * FROM trips
    WHERE journey_id = ? AND status = 'reached'
    ORDER BY sequence ASC
    LIMIT 1
  `).get(journeyId);

  if (!currentTrip) {
    bot.sendMessage(chatId, '❌ 请先标记"到达目的地"。');
    return;
  }

  const completedAt = new Date().toISOString();
  db.prepare(`
    UPDATE trips 
    SET status = 'completed', completed_at = ?
    WHERE id = ?
  `).run(completedAt, currentTrip.id);

  // Get next trip
  const nextTrip = db.prepare(`
    SELECT * FROM trips
    WHERE journey_id = ? AND sequence > ?
    ORDER BY sequence ASC
    LIMIT 1
  `).get(journeyId, currentTrip.sequence);

  let message = `✅ 配送已完成！\n\n`;
  message += `📦 ${currentTrip.destination_name}\n`;
  message += `完成时间: ${new Date(completedAt).toLocaleTimeString('zh-CN')}\n\n`;

  if (nextTrip) {
    // Update ETA (mock)
    const now = new Date();
    now.setMinutes(now.getMinutes() + 20);
    const updatedEta = now.toTimeString().slice(0, 5);
    
    db.prepare(`
      UPDATE trips 
      SET eta = ?
      WHERE id = ?
    `).run(updatedEta, nextTrip.id);

    message += `📍 *下一个配送站点*\n`;
    message += `目的地: ${nextTrip.destination_name}\n`;
    message += `地址: ${nextTrip.destination_address}\n`;
    message += `预计到达: ${updatedEta}\n`;
  } else {
    message += `🎉 所有配送任务已完成！`;
    
    // Mark journey as completed
    db.prepare(`
      UPDATE journeys 
      SET status = 'completed', completed_at = ?
      WHERE id = ?
    `).run(completedAt, journeyId);
    
    activeJourneys.delete(chatId);
  }

  bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
}

function getStatusText(status) {
  const statusMap = {
    'pending': '待启动',
    'active': '进行中',
    'completed': '已完成'
  };
  return statusMap[status] || status;
}

module.exports = {
  handleStart,
  handleMyJourneys,
  handleStartJourney,
  handleLocation,
  handleReachedDestination,
  handleCompleteDestination
};
