const express = require('express');
const config = require('./config');
const { initBot } = require('./bot');
const apiRoutes = require('./api/routes');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/', (req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Delivery Tracking Bot API',
    version: '1.0.0'
  });
});

// API routes
app.use('/api', apiRoutes);

// Initialize Telegram bot
initBot(app);

// Start server
app.listen(config.api.port, () => {
  console.log(`Server running on port ${config.api.port}`);
  console.log(`Environment: ${config.env}`);
});
