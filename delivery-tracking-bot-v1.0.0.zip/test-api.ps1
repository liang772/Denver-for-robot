# API 测试脚本 (PowerShell 版本)
# 用于测试配送行程追踪系统的所有 API 端点

$BASE_URL = "http://localhost:3000/api"

Write-Host "================================" -ForegroundColor Cyan
Write-Host "配送行程追踪 API 测试" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# 测试函数
function Test-Endpoint {
    param(
        [string]$Method,
        [string]$Endpoint,
        [string]$Data,
        [string]$Description
    )
    
    Write-Host "测试: $Description" -ForegroundColor Yellow
    Write-Host "请求: $Method $Endpoint"
    
    try {
        $url = "$BASE_URL$Endpoint"
        
        if ($Method -eq "GET") {
            $response = Invoke-RestMethod -Uri $url -Method Get
        } else {
            $response = Invoke-RestMethod -Uri $url -Method $Method `
                -ContentType "application/json" `
                -Body $Data
        }
        
        Write-Host "✓ 成功" -ForegroundColor Green
        $response | ConvertTo-Json -Depth 10
    }
    catch {
        Write-Host "✗ 失败" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
    
    Write-Host ""
    Write-Host "--------------------------------"
    Write-Host ""
}

# 1. 测试健康检查
Write-Host "1. 健康检查"
try {
    $health = Invoke-RestMethod -Uri "http://localhost:3000/"
    $health | ConvertTo-Json
}
catch {
    Write-Host "服务器未运行，请先启动服务器: npm start" -ForegroundColor Red
    exit
}
Write-Host ""
Write-Host "--------------------------------"
Write-Host ""

# 2. 获取司机今日行程
Test-Endpoint -Method "GET" -Endpoint "/drivers/1/journeys" -Data "" `
    -Description "获取司机 ID=1 的今日行程"

# 保存 journeyId 用于后续测试
$journeys = Invoke-RestMethod -Uri "$BASE_URL/drivers/1/journeys"
$JOURNEY_ID = $journeys.data[0].id
Write-Host "使用 Journey ID: $JOURNEY_ID" -ForegroundColor Cyan
Write-Host ""

# 3. 启动行程
$startData = @{
    latitude = 39.9042
    longitude = 116.4074
} | ConvertTo-Json

Test-Endpoint -Method "POST" -Endpoint "/journeys/$JOURNEY_ID/start" `
    -Data $startData -Description "启动行程并记录位置"

# 4. 更新位置
$locationData = @{
    latitude = 39.9100
    longitude = 116.4100
} | ConvertTo-Json

Test-Endpoint -Method "POST" -Endpoint "/journeys/$JOURNEY_ID/location-update" `
    -Data $locationData -Description "更新司机位置"

# 5. 获取行程的配送任务列表
Test-Endpoint -Method "GET" -Endpoint "/journeys/$JOURNEY_ID/trips" -Data "" `
    -Description "获取行程的配送任务列表"

# 保存 tripId 用于后续测试
$trips = Invoke-RestMethod -Uri "$BASE_URL/journeys/$JOURNEY_ID/trips"
$TRIP_ID = $trips.data[0].id
Write-Host "使用 Trip ID: $TRIP_ID" -ForegroundColor Cyan
Write-Host ""

# 6. 标记到达目的地
Test-Endpoint -Method "POST" -Endpoint "/trips/$TRIP_ID/reached" -Data "" `
    -Description "标记到达第一个配送站点"

# 7. 完成配送任务
Test-Endpoint -Method "POST" -Endpoint "/trips/$TRIP_ID/complete" -Data "" `
    -Description "完成第一个配送任务"

# 8. 再次获取配送任务列表（查看状态变化）
Test-Endpoint -Method "GET" -Endpoint "/journeys/$JOURNEY_ID/trips" -Data "" `
    -Description "查看更新后的配送任务状态"

Write-Host "================================" -ForegroundColor Cyan
Write-Host "测试完成！" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
