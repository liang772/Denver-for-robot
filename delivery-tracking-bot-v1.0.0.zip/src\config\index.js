require('dotenv').config();

module.exports = {
  telegram: {
    token: process.env.TELEGRAM_BOT_TOKEN,
    webhookUrl: process.env.WEBHOOK_URL
  },
  api: {
    port: process.env.PORT || 3000,
    baseUrl: process.env.API_BASE_URL || 'http://localhost:3000'
  },
  webApp: {
    url: process.env.WEB_APP_URL || 'https://your-webapp-domain.com'
  },
  env: process.env.NODE_ENV || 'development'
};
