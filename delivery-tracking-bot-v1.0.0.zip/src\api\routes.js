const express = require('express');
const router = express.Router();
const db = require('../database/db');
const config = require('../config');

// GET /api/drivers/{driverId}/journeys
router.get('/drivers/:driverId/journeys', (req, res) => {
  try {
    const { driverId } = req.params;
    const today = new Date().toISOString().split('T')[0];
    
    const journeys = db.prepare(`
      SELECT j.*, COUNT(t.id) as total_trips,
             SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed_trips
      FROM journeys j
      LEFT JOIN trips t ON j.id = t.journey_id
      WHERE j.driver_id = ? AND j.date = ?
      GROUP BY j.id
    `).all(driverId, today);

    res.json({
      success: true,
      data: journeys
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/journeys/{journeyId}/start
router.post('/journeys/:journeyId/start', (req, res) => {
  try {
    const { journeyId } = req.params;
    const { latitude, longitude } = req.body;
    
    const startedAt = new Date().toISOString();
    
    db.prepare(`
      UPDATE journeys 
      SET status = 'active', started_at = ?
      WHERE id = ?
    `).run(startedAt, journeyId);

    if (latitude && longitude) {
      db.prepare(`
        INSERT INTO location_updates (journey_id, latitude, longitude, timestamp)
        VALUES (?, ?, ?, ?)
      `).run(journeyId, latitude, longitude, startedAt);
    }

    res.json({
      success: true,
      message: '行程已启动',
      data: { journeyId, startedAt }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/journeys/{journeyId}/location-update
router.post('/journeys/:journeyId/location-update', (req, res) => {
  try {
    const { journeyId } = req.params;
    const { latitude, longitude } = req.body;
    
    if (!latitude || !longitude) {
      return res.status(400).json({ success: false, error: '缺少位置信息' });
    }

    const timestamp = new Date().toISOString();
    
    db.prepare(`
      INSERT INTO location_updates (journey_id, latitude, longitude, timestamp)
      VALUES (?, ?, ?, ?)
    `).run(journeyId, latitude, longitude, timestamp);

    res.json({
      success: true,
      message: '位置已更新',
      data: { latitude, longitude, timestamp }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/journeys/{journeyId}/trips
router.get('/journeys/:journeyId/trips', (req, res) => {
  try {
    const { journeyId } = req.params;
    
    const trips = db.prepare(`
      SELECT * FROM trips
      WHERE journey_id = ?
      ORDER BY sequence ASC
    `).all(journeyId);

    res.json({
      success: true,
      data: trips
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/trips/{tripId}/reached
router.post('/trips/:tripId/reached', (req, res) => {
  try {
    const { tripId } = req.params;
    const reachedAt = new Date().toISOString();
    
    db.prepare(`
      UPDATE trips 
      SET status = 'reached', reached_at = ?
      WHERE id = ?
    `).run(reachedAt, tripId);

    const trip = db.prepare('SELECT * FROM trips WHERE id = ?').get(tripId);
    const deepLink = `${config.webApp.url}/journey/${trip.journey_id}/trip/${tripId}`;

    res.json({
      success: true,
      message: '已标记为到达',
      data: {
        tripId,
        reachedAt,
        deepLink
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/trips/{tripId}/complete
router.post('/trips/:tripId/complete', (req, res) => {
  try {
    const { tripId } = req.params;
    const completedAt = new Date().toISOString();
    
    db.prepare(`
      UPDATE trips 
      SET status = 'completed', completed_at = ?
      WHERE id = ?
    `).run(completedAt, tripId);

    const trip = db.prepare('SELECT * FROM trips WHERE id = ?').get(tripId);
    
    // Get next trip and update ETA (mock calculation)
    const nextTrip = db.prepare(`
      SELECT * FROM trips
      WHERE journey_id = ? AND sequence > ?
      ORDER BY sequence ASC
      LIMIT 1
    `).get(trip.journey_id, trip.sequence);

    let updatedEta = null;
    if (nextTrip) {
      const now = new Date();
      now.setMinutes(now.getMinutes() + 20); // Mock: add 20 minutes
      updatedEta = now.toTimeString().slice(0, 5);
      
      db.prepare(`
        UPDATE trips 
        SET eta = ?
        WHERE id = ?
      `).run(updatedEta, nextTrip.id);
    }

    res.json({
      success: true,
      message: '配送已完成',
      data: {
        tripId,
        completedAt,
        nextTrip: nextTrip ? {
          id: nextTrip.id,
          destination: nextTrip.destination_name,
          updatedEta
        } : null
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
