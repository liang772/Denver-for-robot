# 配送行程追踪 Telegram 机器人

一个用于司机管理配送行程的 Telegram 机器人系统，支持实时位置追踪和配送状态更新。

> 📚 **快速导航：** 查看 [INDEX.md](INDEX.md) 获取完整文档索引  
> 🚀 **快速开始：** 查看 [QUICKSTART.md](QUICKSTART.md) 5分钟上手指南

## 功能特性

- 📋 查看今日行程列表
- 🚀 启动行程并分享实时位置
- 📍 标记到达目的地
- ✅ 完成配送任务
- 🔗 生成深度链接访问网页应用
- ⏰ 自动更新预计到达时间（ETA）

## 技术栈

- Node.js + Express
- node-telegram-bot-api
- SQLite (better-sqlite3)
- dotenv

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境变量

复制 `.env.example` 为 `.env` 并填写配置：

```bash
cp .env.example .env
```

编辑 `.env` 文件：

```env
TELEGRAM_BOT_TOKEN=your_bot_token_here
WEBHOOK_URL=https://your-domain.com
PORT=3000
API_BASE_URL=http://localhost:3000
WEB_APP_URL=https://your-webapp-domain.com
NODE_ENV=development
```

### 3. 初始化数据库

```bash
npm run init-db
node src/database/seed.js
```

### 4. 启动服务

开发环境（使用 polling 模式）：
```bash
npm run dev
```

生产环境（使用 webhook 模式）：
```bash
npm start
```

## 机器人使用指南

### 司机操作流程

1. **启动机器人**
   - 发送 `/start` 命令
   - 机器人显示功能菜单

2. **查看今日行程**
   - 点击 "📋 今日我的行程"
   - 查看所有分配的行程和完成进度

3. **启动行程**
   - 点击 "🚀 启动行程"
   - 分享实时位置
   - 系统显示下一个配送站点信息

4. **到达目的地**
   - 点击 "📍 到达目的地"
   - 获取深度链接查看详情

5. **完成配送**
   - 点击 "✅ 完成目的地配送"
   - 系统显示下一站点和更新的 ETA

## API 文档

### 基础信息

- Base URL: `http://localhost:3000/api`
- Content-Type: `application/json`

### 端点列表

#### 1. 获取司机今日行程

```http
GET /api/drivers/{driverId}/journeys
```

**响应示例：**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "driver_id": 1,
      "date": "2025-12-08",
      "status": "pending",
      "total_trips": 3,
      "completed_trips": 0
    }
  ]
}
```

#### 2. 启动行程

```http
POST /api/journeys/{journeyId}/start
```

**请求体：**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

**响应示例：**
```json
{
  "success": true,
  "message": "行程已启动",
  "data": {
    "journeyId": "uuid",
    "startedAt": "2025-12-08T09:00:00.000Z"
  }
}
```

#### 3. 更新位置

```http
POST /api/journeys/{journeyId}/location-update
```

**请求体：**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

#### 4. 获取行程配送任务列表

```http
GET /api/journeys/{journeyId}/trips
```

**响应示例：**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "journey_id": "uuid",
      "sequence": 1,
      "destination_name": "北京市朝阳区配送中心",
      "destination_address": "朝阳区建国路88号",
      "status": "pending",
      "eta": "09:30"
    }
  ]
}
```

#### 5. 标记到达目的地

```http
POST /api/trips/{tripId}/reached
```

**响应示例：**
```json
{
  "success": true,
  "message": "已标记为到达",
  "data": {
    "tripId": "uuid",
    "reachedAt": "2025-12-08T09:30:00.000Z",
    "deepLink": "https://your-webapp-domain.com/journey/xxx/trip/xxx"
  }
}
```

#### 6. 完成配送任务

```http
POST /api/trips/{tripId}/complete
```

**响应示例：**
```json
{
  "success": true,
  "message": "配送已完成",
  "data": {
    "tripId": "uuid",
    "completedAt": "2025-12-08T09:45:00.000Z",
    "nextTrip": {
      "id": "uuid",
      "destination": "王先生家",
      "updatedEta": "10:15"
    }
  }
}
```

### 状态码说明

- `200` - 成功
- `400` - 请求参数错误
- `404` - 资源不存在
- `500` - 服务器错误

## 数据库结构

### drivers 表
- `id` - 司机 ID
- `telegram_id` - Telegram 用户 ID
- `name` - 司机姓名
- `phone` - 联系电话

### journeys 表
- `id` - 行程 ID
- `driver_id` - 司机 ID
- `date` - 日期
- `status` - 状态（pending/active/completed）
- `started_at` - 开始时间
- `completed_at` - 完成时间

### trips 表
- `id` - 配送任务 ID
- `journey_id` - 行程 ID
- `sequence` - 顺序
- `destination_name` - 目的地名称
- `destination_address` - 目的地地址
- `status` - 状态（pending/reached/completed）
- `eta` - 预计到达时间

### location_updates 表
- `id` - 记录 ID
- `journey_id` - 行程 ID
- `latitude` - 纬度
- `longitude` - 经度
- `timestamp` - 时间戳

## 部署指南

### Vercel 部署

1. 安装 Vercel CLI：
```bash
npm i -g vercel
```

2. 部署：
```bash
vercel
```

3. 设置环境变量（在 Vercel Dashboard）

### Render 部署

1. 连接 GitHub 仓库
2. 选择 "Web Service"
3. 设置构建命令：`npm install`
4. 设置启动命令：`npm start`
5. 添加环境变量

### Heroku 部署

1. 创建应用：
```bash
heroku create your-app-name
```

2. 设置环境变量：
```bash
heroku config:set TELEGRAM_BOT_TOKEN=your_token
```

3. 部署：
```bash
git push heroku main
```

## 系统架构

```
司机 (Telegram)
    ↓
Telegram Bot API
    ↓
Bot Handler (src/bot/)
    ↓
API Layer (src/api/)
    ↓
Database (SQLite)
```

## 开发说明

### 项目结构

```
.
├── src/
│   ├── bot/
│   │   ├── index.js       # Bot 初始化
│   │   └── handlers.js    # 消息处理器
│   ├── api/
│   │   └── routes.js      # API 路由
│   ├── database/
│   │   ├── db.js          # 数据库连接
│   │   ├── init.js        # 初始化脚本
│   │   └── seed.js        # 模拟数据
│   ├── config/
│   │   └── index.js       # 配置管理
│   └── index.js           # 应用入口
├── package.json
├── .env.example
└── README.md
```

### 添加新功能

1. 在 `src/bot/handlers.js` 添加新的消息处理器
2. 在 `src/api/routes.js` 添加新的 API 端点
3. 更新数据库结构（如需要）

## 后续集成说明

本项目使用模拟数据，后续集成真实后端时：

1. 修改 `src/api/routes.js` 中的数据库查询为后端 API 调用
2. 更新 `.env` 中的 `API_BASE_URL` 指向真实后端
3. 实现真实的 ETA 计算逻辑
4. 添加认证机制（JWT/OAuth）

## 许可证

MIT
