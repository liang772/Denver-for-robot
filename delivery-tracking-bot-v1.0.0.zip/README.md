# Delivery Journey Tracking Telegram Bot

A Telegram bot system for drivers to manage delivery journeys, supporting real-time location tracking and delivery status updates.

> 📚 **Quick Navigation:** See [INDEX.md](INDEX.md) for complete documentation index  
> 🚀 **Quick Start:** See [QUICKSTART.md](QUICKSTART.md) for 5-minute setup guide

## Features

- 📋 View today's journey list
- 🚀 Start journey and share real-time location
- 📍 Mark destination as reached
- ✅ Complete delivery tasks
- 🔗 Generate deep links to web app
- ⏰ Automatically update ETA (Estimated Time of Arrival)

## Tech Stack

- Node.js + Express
- node-telegram-bot-api
- SQLite (better-sqlite3)
- dotenv

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment Variables

Copy `.env.example` to `.env` and fill in the configuration:

```bash
cp .env.example .env
```

Edit `.env` file:

```env
TELEGRAM_BOT_TOKEN=your_bot_token_here
WEBHOOK_URL=https://your-domain.com
PORT=3000
API_BASE_URL=http://localhost:3000
WEB_APP_URL=https://your-webapp-domain.com
NODE_ENV=development
```

### 3. Initialize Database

```bash
npm run init-db
node src/database/seed.js
```

### 4. Start Service

Development environment (using polling mode):
```bash
npm run dev
```

Production environment (using webhook mode):
```bash
npm start
```

## Bot Usage Guide

### Driver Operation Flow

1. **Start Bot**
   - Send `/start` command
   - Bot displays function menu

2. **View Today's Journeys**
   - Click "📋 My Journeys Today"
   - View all assigned journeys and completion progress

3. **Start Journey**
   - Click "🚀 Start Journey"
   - Share real-time location
   - System displays next delivery destination information

4. **Reach Destination**
   - Click "📍 Reached Destination"
   - Get deep link to view details

5. **Complete Delivery**
   - Click "✅ Complete Destination"
   - System displays next destination and updated ETA

## API Documentation

### Base Information

- Base URL: `http://localhost:3000/api`
- Content-Type: `application/json`

### Endpoint List

#### 1. Get Driver's Today Journeys

```http
GET /api/drivers/{driverId}/journeys
```

**Response Example:**
```json
{
  "success": true,
  "data": [
    {
      "id": "uuid",
      "driver_id": 1,
      "date": "2025-12-08",
      "status": "pending",
      "total_trips": 3,
      "completed_trips": 0
    }
  ]
}
```

#### 2. Start Journey

```http
POST /api/journeys/{journeyId}/start
```

**Request Body:**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

#### 3. Update Location

```http
POST /api/journeys/{journeyId}/location-update
```

**Request Body:**
```json
{
  "latitude": 39.9042,
  "longitude": 116.4074
}
```

#### 4. Get Journey Trips List

```http
GET /api/journeys/{journeyId}/trips
```

#### 5. Mark Destination as Reached

```http
POST /api/trips/{tripId}/reached
```

**Response Example:**
```json
{
  "success": true,
  "message": "Marked as reached",
  "data": {
    "tripId": "uuid",
    "reachedAt": "2025-12-08T09:30:00.000Z",
    "deepLink": "https://your-webapp-domain.com/journey/xxx/trip/xxx"
  }
}
```

#### 6. Complete Delivery Task

```http
POST /api/trips/{tripId}/complete
```

**Response Example:**
```json
{
  "success": true,
  "message": "Delivery completed",
  "data": {
    "tripId": "uuid",
    "completedAt": "2025-12-08T09:45:00.000Z",
    "nextTrip": {
      "id": "uuid",
      "destination": "Next Location",
      "updatedEta": "10:15"
    }
  }
}
```

## Database Structure

### drivers Table
- `id` - Driver ID
- `telegram_id` - Telegram User ID
- `name` - Driver Name
- `phone` - Contact Phone

### journeys Table
- `id` - Journey ID
- `driver_id` - Driver ID
- `date` - Date
- `status` - Status (pending/active/completed)
- `started_at` - Start Time
- `completed_at` - Completion Time

### trips Table
- `id` - Delivery Task ID
- `journey_id` - Journey ID
- `sequence` - Sequence Number
- `destination_name` - Destination Name
- `destination_address` - Destination Address
- `status` - Status (pending/reached/completed)
- `eta` - Estimated Time of Arrival

### location_updates Table
- `id` - Record ID
- `journey_id` - Journey ID
- `latitude` - Latitude
- `longitude` - Longitude
- `timestamp` - Timestamp

## Deployment Guide

### Vercel Deployment

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Deploy:
```bash
vercel
```

3. Set environment variables in Vercel Dashboard

### Render Deployment (Recommended)

1. Connect GitHub repository
2. Select "Web Service"
3. Set build command: `npm install`
4. Set start command: `npm start`
5. Add environment variables

### Heroku Deployment

1. Create app:
```bash
heroku create your-app-name
```

2. Set environment variables:
```bash
heroku config:set TELEGRAM_BOT_TOKEN=your_token
```

3. Deploy:
```bash
git push heroku main
```

## System Architecture

```
Driver (Telegram)
    ↓
Telegram Bot API
    ↓
Bot Handler (src/bot/)
    ↓
API Layer (src/api/)
    ↓
Database (SQLite)
```

## Development Guide

### Project Structure

```
.
├── src/
│   ├── bot/
│   │   ├── index.js       # Bot initialization
│   │   └── handlers.js    # Message handlers
│   ├── api/
│   │   └── routes.js      # API routes
│   ├── database/
│   │   ├── db.js          # Database connection
│   │   ├── init.js        # Initialization script
│   │   └── seed.js        # Mock data
│   ├── config/
│   │   └── index.js       # Configuration management
│   └── index.js           # Application entry
├── package.json
├── .env.example
└── README.md
```

### Adding New Features

1. Add new message handlers in `src/bot/handlers.js`
2. Add new API endpoints in `src/api/routes.js`
3. Update database structure (if needed)

## Backend Integration Guide

This project currently uses mock data. To integrate with your backend:

1. Modify database queries in `src/api/routes.js` to call your backend API
2. Update `API_BASE_URL` in `.env` to point to your backend
3. Implement real ETA calculation logic
4. Add authentication mechanism (JWT/OAuth)

## Testing

### Manual Testing

```bash
# Test health check
curl http://localhost:3000/

# Get driver journeys
curl http://localhost:3000/api/drivers/1/journeys
```

### API Testing Scripts

Windows:
```powershell
.\test-api.ps1
```

Linux/Mac:
```bash
chmod +x test-api.sh
./test-api.sh
```

## Troubleshooting

### Bot Not Responding?

1. Confirm server is running
2. Check if Bot Token is correct
3. View server log output
4. Confirm `/start` command was sent

### Database Error?

```bash
# Delete old database and reinitialize
rm data.db
npm run init-db
node src/database/seed.js
```

### Port Already in Use?

Edit `.env` file:
```env
PORT=3001
```

## License

MIT

## Support

For questions or issues, please check the documentation or contact the development team.
