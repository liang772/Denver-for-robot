#!/bin/bash

# API 测试脚本
# 用于测试配送行程追踪系统的所有 API 端点

BASE_URL="http://localhost:3000/api"

echo "================================"
echo "配送行程追踪 API 测试"
echo "================================"
echo ""

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 测试函数
test_endpoint() {
    local method=$1
    local endpoint=$2
    local data=$3
    local description=$4
    
    echo -e "${YELLOW}测试: ${description}${NC}"
    echo "请求: $method $endpoint"
    
    if [ "$method" = "GET" ]; then
        response=$(curl -s -w "\n%{http_code}" "$BASE_URL$endpoint")
    else
        response=$(curl -s -w "\n%{http_code}" -X "$method" "$BASE_URL$endpoint" \
            -H "Content-Type: application/json" \
            -d "$data")
    fi
    
    http_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | sed '$d')
    
    if [ "$http_code" -eq 200 ]; then
        echo -e "${GREEN}✓ 成功 (HTTP $http_code)${NC}"
        echo "响应: $body" | jq '.' 2>/dev/null || echo "$body"
    else
        echo -e "${RED}✗ 失败 (HTTP $http_code)${NC}"
        echo "响应: $body"
    fi
    
    echo ""
    echo "--------------------------------"
    echo ""
}

# 1. 测试健康检查
echo "1. 健康检查"
curl -s http://localhost:3000/ | jq '.'
echo ""
echo "--------------------------------"
echo ""

# 2. 获取司机今日行程
test_endpoint "GET" "/drivers/1/journeys" "" "获取司机 ID=1 的今日行程"

# 保存 journeyId 用于后续测试
JOURNEY_ID=$(curl -s "$BASE_URL/drivers/1/journeys" | jq -r '.data[0].id')
echo "使用 Journey ID: $JOURNEY_ID"
echo ""

# 3. 启动行程
test_endpoint "POST" "/journeys/$JOURNEY_ID/start" \
    '{"latitude": 39.9042, "longitude": 116.4074}' \
    "启动行程并记录位置"

# 4. 更新位置
test_endpoint "POST" "/journeys/$JOURNEY_ID/location-update" \
    '{"latitude": 39.9100, "longitude": 116.4100}' \
    "更新司机位置"

# 5. 获取行程的配送任务列表
test_endpoint "GET" "/journeys/$JOURNEY_ID/trips" "" "获取行程的配送任务列表"

# 保存 tripId 用于后续测试
TRIP_ID=$(curl -s "$BASE_URL/journeys/$JOURNEY_ID/trips" | jq -r '.data[0].id')
echo "使用 Trip ID: $TRIP_ID"
echo ""

# 6. 标记到达目的地
test_endpoint "POST" "/trips/$TRIP_ID/reached" "" "标记到达第一个配送站点"

# 7. 完成配送任务
test_endpoint "POST" "/trips/$TRIP_ID/complete" "" "完成第一个配送任务"

# 8. 再次获取配送任务列表（查看状态变化）
test_endpoint "GET" "/journeys/$JOURNEY_ID/trips" "" "查看更新后的配送任务状态"

echo "================================"
echo "测试完成！"
echo "================================"
