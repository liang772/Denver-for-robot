const db = require('./db');
const { v4: uuidv4 } = require('uuid');

// Seed mock data
function seedData() {
  // Insert mock driver
  const driver = db.prepare(`
    INSERT OR IGNORE INTO drivers (telegram_id, name, phone)
    VALUES (?, ?, ?)
  `).run('123456789', '张师傅', '+86 138 0000 0000');

  const driverId = db.prepare('SELECT id FROM drivers WHERE telegram_id = ?').get('123456789')?.id;

  if (!driverId) return;

  // Insert mock journeys
  const today = new Date().toISOString().split('T')[0];
  const journeyId1 = uuidv4();
  const journeyId2 = uuidv4();

  db.prepare(`
    INSERT OR IGNORE INTO journeys (id, driver_id, date, status)
    VALUES (?, ?, ?, ?)
  `).run(journeyId1, driverId, today, 'pending');

  db.prepare(`
    INSERT OR IGNORE INTO journeys (id, driver_id, date, status)
    VALUES (?, ?, ?, ?)
  `).run(journeyId2, driverId, today, 'pending');

  // Insert mock trips for journey 1
  const trips1 = [
    { name: '北京市朝阳区配送中心', address: '朝阳区建国路88号', lat: 39.9042, lng: 116.4074, eta: '09:30' },
    { name: '王先生家', address: '朝阳区望京SOHO T3', lat: 39.9965, lng: 116.4704, eta: '10:15' },
    { name: '李女士公司', address: '海淀区中关村大街1号', lat: 39.9869, lng: 116.3143, eta: '11:00' }
  ];

  trips1.forEach((trip, index) => {
    db.prepare(`
      INSERT OR IGNORE INTO trips (id, journey_id, sequence, destination_name, destination_address, destination_lat, destination_lng, status, eta)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(uuidv4(), journeyId1, index + 1, trip.name, trip.address, trip.lat, trip.lng, 'pending', trip.eta);
  });

  // Insert mock trips for journey 2
  const trips2 = [
    { name: '上海市浦东新区仓库', address: '浦东新区张江高科技园区', lat: 31.2304, lng: 121.4737, eta: '14:00' },
    { name: '陈先生办公室', address: '浦东新区世纪大道100号', lat: 31.2397, lng: 121.5058, eta: '15:30' }
  ];

  trips2.forEach((trip, index) => {
    db.prepare(`
      INSERT OR IGNORE INTO trips (id, journey_id, sequence, destination_name, destination_address, destination_lat, destination_lng, status, eta)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(uuidv4(), journeyId2, index + 1, trip.name, trip.address, trip.lat, trip.lng, 'pending', trip.eta);
  });

  console.log('Mock data seeded successfully');
}

seedData();
