const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, '../../data.db'));

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS drivers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    phone TEXT
  );

  CREATE TABLE IF NOT EXISTS journeys (
    id TEXT PRIMARY KEY,
    driver_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    started_at TEXT,
    completed_at TEXT,
    FOREIGN KEY (driver_id) REFERENCES drivers(id)
  );

  CREATE TABLE IF NOT EXISTS trips (
    id TEXT PRIMARY KEY,
    journey_id TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    destination_name TEXT NOT NULL,
    destination_address TEXT NOT NULL,
    destination_lat REAL,
    destination_lng REAL,
    status TEXT DEFAULT 'pending',
    reached_at TEXT,
    completed_at TEXT,
    eta TEXT,
    FOREIGN KEY (journey_id) REFERENCES journeys(id)
  );

  CREATE TABLE IF NOT EXISTS location_updates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    journey_id TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (journey_id) REFERENCES journeys(id)
  );
`);

console.log('Database initialized successfully');
db.close();
