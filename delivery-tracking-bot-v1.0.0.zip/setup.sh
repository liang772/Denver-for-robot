#!/bin/bash

# 项目快速设置脚本
# 自动完成项目初始化

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}================================${NC}"
echo -e "${CYAN}配送行程追踪机器人 - 快速设置${NC}"
echo -e "${CYAN}================================${NC}"
echo ""

# 检查 Node.js
echo -e "${YELLOW}检查 Node.js...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✓ Node.js 已安装: $NODE_VERSION${NC}"
else
    echo -e "${RED}✗ 未找到 Node.js，请先安装 Node.js 16+${NC}"
    echo -e "${YELLOW}下载地址: https://nodejs.org/${NC}"
    exit 1
fi
echo ""

# 检查 npm
echo -e "${YELLOW}检查 npm...${NC}"
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    echo -e "${GREEN}✓ npm 已安装: $NPM_VERSION${NC}"
else
    echo -e "${RED}✗ 未找到 npm${NC}"
    exit 1
fi
echo ""

# 安装依赖
echo -e "${YELLOW}安装项目依赖...${NC}"
npm install
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 依赖安装成功${NC}"
else
    echo -e "${RED}✗ 依赖安装失败${NC}"
    exit 1
fi
echo ""

# 检查 .env 文件
echo -e "${YELLOW}检查环境变量配置...${NC}"
if [ -f ".env" ]; then
    echo -e "${GREEN}✓ .env 文件已存在${NC}"
else
    echo -e "${YELLOW}! .env 文件不存在，正在创建...${NC}"
    cp .env.example .env
    echo -e "${GREEN}✓ 已创建 .env 文件${NC}"
    echo ""
    echo -e "${YELLOW}⚠ 重要：请编辑 .env 文件，填入你的 Telegram Bot Token${NC}"
    echo -e "${CYAN}   1. 在 Telegram 中找到 @BotFather${NC}"
    echo -e "${CYAN}   2. 发送 /newbot 创建机器人${NC}"
    echo -e "${CYAN}   3. 复制获得的 Token${NC}"
    echo -e "${CYAN}   4. 编辑 .env 文件，填入 TELEGRAM_BOT_TOKEN${NC}"
    echo ""
    
    # 询问是否现在配置
    read -p "是否现在配置 Bot Token? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        read -p "请输入你的 Telegram Bot Token: " TOKEN
        if [ ! -z "$TOKEN" ]; then
            sed -i.bak "s/TELEGRAM_BOT_TOKEN=.*/TELEGRAM_BOT_TOKEN=$TOKEN/" .env
            rm .env.bak 2>/dev/null
            echo -e "${GREEN}✓ Bot Token 已配置${NC}"
        fi
    fi
fi
echo ""

# 初始化数据库
echo -e "${YELLOW}初始化数据库...${NC}"
npm run init-db
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 数据库初始化成功${NC}"
else
    echo -e "${RED}✗ 数据库初始化失败${NC}"
    exit 1
fi
echo ""

# 填充测试数据
echo -e "${YELLOW}填充测试数据...${NC}"
node src/database/seed.js
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ 测试数据填充成功${NC}"
else
    echo -e "${RED}✗ 测试数据填充失败${NC}"
    exit 1
fi
echo ""

# 完成
echo -e "${CYAN}================================${NC}"
echo -e "${GREEN}✓ 设置完成！${NC}"
echo -e "${CYAN}================================${NC}"
echo ""
echo -e "${YELLOW}下一步操作：${NC}"
echo -e "${CYAN}1. 确保 .env 文件中的 Bot Token 已配置${NC}"
echo -e "${CYAN}2. 运行 'npm run dev' 启动开发服务器${NC}"
echo -e "${CYAN}3. 在 Telegram 中找到你的机器人并发送 /start${NC}"
echo ""
echo -e "${YELLOW}查看文档：${NC}"
echo -e "${CYAN}- QUICKSTART.md - 快速开始指南${NC}"
echo -e "${CYAN}- README.md - 完整文档${NC}"
echo -e "${CYAN}- API.md - API 参考${NC}"
echo ""
echo -e "${YELLOW}准备好了吗？运行以下命令启动服务器：${NC}"
echo -e "${GREEN}npm run dev${NC}"
echo ""
