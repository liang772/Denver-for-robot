# Driver Operation Flow Diagrams

This document describes the complete flow for drivers using the Telegram bot to complete delivery tasks.

---

## Complete Flow Diagram

```
                    ┌─────────────────┐
                    │   Driver Opens  │
                    │  Telegram Bot   │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  Send /start    │
                    │   Command       │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  Display Menu   │
                    │  - Today's      │
                    │    Journeys     │
                    │  - Start        │
                    │    Journey      │
                    │  - Reached      │
                    │  - Complete     │
                    └────────┬────────┘
                             │
                ┌────────────┼────────────┐
                │            │            │
                ▼            ▼            ▼
        ┌──────────┐  ┌──────────┐  ┌──────────┐
        │View      │  │Start     │  │Update    │
        │Journeys  │  │Journey   │  │Status    │
        └──────────┘  └──────────┘  └──────────┘
```

---

## Detailed Flows

### 1. Initialization Flow

```
Driver
 │
 ├─► Open Telegram
 │
 ├─► Search and open bot
 │
 ├─► Send /start command
 │
 └─► Receive welcome message and function menu
      ├─ 📋 My Journeys Today
      ├─ 🚀 Start Journey
      ├─ 📍 Reached Destination
      └─ ✅ Complete Destination
```

---

### 2. View Today's Journeys Flow

```
┌──────────────┐
│ Driver Clicks│
│"My Journeys  │
│   Today"     │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ Bot Queries Database │
│ SELECT journeys      │
│ WHERE driver_id = ?  │
│ AND date = today     │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Return Journey List  │
│                      │
│ 🟢 Journey 1         │
│ Status: In Progress  │
│ Destinations: 2/5    │
│                      │
│ ⚪ Journey 2         │
│ Status: Not Started  │
│ Destinations: 0/3    │
└──────────────────────┘
```

---

### 3. Start Journey Flow

```
┌──────────────┐
│ Driver Clicks│
│"Start        │
│ Journey"     │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ Bot Queries Pending  │
│ Journey              │
│ SELECT journey       │
│ WHERE status =       │
│ 'pending'            │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Request Share        │
│ Real-time Location   │
│ "Please share your   │
│  real-time location  │
│  to start journey"   │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Driver Clicks        │
│ "📍 Share Real-time  │
│     Location"        │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Bot Receives         │
│ Location Data        │
│ latitude: 39.9042    │
│ longitude: 116.4074  │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Update Journey       │
│ Status               │
│ UPDATE journeys      │
│ SET status = 'active'│
│ started_at = now()   │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Save Location Record │
│ INSERT INTO          │
│ location_updates     │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Query Next           │
│ Destination          │
│ SELECT trip          │
│ WHERE status =       │
│ 'pending'            │
│ ORDER BY sequence    │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Display Next         │
│ Destination Info     │
│                      │
│ ✅ Journey Started!  │
│                      │
│ 📍 Next Destination  │
│ Destination: Center  │
│ Address: 88 Road     │
│ ETA: 09:30           │
└──────────────────────┘
```

---

### 4. Reached Destination Flow

```
┌──────────────┐
│ Driver       │
│ Arrives at   │
│ Destination  │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ Driver Clicks        │
│ "📍 Reached          │
│     Destination"     │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Bot Queries Current  │
│ Destination          │
│ SELECT trip          │
│ WHERE status =       │
│ 'pending'            │
│ ORDER BY sequence    │
│ LIMIT 1              │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Update Destination   │
│ Status               │
│ UPDATE trips         │
│ SET status =         │
│ 'reached'            │
│ reached_at = now()   │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Generate Deep Link   │
│ deepLink =           │
│ webapp.com/journey/  │
│ {journeyId}/trip/    │
│ {tripId}             │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Return Confirmation  │
│                      │
│ ✅ Marked as Reached!│
│                      │
│ 📍 Distribution      │
│    Center            │
│ 88 Jianguo Road      │
│                      │
│ 🔗 View Details:     │
│ [Deep Link]          │
└──────────────────────┘
```

---

### 5. Complete Delivery Flow

```
┌──────────────┐
│ Driver       │
│ Completes    │
│ Delivery     │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ Driver Clicks        │
│ "✅ Complete         │
│     Destination"     │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Bot Queries Current  │
│ Destination          │
│ SELECT trip          │
│ WHERE status =       │
│ 'reached'            │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Update Destination   │
│ Status               │
│ UPDATE trips         │
│ SET status =         │
│ 'completed'          │
│ completed_at = now() │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Query Next           │
│ Destination          │
│ SELECT trip          │
│ WHERE sequence >     │
│ current_sequence     │
│ ORDER BY sequence    │
│ LIMIT 1              │
└──────┬───────────────┘
       │
       ├─► Has Next Destination
       │   │
       │   ▼
       │   ┌──────────────────────┐
       │   │ Calculate & Update   │
       │   │ ETA                  │
       │   │ (Mock: current+20min)│
       │   └──────┬───────────────┘
       │          │
       │          ▼
       │   ┌──────────────────────┐
       │   │ Display Next         │
       │   │ Destination Info     │
       │   │                      │
       │   │ ✅ Delivery Complete!│
       │   │                      │
       │   │ 📦 Distribution      │
       │   │    Center            │
       │   │ Completed: 09:45     │
       │   │                      │
       │   │ 📍 Next Destination  │
       │   │ Destination: Mr.Wang │
       │   │ Address: SOHO T3     │
       │   │ ETA: 10:15           │
       │   └──────────────────────┘
       │
       └─► No Next Destination (Last Stop)
           │
           ▼
           ┌──────────────────────┐
           │ Mark Journey         │
           │ Complete             │
           │ UPDATE journeys      │
           │ SET status =         │
           │ 'completed'          │
           │ completed_at = now() │
           └──────┬───────────────┘
                  │
                  ▼
           ┌──────────────────────┐
           │ Display Completion   │
           │ Message              │
           │                      │
           │ ✅ Delivery Complete!│
           │                      │
           │ 📦 Ms. Li's Company  │
           │ Completed: 11:30     │
           │                      │
           │ 🎉 All Delivery      │
           │    Tasks Complete!   │
           └──────────────────────┘
```

---

## System Interaction Flow

### Driver → Bot → API → Database

```
┌─────────┐         ┌─────────┐         ┌─────────┐         ┌─────────┐
│  Driver │         │   Bot   │         │   API   │         │Database │
└────┬────┘         └────┬────┘         └────┬────┘         └────┬────┘
     │                   │                   │                   │
     │  Click "Today's   │                   │                   │
     │  Journeys"        │                   │                   │
     ├──────────────────►│                   │                   │
     │                   │  Query Journeys   │                   │
     │                   ├──────────────────►│                   │
     │                   │                   │  SELECT journeys  │
     │                   │                   ├──────────────────►│
     │                   │                   │                   │
     │                   │                   │  Return Data      │
     │                   │                   │◄──────────────────┤
     │                   │  Return List      │                   │
     │                   │◄──────────────────┤                   │
     │  Display Info     │                   │                   │
     │◄──────────────────┤                   │                   │
     │                   │                   │                   │
```

---

## State Transition Diagrams

### Journey State Transitions

```
     Start Journey
┌─────────┐  start  ┌─────────┐  complete  ┌───────────┐
│ pending ├────────►│ active  ├───────────►│ completed │
└─────────┘         └─────────┘            └───────────┘
 Not Started        In Progress             Completed
```

### Trip State Transitions

```
     Reach Destination    Complete Delivery
┌─────────┐  reached  ┌─────────┐  complete  ┌───────────┐
│ pending ├──────────►│ reached ├───────────►│ completed │
└─────────┘           └─────────┘            └───────────┘
 Not Started          Reached                 Completed
```

---

## Error Handling Flows

### Scenario: No Pending Journey When Starting

```
┌──────────────┐
│ Driver Clicks│
│"Start        │
│ Journey"     │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ Bot Queries Pending  │
│ Journey              │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ No Pending Journey   │
│ Found                │
│ (journeys.length=0)  │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Return Error Message │
│                      │
│ ❌ No pending        │
│    journeys          │
└──────────────────────┘
```

### Scenario: Complete Without Marking Reached

```
┌──────────────┐
│ Driver Clicks│
│"Complete     │
│ Delivery"    │
└──────┬───────┘
       │
       ▼
┌──────────────────────┐
│ Bot Queries Reached  │
│ Destination          │
│ WHERE status =       │
│ 'reached'            │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ No Reached           │
│ Destination Found    │
└──────┬───────────────┘
       │
       ▼
┌──────────────────────┐
│ Return Error Message │
│                      │
│ ❌ Please mark       │
│    "Reached          │
│    Destination"      │
│    first             │
└──────────────────────┘
```

---

## Timeline Example

### Complete Delivery Day Example

```
08:30  Driver starts Telegram Bot
       └─► Send /start command

08:31  View today's journeys
       └─► See 2 pending journeys

08:35  Start Journey 1
       └─► Share real-time location
       └─► System displays first destination

09:00  Arrive at distribution center
       └─► Mark "Reached Destination"
       └─► Get deep link

09:15  Complete pickup at center
       └─► Mark "Complete Delivery"
       └─► System displays next destination (Mr. Wang's home)

09:45  Arrive at Mr. Wang's home
       └─► Mark "Reached Destination"

10:00  Complete delivery to Mr. Wang
       └─► Mark "Complete Delivery"
       └─► System displays next destination (Ms. Li's company)

10:30  Arrive at Ms. Li's company
       └─► Mark "Reached Destination"

10:45  Complete delivery to Ms. Li
       └─► Mark "Complete Delivery"
       └─► System prompts: All delivery tasks complete!

11:00  View today's journeys
       └─► Journey 1: Completed (3/3)
       └─► Journey 2: Not Started (0/2)
```

---

## Data Flow Diagram

```
┌─────────────────────────────────────────────────────────┐
│                      Telegram Client                     │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐│
│  │View      │  │Start     │  │Reached   │  │Complete ││
│  │Journeys  │  │Journey   │  │Dest      │  │Delivery ││
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬────┘│
└───────┼─────────────┼─────────────┼──────────────┼─────┘
        │             │             │              │
        │ GET         │ POST        │ POST         │ POST
        │             │             │              │
┌───────▼─────────────▼─────────────▼──────────────▼─────┐
│                    Telegram Bot API                     │
└───────┬─────────────┬─────────────┬──────────────┬─────┘
        │             │             │              │
        │ Webhook     │ Webhook     │ Webhook      │ Webhook
        │             │             │              │
┌───────▼─────────────▼─────────────▼──────────────▼─────┐
│                     Bot Handler                         │
│                                                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐ │
│  │handleJourneys│  │handleStart   │  │handleReached │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘ │
└─────────┼──────────────────┼──────────────────┼─────────┘
          │                  │                  │
          │ Query            │ Update           │ Update
          │                  │                  │
┌─────────▼──────────────────▼──────────────────▼─────────┐
│                      Database (SQLite)                   │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐│
│  │ drivers  │  │ journeys │  │  trips   │  │location ││
│  └──────────┘  └──────────┘  └──────────┘  └─────────┘│
└─────────────────────────────────────────────────────────┘
```

---

## Summary

This flow diagram shows the complete process for drivers using the Telegram bot to complete delivery tasks, including:

1. **Initialization** - Start bot and view features
2. **View Journeys** - Understand today's delivery tasks
3. **Start Journey** - Begin delivery and share location
4. **Update Status** - Mark reached and complete
5. **Complete Journey** - Finish all delivery tasks

Each step has clear data flow and state transitions, ensuring smooth driver operations and accurate system state.
